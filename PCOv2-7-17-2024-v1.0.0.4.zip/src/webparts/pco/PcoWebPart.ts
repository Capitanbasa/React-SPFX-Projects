import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  type IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart} from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';

import Pco from './components/Pco';
import PcoPMReview from './components/PcoPMReview';
import CostEngineerReview from './components/CostEngineerReview';
import PRCreatorReview from './components/PRCreatorReview';
import InitiatorRevision from './components/InitiatorRevision';
import PM2ndReview from './components/PM2ndReview';
import POCreation from './components/POCreation';
import PRCreation from './components/PRCreation';
import POAttached from './components/POAttached';
import NoAccess from './components/NoAccess';
import * as strings from 'PcoWebPartStrings';
import { IPcoProps, IProjectListItem, IPcoListItems, IPcoWebPartProps, ITaskCodes } from './components/IPcoProps';
import { SPHttpClient } from '@microsoft/sp-http';
import { getSP } from './pnpjsConfig';

import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/lists/web";
import "@pnp/sp/site-users/web";
import 'bootstrap/dist/css/bootstrap.min.css';
import { isEmpty } from '@microsoft/sp-lodash-subset';



export default class PcoWebPart extends BaseClientSideWebPart<IPcoWebPartProps> {

  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = '';
  private _projectsList:  IProjectListItem[];
  private _pcoItem: IPcoListItems[];
  private _currentUserVerified: boolean = false;
  private _taskcodes: ITaskCodes[];
  private _view: boolean = false;

  public render(): void {
    let StageComponentForm = Pco;
    if(this._pcoItem && this._pcoItem.length > 0){
      if(this._currentUserVerified){
        switch (this._pcoItem[0].Stage) {
          case "PM Review":
            StageComponentForm = PcoPMReview; break;
          case 'Initiator Revision':
            StageComponentForm = InitiatorRevision; break;
          case 'Cost Engineer Review':
            StageComponentForm = CostEngineerReview; break;
          case 'PR Creator Review':
            StageComponentForm = PRCreatorReview; break;
          case 'PM 2nd Review':
            StageComponentForm = PM2ndReview; break;
          case 'PR Creation':
            StageComponentForm = PRCreation; break;
          case 'PO Creation':
            StageComponentForm = POCreation; break;
          case 'PO Attached':
            StageComponentForm = POAttached; break;
          default:
            StageComponentForm = Pco;
        }
      }else{
        StageComponentForm = NoAccess;
      }
    }else{
      StageComponentForm = Pco;
    }

    // Additional Feature to view the current workflow for non actors/assignedTo
    const params = new URLSearchParams(window.location.search);
    const view:string = params.get('view') as string;
    if( view === 'true'){
      this._view = true;
      if(this._pcoItem && this._pcoItem.length > 0){
        switch (this._pcoItem[0].Stage) {
          case "PM Review":
            StageComponentForm = PcoPMReview; break;
          case 'Initiator Revision':
            StageComponentForm = InitiatorRevision; break;
          case 'Cost Engineer Review':
            StageComponentForm = CostEngineerReview; break;
          case 'PR Creator Review':
            StageComponentForm = PRCreatorReview; break;
          case 'PM 2nd Review':
            StageComponentForm = PM2ndReview; break;
          case 'PR Creation':
            StageComponentForm = PRCreation; break;
          case 'PO Creation':
            StageComponentForm = POCreation; break;
          case 'PO Attached':
            StageComponentForm = POAttached; break;
          default:
            StageComponentForm = Pco;
        }
      }else{
        StageComponentForm = Pco;
      }
    }

    const element: React.ReactElement<IPcoProps> = React.createElement(
      StageComponentForm,
      {
        description: this.properties.description,
        isDarkTheme: this._isDarkTheme,
        userEmail: this.context.pageContext.user.email,
        environmentMessage: this._environmentMessage,
        hasTeamsContext: !!this.context.sdks.microsoftTeams,
        userDisplayName: this.context.pageContext.user.displayName,
        spContext: this.context,
        spProjectListItems: this._projectsList,
        PanePropsProjectNumberName: this.properties.PanePropsProjectNumberName,
        PanePropsProjectType: this.properties.PanePropsProjectType,
        PanePropsIPcoList : this.properties.PanePropsPcoList,
        spPCOListItems: this._pcoItem,
        PanePropsPropsedVendor: this.properties.PanePropsProposedVendor,
        spTaskCodeListItems: this._taskcodes,
        spView: this._view
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected async onInit(): Promise<void> {
    await this._onGetProjectListItems();
    return this._getEnvironmentMessage().then(message => {
      this._environmentMessage = message;
    });
  }

  private _onGetProjectListItems = async (): Promise<void> => {
    const projectlist: IProjectListItem[] = await this._getProjectListItems();
    const pcoItem: IPcoListItems[] = await this._getCurrentPcoItem();
    const CurrentUserVerify:boolean = await this._verfiyuser(pcoItem.length > 0 ? pcoItem[0].AssignedToId : 0);
    const taskcodes: ITaskCodes[] = await this._getTaskCodes();
    this._projectsList = projectlist;
    this._currentUserVerified = CurrentUserVerify;
    this._pcoItem = pcoItem;
    this._taskcodes = taskcodes;
  }

  private async _getProjectListItems(): Promise<IProjectListItem[]> {

    // const response = await this.context.spHttpClient.get(
    //   this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${this.properties.PanePropsProjectNumberName}')/items?$top=1000&$select=Id,ProjectName,ProjectType&$filter=Transaction eq 'PCO'`,
    //   SPHttpClient.configurations.v1)
    // if (!response.ok) {
    //   const responseText = await response.text();
    //   throw new Error(responseText);
    // }
    
    // const responseJson = await response.json();
    // console.log(response);

    const sp = getSP(this.context);
    const countLastIDList = await sp.web.lists.getByTitle(this.properties.PanePropsProjectNumberName).items.select("ID").orderBy("ID", false).top(1)();
    const TopLastID = countLastIDList.length > 0 ? countLastIDList[0].ID : 0;
    const vendorsretult = await sp.web.lists.getByTitle(this.properties.PanePropsProjectNumberName).items.select("ProjectName", "Id", "ProjectType").top(TopLastID).filter("Transaction eq 'PCO'")();
    console.log(vendorsretult);
    return vendorsretult;
  }

  private async _verfiyuser(assignedtoId:number): Promise<boolean> {
    const sp = getSP(this.context);

    if(assignedtoId !== 0 && assignedtoId){
      const user = await sp.web.currentUser();
      console.log("current User:", user);
      const assignedtoUserID = await sp.web.getUserById(assignedtoId)();
      console.log("Assigned User:", assignedtoUserID);
      if(user.UserId.NameId === assignedtoUserID.UserId.NameId){
        return true;
      }else{
        return false;
      }
    }else{
      return false;
    }
  }

  private async _getCurrentPcoItem(): Promise<IPcoListItems[]> {
    const params = new URLSearchParams(window.location.search);
    const PCO_ID:string = params.get('ReqID') as string ;
    if(!isEmpty(PCO_ID)){
      const response = await this.context.spHttpClient.get(
        this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${this.properties.PanePropsPcoList}')/items?$filter= ID eq ${escape(PCO_ID)}`,
        SPHttpClient.configurations.v1);
      if (!response.ok) {
        const responseText = await response.text();
        throw new Error(responseText);
      }
      
      const responseJson = await response.json();
      console.log(responseJson);
      return responseJson.value as IPcoListItems[];
    }else{
      const responseJson: IPcoListItems[]= [];
      return  responseJson;
    }
  
    
  }

  private async _getTaskCodes(): Promise<ITaskCodes[]> {

    const response = await this.context.spHttpClient.get(
      this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${this.properties.PanePropsTaskCodeList}')/items?$select=Id,TaskCode`,
      SPHttpClient.configurations.v1)
    if (!response.ok) {
      const responseText = await response.text();
      throw new Error(responseText);
    }
    
    const responseJson = await response.json();
  
    return responseJson.value as ITaskCodes[];
  }

  private _getEnvironmentMessage(): Promise<string> {
    if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
      return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
        .then(context => {
          let environmentMessage: string = '';
          switch (context.app.host.name) {
            case 'Office': // running in Office
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOffice : strings.AppOfficeEnvironment;
              break;
            case 'Outlook': // running in Outlook
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOutlook : strings.AppOutlookEnvironment;
              break;
            case 'Teams': // running in Teams
            case 'TeamsModern':
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentTeams : strings.AppTeamsTabEnvironment;
              break;
            default:
              environmentMessage = strings.UnknownEnvironment;
          }

          return environmentMessage;
        });
    }

    return Promise.resolve(this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentSharePoint : strings.AppSharePointEnvironment);
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }

    this._isDarkTheme = !!currentTheme.isInverted;
    const {
      semanticColors
    } = currentTheme;

    if (semanticColors) {
      this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
      this.domElement.style.setProperty('--link', semanticColors.link || null);
      this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
    }

  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('PanePropsPcoList', {
                  label: strings.PanePropsPcoList,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
                PropertyPaneTextField('PanePropsProjectNumberName', {
                  label: strings.PanePropsProjectNumberName,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
                PropertyPaneTextField('PanePropsProjectNumberNameDev', {
                  label: strings.PanePropsProjectNumberNameDev,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
                PropertyPaneTextField('PanePropsProposedVendor', {
                  label: strings.PanePropsProposedVendor,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
                PropertyPaneTextField('PanePropsTaskCodeList', {
                  label: strings.PanePropsProposedVendor,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
              ]
            }
          ]
        }
      ]
    };
  }

  private async validatePaneProps(value: string): Promise<string> {
    if (value === null || value.length === 0) {
      return "Provide the list name";
    }
    try{
      const response = await this.context.spHttpClient.get(
      this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${value}')/items?$select=Id`,
      SPHttpClient.configurations.v1);
      if (response.ok) {
        return "";
    } else if (response.status === 404) {
        return `List '${escape(value)}' doesn't exist in the current site`;
    }else{
        return `Error: ${response.statusText}. Please try again`;
    }
    }catch(error){
    return error.message;
    }
  }
}

