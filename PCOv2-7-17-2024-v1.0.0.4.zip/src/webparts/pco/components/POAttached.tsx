import * as React from 'react';
import styles from './Pco.module.scss';
import type { IPcoProps } from './IPcoProps';
//import { escape } from '@microsoft/sp-lodash-subset';
import { Alert, Button, Card, Col, Container, Form, Modal, Row, Spinner } from 'react-bootstrap';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup";
import { getSP } from '../pnpjsConfig';
import { IAttachmentInfo } from '@pnp/sp/attachments';
import addFilesPromise from '../utils/addFilesPromise';
import { PpoAttachedFormSchema, poAttachedFormSchema } from '../utils/types';
import WorkFlowSubmit from '../utils/Submit';
import { IoDocumentAttachOutline } from "react-icons/io5";
// import * as dayjs from 'dayjs';



export default function POAttached(Props:IPcoProps):React.ReactElement{
    const [ShowSuccess, setShowSuccess] = React.useState( false );
    const [message, setmessage]= React.useState( "" );
    const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
    const [CCGroup, setCCGroup ] = React.useState(false);
    const [theAttachmentFiles, settheAttachmentFiles] = React.useState<IAttachmentInfo[]>([]);
    const [, setnextStage] = React.useState("");
    const [ModalShow, setModalShow ] = React.useState(false);
    const handleClose = ():void => setModalShow(false);

    const { 
        register, 
        handleSubmit,
        formState: {errors, isSubmitting},
        reset, 
    } = useForm<PpoAttachedFormSchema>({
        resolver: yupResolver(poAttachedFormSchema),
    });

    const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
        if(FileAttachment && FileAttachment?.length > 0){
            for(let i =0; i < FileAttachment.length; i++){
                /* eslint-disable no-useless-escape */
                const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
                if(match){
                    setShowSuccess(true);
                    setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
                    setMessageType('danger');
                    return true;
                }else{
                    return false;
                }
            }
        }
        return false;
    }

    const onSubmit = async (data: PpoAttachedFormSchema):Promise<void> => {
        const sp = getSP(Props.spContext);
        const Attachment = document.getElementById("FileAttachment") as HTMLInputElement;
        const Attfiles = Attachment.files;
        if(filenameCharValidation(Attfiles)){ return; }

        data.CCUser = CCGroup === true ? "Yes": "No";
        data.Flag = "2";
        delete data.FileAttachment;
        console.log("Schema Data:", data);
        const newStatus = "Completed";
        const newStage = "Completed";
        data.Status = newStatus;
        data.Stage = newStage;

        await sp.web.lists.getByTitle(Props.PanePropsIPcoList).items.getById(parseInt(Props.spPCOListItems[0].Id)).update(data)
        .then(async (addResult) => {
            console.log("add result:",addResult);

            if(Attfiles && Attfiles?.length > 0){
                const PromoseArray = [];
                setShowSuccess(true);
                setmessage("Please wait while we upload the file Attachment.");
                setMessageType('warning');
                for(let i =0; i < Attfiles.length; i++){
                const UploadArray = await addFilesPromise( Props.PanePropsIPcoList, parseInt(Props.spPCOListItems[0].Id) ,Attfiles, i);
                PromoseArray.push(UploadArray);
                }

                Promise.all(PromoseArray).then( res => { 
                    console.log("Promise Upload resolve:", res);
                    setShowSuccess(true);
                    setmessage("Successfully Submitted Your Request.");
                    setMessageType('success');
                    reset();
                }).catch(err => { 
                    console.log("Promise Upload reject:", err);
                    setShowSuccess(true);
                    setmessage("Your Request is Submitted but there was a problem uploading the attachment");
                    setMessageType('danger');
                    reset();
                });
            }else{
                setShowSuccess(true);
                setmessage("Successfully Submitted Your Request without Attachment.");
                setMessageType('warning');
                reset();
            }
            const WFresult = await WorkFlowSubmit(Props.spPCOListItems[0].Id.toString(), false, newStatus, data.Stage, "2");
            console.log("WF Result:", WFresult);
            reset();
            setModalShow(true);
            return Promise.resolve;
        }).catch( (error) => {
            console.log("Error Submit:", error);
            setShowSuccess(true);
            setmessage("Sorry! Your Request failed to Submit. Please try again.");
                setMessageType('danger');
            return Promise.reject;
        });
            
    };

    let attachments: IAttachmentInfo[] = [];
    React.useEffect(() => {
        async function fecthData():Promise<void>{
        const sp = getSP();
        const item = sp.web.lists.getByTitle(Props.PanePropsIPcoList).items.getById(parseInt(Props.spPCOListItems[0].Id));
        attachments = await item.attachmentFiles().then(async res => {return await res});
        settheAttachmentFiles(attachments);
        console.log("await:",attachments);
        }
        fecthData().catch(console.error);
    },[]);

    return(
        <section className={`${styles.pco} ${Props.hasTeamsContext ? styles.teams : ''}`}>
            <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
                <fieldset disabled={Props.spView}>
                    <Container>
                        <Card>
                            <Card.Header className="h5">Purchase Change Order (PCO) - PO Attached</Card.Header>
                                <Card.Body>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Project Number and Name</Form.Label>
                                                <Form.Control type="text" defaultValue={Props.spPCOListItems[0].ProjectName} disabled/>
                                            </Form.Group>
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Instance Number</Form.Label>
                                                <Form.Control type="text" defaultValue={Props.spPCOListItems[0].Id} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Requester Name</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].RequesterName} disabled/>
                                            </Form.Group>
                        
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Requester Email</Form.Label>
                                                <Form.Control type="email"  defaultValue={Props.spPCOListItems[0].RequesterEmail} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Subject</Form.Label>
                                                <Form.Control type="text" defaultValue={Props.spPCOListItems[0].Subject} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Vendor</Form.Label>
                                                <Form.Control type="text" defaultValue={Props.spPCOListItems[0].Vendor} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>PCO Description</Form.Label>
                                                <Form.Control type="textarea"  defaultValue={Props.spPCOListItems[0].PCODescription} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Due Date</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].DueDate} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row clssname="mb-3">
                                        <Col>
                                        <Card style={{ width: '100%'}}>
                                            <Card.Header>Commitments</Card.Header>
                                                <Card.Body>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3" >
                                                                <Form.Label className={styles.required}>Commitment Name</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].CommitmentName} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label className={styles.required}>PO Number</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].PONumber} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3" >
                                                                <Form.Label className={styles.required}>PCO Amount</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].PCOAmount} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label className={styles.required}>Reason Code</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ReasonCode} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                </Card.Body>
                                        </Card>
                                        </Col>
                                    </Row>
                                    <Row className="mb-5">
                                        <Col>
                                            <Card style={{ width: '100%' }}>
                                                <Card.Header>Initiator Attachments</Card.Header>
                                                    <Card.Body>
                                                        <div className="d-grid gap-2">
                                                        {
                                                            theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                                                            return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                                                            })
                                                        }
                                                        </div>
                                                    </Card.Body>
                                            </Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Need by Date</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].NeedByDate} disabled/>
                                            </Form.Group>
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Procurement Reason for Need By Date Update</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ProcurementReasonChange} disabled/>
                                            </Form.Group>
                                        </Col>       
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Special Instructions for Procurement</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].SpecialInstructionsProcurement} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Description of Root Cause</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].DescriptionofRootCause} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row clssname="mb-3">
                                        <Col>
                                        <Card style={{ width: '100%'}}>
                                            <Card.Header className="h5">Ready for PR Creation</Card.Header>
                                                <Card.Body>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3" >
                                                                <Form.Label className={styles.required}>PCO Type</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].PCOType} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label className={styles.required}>SPWR Executed CO Numer</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].SPWRExecutedCONumber} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3" >
                                                                <Form.Label className={styles.required}>Pricing Methodology</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].PricingMethodology} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label className={styles.required}>Promise Date</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].PromiseDate} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                </Card.Body>
                                        </Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label className={styles.required}>Date PR Approved</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].DatePRApproved} disabled/>
                                            </Form.Group>
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label className={styles.required}>Date PO Approved</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].DatePOApproved} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Approved PO Amount</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ApprovedPOAmount} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>New Promise Date</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].NewPromiseDate} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>New Promise Date Comment</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].NewPromisedDateComment} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>New Required by Date</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].NewRequiredbyDate} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>New Required by Comment</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].NewRequiredbyComment} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    
                                    <Row className="mb-5">
                                        <Col>
                                            <Card style={{ width: '100%' }}>
                                                <Card.Header>CC Users</Card.Header>
                                                    <Card.Body>
                                                        <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                                                            <Form.Group className="mb-3" >
                                                            <Form.Check
                                                                inline
                                                                label="Yes"
                                                                value="true"
                                                                {...register("CCUser")} 
                                                                onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}/>
                                                            </Form.Group>
                                                            <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                                                                <Form.Label className={styles.required}>Email Addresses</Form.Label>
                                                                <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails } defaultValue={Props.spPCOListItems[0].CCEmails}/>
                                                                <Form.Control.Feedback type="invalid">
                                                                    {errors.CCEmails?.message}
                                                                </Form.Control.Feedback>
                                                            </Form.Group>
                                                            <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                                                                <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                                                                <Form.Control as="textarea" rows={3} {...register("CCComment")} defaultValue={Props.spPCOListItems[0].CCComment}/>
                                                            </Form.Group>
                                                    </Card.Body>
                                            </Card>
                                        </Col>
                                    </Row>
                                    <Row className="mb-5">
                                        <Col>
                                            <Form.Group >
                                                <Form.Label className={styles.required}>Attach CO</Form.Label>
                                                <Form.Control type="file" id="FileAttachment" multiple {...register("FileAttachment")} />
                                            </Form.Group>
                                            <p className="link-danger">{errors.FileAttachment?.message}</p>
                                        </Col>
                                    </Row>
                                    <Row className="mb-3">
                                        <Col>
                                            <Form.Group >
                                                <Form.Check
                                                    type = "checkbox"
                                                    label="CO Attached"
                                                    value="Yes"
                                                    {...register("COAttached")} isInvalid={ !!errors.COAttached }/>
                                            </Form.Group>
                                            <p className="link-danger">{errors.COAttached?.message}</p>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-5">
                                            <Form.Label className={styles.required}>Next step</Form.Label>
                                            <Form.Select aria-label="Please Select Next Step" {...register("Stage")} isInvalid={!!errors.Stage } onChange={(e)=>{setnextStage(e.currentTarget.value )}} >
                                                <option value="">Please Select Next Step</option>
                                                <option key='ns1' value="Complete">Finish</option>
                                            </Form.Select>
                                            <Form.Control.Feedback type="invalid">
                                                {errors.Stage?.message}
                                            </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row className="mb-4">
                                        <Col>
                                            <div className="d-grid gap-2">
                                                <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting } >
                                                    <Spinner
                                                        as="span"
                                                        animation="border"
                                                        size="sm"
                                                        role="status"
                                                        aria-hidden={ !!isSubmitting }
                                                        className={ "visually-hidden" } />
                                                    { isSubmitting ? "...Submitting" : "SUBMIT" }
                                                </Button>
                                            </div>
                                        </Col>
                                    </Row>
                                    { ShowSuccess && (
                                        <Alert 
                                        key={ MessageType } 
                                        variant={ MessageType } 
                                        dismissible 
                                        onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                                            { message }
                                        </Alert>
                                    )}
                            </Card.Body>
                        </Card>
                    </Container>
                </fieldset>
            </form>
            <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
                <Modal.Header>
                    <Modal.Title>SharePoint</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Alert variant="primary">
                        <Alert.Heading>{ message }</Alert.Heading>
                        <p hidden={MessageType === "danger" ? true : false}>
                        Thank you! You can now close this tab or window.
                        </p>
                    </Alert>
                </Modal.Body>
                <Modal.Footer hidden={MessageType === "danger" ? false : true}>
                    <Button variant="secondary" onClick={handleClose}>
                        Continue
                    </Button>
                </Modal.Footer>
            </Modal>
        </section>
    );
}



