import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IPcoProps {
  description: string;
  userEmail: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  spProjectListItems?: IProjectListItem[];
  spPCOListItems: IPcoListItems[];
  PanePropsProjectNumberName: string;
  PanePropsProjectType: string;
  spContext: WebPartContext;
  PanePropsIPcoList:string;
  PanePropsPropsedVendor: string;
  spTaskCodeListItems: ITaskCodes[];
  spView:boolean;
  
}

export interface IPcoWebPartProps {
  PanePropsPcoList: string;
  PanePropsProjectType: string;
  description: string;
  PanePropsProjectNumberName: string;
  PanePropsDEVProjectNumberName: string;
  PanePropsProposedVendor: string;
  PanePropsTaskCodeList: string;
  // PanePropsIPcoList:string;
  
}

export interface IProjectListItem{
  id: string;
  ProjectType: string;
  ProjectName: string;
  RequesterName: string;
  RequesterEmail: string;
  Subject: string;
  CCUser: string;
  CCEmails	: string;
  CCComment: string;
}

export interface ITaskCodes {
  id:string;
  TaskCode: string;
}

export interface IPcoListItems{
  Id: string;
  Stage: string;
  Status:string;
  AssignedToId:number;
  Flag:string;
  ProjectType: string;
  ProjectName: string;
  RequesterName: string;
  RequesterEmail:string;
  Subject: string;
  ProposedVendor: string;
  Vendor: string;
  DoestheContactneedaCopyofthePO: string;
  IsthisContactaReplacementofthePr: string;
  PCODescription: string;
  DueDate: string;
  ContractorPCONumber: string;
  ContractorPCODocument: string;
  EstimatedWorkCompletion: string;
  IsContractorPerformingWorkonSite: string;
  ZeroCostPCO: string;
  RelatedRFI: string;
  CanWeRequestaChangeOrdertotheCli: string;
  IfNoProvideFeedbackofSourcetothe: string;
  ScheduleImpact: string;
  ScheduleImpactNotes: string;
  CommitmentName: string;
  PONumber: string;
  PCOAmount: number;
  ReasonCode: string;
  PCOLineItems: string;
  CCUser: string;
  CCEmails	: string;
  CCComment: string;
  VendorName: string;
  DelegatedToId:string;
  Comments: string;
  NeedByDate: string;
  DescriptionofRootCause: string;
  SpecialInstructionsProcurement: string;
  RelatedRisk: string;
  TaskCode: string;
  InitialForecastAmount: number;
  FinalCommitmentAmount: string;
  Description: string;
  ProjectManagerComments: string;
  ProcurementComments: string;
  CommentsforPM: string;
  DelegatedTo: string;
  CommentsforInitiator: string;
  NeedtoReviseTaskCode: string;
  ReasonforCostCodeRevision: string;
  SpecialInstructionsforProcure: string;
  NeedtoUpdate: string;
  ProcurementReasonChange: string;
  RequestPMRComments: string;
  VoidComments: string;
  PCOType: string;
  SPWRExecutedCONumber: string;
  PricingMethodology: string;
  PromiseDate: string;
  ProcurementMngrComts: string;
  CommentsforPM2ndReview: string;
  ContacttoRemoved: string;
  PRRejectedComments: string;
  PRNumber: string;
  DatePREntered: string;
  CommentsRevise: string;
  ContactReplacement: string;
  DatePRApproved: string;
  DatePOApproved: string;
  ApprovedPOAmount: number;
  NewPromiseDate: string;
  NewPromisedDateComment: string;
  NewRequiredbyDate: string;
  NewRequiredbyComment: string;
  COAttached: string;
  TaskCodeItem2:string;
  InitialAmountItem2:string;
  DescriptionItem2:string;
  TaskCodeItem1:string;
  InitialAmountItem1:string;
  DescriptionItem1:string;
  TaskCodeItem3:string;
  InitialAmountItem3:string;
  DescriptionItem3:string;
  FinalAmountItem1: string;
  FinalAmountItem2: string;
  FinalAmountItem3: string;
}