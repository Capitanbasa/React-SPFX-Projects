import * as React from 'react';
import styles from './Pco.module.scss';
import type { IPcoProps } from './IPcoProps';
//import { escape } from '@microsoft/sp-lodash-subset';
import { Alert, Button, Card, Col, Container, Form, Modal, Row, Spinner } from 'react-bootstrap';
import { DatePicker } from 'antd';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup";
import { getSP } from '../pnpjsConfig';
import addFilesPromise from '../utils/addFilesPromise';
import { IProposeVendor, PpcoFormSchema, pcoFormSchema } from '../utils/types';
import WorkFlowSubmit from '../utils/Submit';
import * as dayjs from 'dayjs';


export default function Pco(Props:IPcoProps):React.ReactElement{
  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [CCGroup, setCCGroup ] = React.useState(false);
  const [CWRCO, setCWRCO] = React.useState(false);
  const [ICRPO, setICRPO] = React.useState(true);
  const [PCOLI, setPCOLI] = React.useState("");
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);
  const [VendorRange, setVendorRange]  = React.useState("");


  const [Vendor, setVendor] = React.useState<IProposeVendor[]>([]);
  const [ProjectType, setProjectType] = React.useState("");

 
  const { 
    register, 
    handleSubmit,
    formState: {errors, isSubmitting},
    reset, setValue
  } = useForm<PpcoFormSchema>({
    resolver: yupResolver(pcoFormSchema),
  });

  const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
    if(FileAttachment && FileAttachment?.length > 0){
      for(let i =0; i < FileAttachment.length; i++){
        /* eslint-disable no-useless-escape */
        const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
        if(match){
          setShowSuccess(true);
          setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
          setMessageType('danger');
          return true;
        }else{
          return false;
        }
      }
    }
    return false;
  }
 

  const onSubmit = async (data: PpcoFormSchema):Promise<void> => {
    const sp = getSP(Props.spContext);
    const Attachment = document.getElementById("FileAttachment") as HTMLInputElement;
    const Attfiles = Attachment.files;
    if(filenameCharValidation(Attfiles)){ return; }

    data.CCUser = CCGroup === true ? "Yes": "No";
    data.Flag = "1";
    console.log("Schema Data:", data);
    delete data.ProjectType;

    await sp.web.lists.getByTitle(Props.PanePropsIPcoList).items.add(data)
    .then(async (addResult) => {
      console.log("add result:",addResult);

      if(Attfiles && Attfiles?.length > 0){
        const PromoseArray = [];
        setShowSuccess(true);
        setmessage("Please wait while we upload the file Attachment.");
        setMessageType('warning');
        for(let i =0; i < Attfiles.length; i++){
          const UploadArray = await addFilesPromise( Props.PanePropsIPcoList, addResult.ID ,Attfiles, i);
          PromoseArray.push(UploadArray);
        }
        Promise.all(PromoseArray).then( res => { 
          console.log("Promise Upload resolve:", res);
          setShowSuccess(true);
          setmessage("Successfully Submitted Your Request.");
          setMessageType('success');
          reset();
        })
        .catch(err => { 
          console.log("Promise Upload reject:", err);
          setShowSuccess(true);
          setmessage("Your Request is Submitted but there was a problem uploading the attachment");
          setMessageType('danger');
          reset();
        });
      }else{
        setShowSuccess(true);
        setmessage("Successfully Submitted Your Request without Attachment.");
        setMessageType('warning');
        reset();
      }
      const WFresult = await WorkFlowSubmit(addResult.ID.toString(), true, "Pending", "PM Review", "1",data.ProjectName);
      console.log("WF Result:", WFresult);
      reset();
      setModalShow(true);
      return Promise.resolve;
    })
    .catch( (error) => {
        console.log("Error Submit:", error);
        setShowSuccess(true);
        setmessage("Sorry! Your Request failed to Submit. Please try again.");
         setMessageType('danger');
        return Promise.reject;
    });
    
  };

  // const getFIlteredVendor = async (range:string):Promise<void> => {
  //   const sp = getSP(Props.spContext);
  //   console.log("Vendor", Props.PanePropsPropsedVendor);
  //   console.log("Range",range);
  //   const vendorsretult:IProposeVendor[] = await sp.web.lists.getByTitle(Props.PanePropsPropsedVendor).items.select("VendorName", "Id").filter("Range eq '"+range.toString()+"'").top(2000)();
  //   setVendor(vendorsretult);
  // }

  React.useEffect(() => {
    async function getAllVendor():Promise<void>{
      const sp = getSP(Props.spContext);
      const countLastIDList = await sp.web.lists.getByTitle(Props.PanePropsPropsedVendor).items.select("ID").orderBy("ID", false).top(1)();
      const TopLastID = countLastIDList.length > 0 ? countLastIDList[0].ID : 0;
      const vendorsretult:IProposeVendor[] = await sp.web.lists.getByTitle(Props.PanePropsPropsedVendor).items.select("VendorName", "Id", "Range").top(TopLastID)();
      setVendor(vendorsretult);
      console.log("Vendor", vendorsretult);
    }
    getAllVendor().catch(console.error);
  },[]);

  return(
    <section className={`${styles.pco} ${Props.hasTeamsContext ? styles.teams : ''}`}>
       <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
       <Container>
            <Card>
              <Card.Header className="h5">Purchase Change Order (PCO)</Card.Header>
                <Card.Body>
                <Row>
                      <Col>
                      <Form.Group className="mb-3">
                        <Form.Label className={styles.required}>Project Type</Form.Label>
                        <Form.Select aria-label="Please Select" 
                          {...register("ProjectType")} 
                          isInvalid={ !!errors.ProjectType } 
                          onChange={ (e) => { setProjectType(e.currentTarget.value)} }>
                          <option value="">Please Select</option> 
                          <option key="pt-1" value="Prod">Project</option>
                          <option key="pt-2" value="DEV">DEV Project</option>
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">
                          {errors.ProjectType?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                      <Form.Group className="mb-3" hidden={ ProjectType === "" ? true : false }>
                        <Form.Label className={styles.required}>Project Number and Name</Form.Label>
                        <Form.Select aria-label="Please Select Project" {...register("ProjectName")} isInvalid={ !!errors.ProjectName }>
                          <option value="">Please Select Project</option> 
                            {Props.spProjectListItems && Props.spProjectListItems.map((list) => {
                              if(list.ProjectType === ProjectType ){
                                  return  ( 
                                    <option key={list.id} value={list.ProjectName}>{list.ProjectName}</option> 
                                  );
                                }
                            })}
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">
                          {errors.ProjectName?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                      </Col>
                    </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Label className={styles.required}>Requester Name</Form.Label>
                        <Form.Control type="text" {...register("RequesterName")} defaultValue={Props.userDisplayName} isInvalid={ !!errors.RequesterName }/>
                        <Form.Control.Feedback type="invalid">
                          {errors.RequesterName?.message} 
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label className={styles.required}>Requester Email</Form.Label>
                        <Form.Control type="email" {...register("RequesterEmail")} isInvalid={ !!errors.RequesterEmail } defaultValue={Props.userEmail}/>
                        <Form.Control.Feedback type="invalid">
                          {errors.RequesterEmail?.message} 
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Label className={styles.required}>Subject</Form.Label>
                        <Form.Control type="text" id="txtSubject" {...register("Subject")} isInvalid={ !!errors.Subject }/>
                        <Form.Control.Feedback type="invalid">
                          {errors.Subject?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label className={styles.required}>Vendor first Initial Range</Form.Label>
                        <Form.Select aria-label="Please Select Range" {...register("ProposedVendor")} isInvalid={!!errors.ProposedVendor } onChange={(e) => { setVendorRange(e.currentTarget.value) }}>
                          <option key="range-null" value="">Please Select Range</option>
                          <option key='range-ad' value="A-D">A-D</option>
                          <option key='range-em' value="E-M">E-M</option>
                          <option key='range-nr' value="N-R">N-R</option> 
                          <option key='range-sz' value="S-Z">S-Z</option>
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">
                          {errors.ProposedVendor?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3">
                            <Form.Label className={styles.required}>Vendor</Form.Label>
                            <Form.Select aria-label="Please Select Vendor" {...register("Vendor")} isInvalid={ !!errors.Vendor }>
                              <option key="range-null" value="">Please Select Vendor</option>
                              {Vendor && Vendor.map((list) => {
                                if(list.Range === VendorRange ){
                                    return  ( 
                                      <option key={list.id} value={list.VendorName}>{list.VendorName}</option>
                                    );
                                  }
                              })}
                            </Form.Select>
                            <Form.Control.Feedback type="invalid">
                              {errors.Vendor?.message}
                            </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Label>Does the contact need a copy of the PO?</Form.Label>
                    </Col>
                    <Col>
                      <Form.Label>Is this contact a replacement of the previous PO receiver?</Form.Label>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Select aria-label="Please Select" {...register("DoestheContactneedaCopyofthePO")} isInvalid={!!errors.DoestheContactneedaCopyofthePO }>
                          <option value="">Please Select</option> 
                          <option key='Yes' value="Yes">Yes</option>
                          <option key='No' value="No">No</option>
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">{errors.DoestheContactneedaCopyofthePO?.message}</Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group className="mb-5">
                        <Form.Select aria-label="Please Select" 
                        {...register("IsthisContactaReplacementofthePr")} 
                        isInvalid={!!errors.IsthisContactaReplacementofthePr } 
                        onChange={(e) => { setICRPO(e.currentTarget.value === "No" || e.currentTarget.value ===""? true : false)}}>
                          <option value="">Please Select</option> 
                          <option key='Yes' value="Yes">Yes</option>
                          <option key='No' value="No">No</option>
                        </Form.Select>
                        <Form.Control.Feedback type="invalid"> {errors.IsthisContactaReplacementofthePr?.message}</Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row hidden={ICRPO}>
                    <Col>
                    <Form.Label className={styles.required}>If Contact Replacement, please specify the contact to be removed</Form.Label>
                    <Form.Group className="mb-5">
                    <Form.Control type="text" {...register("ContacttoRemoved")} isInvalid={ !!errors.ContacttoRemoved }/>
                        <Form.Control.Feedback type="invalid">
                          {errors.ContacttoRemoved?.message}
                        </Form.Control.Feedback>
                    </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Label className={styles.required}>PCO Description</Form.Label>
                        <Form.Control as="textarea" {...register("PCODescription")} isInvalid={ !!errors.PCODescription }/>
                        <Form.Control.Feedback type="invalid">
                          {errors.PCODescription?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Label className={styles.required}>Due Date</Form.Label>
                        <DatePicker 
                              className='form-control' 
                              allowClear={true}
                              format={"MMM DD, YYYY"}
                              minDate={dayjs()}
                              {...register("DueDate")}
                              onChange={(e): void => {  if(e){ setValue("DueDate", e.format("MMM DD, YYYY").toString(),  { shouldValidate: true }) } }} />
                          <Form.Control.Feedback type="invalid">
                            {errors.DueDate?.message} 
                          </Form.Control.Feedback>
                          <p className="link-danger">{errors.DueDate?.message}</p>
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label >Contractor PCO Number</Form.Label>
                        <Form.Control type="text" {...register("ContractorPCONumber")}/>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Label>Contractor PCO Document (link to SharePoint)</Form.Label>
                        <Form.Control type="text" id="txtContrcatorPCODocument" {...register("ContractorPCODocument")} isInvalid={!!errors.ContractorPCODocument }/>
                        <Form.Control.Feedback type="invalid">
                          {errors.ContractorPCODocument?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Label className={styles.required}>Estimated Work Completion</Form.Label>
                        <DatePicker 
                              className='form-control' 
                              allowClear={true}
                              format={"MMM DD, YYYY"}
                              minDate={dayjs()}
                              {...register("EstimatedWorkCompletion")}
                              onChange={(e): void => {  if(e){ setValue("EstimatedWorkCompletion", e.format("MMM DD, YYYY").toString(),  { shouldValidate: true }) } }} />
                          <Form.Control.Feedback type="invalid">
                            {errors.EstimatedWorkCompletion?.message} 
                          </Form.Control.Feedback>
                          <p className="link-danger">{errors.EstimatedWorkCompletion?.message}</p>
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label className={styles.required}>Is Contractor Performing Work on Site? </Form.Label>
                        <Form.Select aria-label="Please Select" {...register("IsContractorPerformingWorkonSite")} isInvalid={!!errors.IsContractorPerformingWorkonSite }>
                          <option value="">Please Select</option> 
                          <option key='Yes' value="Yes">Yes</option>
                          <option key='No' value="No">No</option>
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">
                          {errors.IsContractorPerformingWorkonSite?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Label>Zero Cost PCO</Form.Label>
                        <Form.Select aria-label="Please Select" {...register("ZeroCostPCO")} isInvalid={!!errors.ZeroCostPCO }>
                          <option value="">Please Select</option> 
                          <option key='sc1' value="Yes">Yes</option>
                          <option key='sc2' value="No">No</option> 
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">
                          {errors.ZeroCostPCO?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label>Related RFI</Form.Label>
                        <Form.Control type="text" id="txtRelatedRFI" {...register("RelatedRFI")} isInvalid={!!errors.RelatedRFI }/>
                        <Form.Control.Feedback type="invalid">
                          {errors.RelatedRFI?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label className={styles.required}>Can we request a Change Order to the client in regards to this PCO?</Form.Label>
                        <Form.Select aria-label="Please Select" 
                          {...register("CanWeRequestaChangeOrdertotheCli")} 
                          isInvalid={!!errors.CanWeRequestaChangeOrdertotheCli }
                          onChange={(e) => { setCWRCO(e.currentTarget.value === "Yes" ? true : false)}}>
                          <option key='cocno' value="No">No</option> 
                          <option key='cocyes' value="Yes">Yes</option>
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">
                          {errors.CanWeRequestaChangeOrdertotheCli?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row hidden={CWRCO}>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Label className={styles.required}>If no, provide feedback of source to the change.</Form.Label>
                        <Form.Control type="text" id="txtIfNoProvideFeedbackofSourcetotheChange" {...register("IfNoProvideFeedbackofSourcetothe")} isInvalid={!!errors.IfNoProvideFeedbackofSourcetothe }/>
                        <Form.Control.Feedback type="invalid">
                          {errors.IfNoProvideFeedbackofSourcetothe?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Label className={styles.required}>Schedule Impact</Form.Label>
                        <Form.Control type="text" id="txtScheduleImpact" {...register("ScheduleImpact")} isInvalid={!!errors.ScheduleImpact }/>
                        <Form.Control.Feedback type="invalid">
                          {errors.ScheduleImpact?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Label className={styles.required}>Schedule Impact Notes</Form.Label>
                        <Form.Control as="textarea" {...register("ScheduleImpactNotes")} isInvalid={!!errors.ScheduleImpactNotes }/>
                        <Form.Control.Feedback type="invalid">
                          {errors.ScheduleImpactNotes?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row clssname="mb-3">
                    <Col>
                    <Card className="mb-3" style={{ width: '100%'}}>
                      <Card.Header className="h5">Commitment</Card.Header>
                        <Card.Body>
                          <Row>
                            <Col>
                              <Form.Group className="mb-3" >
                                <Form.Label className={styles.required}>Commitment Name</Form.Label>
                                <Form.Control type="text" {...register("CommitmentName")} isInvalid={!!errors.CommitmentName }/>
                                <Form.Control.Feedback type="invalid">
                                  {errors.CommitmentName?.message}
                                </Form.Control.Feedback>
                              </Form.Group>
                            </Col>
                            <Col>
                              <Form.Group className="mb-3">
                                <Form.Label className={styles.required}>PO Number</Form.Label>
                                <Form.Control type="text" {...register("PONumber")} isInvalid={!!errors.PONumber }/>
                                <Form.Control.Feedback type="invalid">
                                  {errors.PONumber?.message}
                                </Form.Control.Feedback>
                              </Form.Group>
                            </Col>
                          </Row>
                          <Row>
                            <Col>
                              <Form.Group className="mb-3" >
                                <Form.Label className={styles.required}>PCO Amount</Form.Label>
                                <Form.Control type="text" id="txtPCOAmount" {...register("PCOAmount")} isInvalid={!!errors.PCOAmount }/>
                                <Form.Control.Feedback type="invalid">
                                  {errors.PCOAmount?.message}
                                </Form.Control.Feedback>
                              </Form.Group>
                            </Col>
                          </Row>
                          <Row>
                            <Col>
                              <Form.Group className="mb-3">
                                <Form.Label className={styles.required}>Reason Code</Form.Label>
                                <Form.Select aria-label="Please Select" {...register("ReasonCode")} isInvalid={!!errors.ReasonCode }>
                                  <option value="">Please Select</option>
                                  <option key='sc1' value="BOM Change (Changes)">BOM Change (Changes)</option>
                                  <option key='sc2' value="Delayed Material (Changes)">Delayed Material (Changes)</option>
                                  <option key='sc3' value="Design Commission (Changes)">Design Commission (Changes)</option>
                                  <option key='sc4' value="Inaccurate Mat Estim (Changes)">Inaccurate Mat Estim (Changes)</option>
                                  <option key='sc5' value="Mat Non-Conformance (Changes)">Mat Non-Conformance (Changes)</option>
                                  <option key='sc6' value="Oracle Recon (Changes)">Oracle Recon (Changes)</option>
                                  <option key='sc7' value="Owner Funded Change (Changes)">Owner Funded Change (Changes)</option>
                                  <option key='sc8' value="Pan Original Scope (Changes)">Pan Original Scope (Changes)</option>
                                  <option key='sc9' value="Schedule Change (Changes)">Schedule Change (Changes)</option>
                                  <option key='sc10' value="Scope Gap (Changes)">Scope Gap (Changes)</option>
                                  <option key='sc11' value="Sub Non-Conformance (Changes)">Sub Non-Conformance (Changes)</option>
                                  <option key='sc12' value="Unforeseen Condition (Changes)">Unforeseen Condition (Changes)</option>
                                </Form.Select>
                                <Form.Control.Feedback type="invalid">
                                  {errors.ReasonCode?.message}
                                </Form.Control.Feedback>
                              </Form.Group>
                            </Col>
                          </Row>
                          <Row>
                            <Col>
                              <Form.Group className="mb-3">
                                <Form.Label className={styles.required}># PCO Line Items</Form.Label>
                                <Form.Select aria-label="Please Select" {...register("PCOLineItems")} 
                                onChange={(e) => { setPCOLI(e.currentTarget.value )}}
                                isInvalid={!!errors.PCOLineItems }>
                                  <option value="">Please Select</option> 
                                  <option key='1' value="1">1</option>
                                  <option key='2' value="2">2</option>
                                  <option key='3' value="3">3</option>
                                </Form.Select>
                                <Form.Control.Feedback type="invalid">
                                  {errors.PCOLineItems?.message}
                                </Form.Control.Feedback>
                              </Form.Group>
                            </Col>
                          </Row>
                        </Card.Body>
                    </Card>
                    </Col>
                  </Row>
                  <Card className="mb-3" style={{ width: '100%'}} hidden = {PCOLI === "1" || PCOLI === "2" || PCOLI === "3"? false : true}>
                      <Card.Header className="h5">Line Item 1</Card.Header>
                        <Card.Body>
                        <Row>
                          <Col>
                            <Form.Group className="mb-3">
                              <Form.Label className={styles.required}>Task Code</Form.Label>
                              <Form.Select aria-label="Please Select" {...register("TaskCodeItem1")} isInvalid={ !!errors.TaskCodeItem1 }>
                                <option value="">Please Select</option>
                                {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                      return  ( 
                                        <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                      );
                                })}
                              </Form.Select>
                              <Form.Control.Feedback type="invalid">
                                {errors.TaskCodeItem1?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                          <Col>
                            <Form.Group className="mb-3" >
                                <Form.Label >Initial Forecast Amount</Form.Label>
                                <Form.Control type="text" id="txtInitialAmountItem1" {...register("InitialAmountItem1")} isInvalid={!!errors.InitialAmountItem1 }/>
                                <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem1?.message}
                                </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                        </Row>
                        <Row>
                            <Col>
                            <Form.Group className="mb-3" >
                                <Form.Label>Description</Form.Label>
                                <Form.Control type="textarea" {...register("DescriptionItem1")} isInvalid={ !!errors.DescriptionItem1 }/>
                                <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem1?.message}
                                </Form.Control.Feedback>
                            </Form.Group>
                            </Col>
                        </Row>
                      </Card.Body>
                    </Card>
                    <Card className="mb-3" style={{ width: '100%'}} hidden = {PCOLI === "2" || PCOLI === "3"? false : true}>
                      <Card.Header className="h5">Line Item 2</Card.Header>
                        <Card.Body>
                        <Row>
                          <Col>
                            <Form.Group className="mb-3">
                              <Form.Label className={styles.required}>Task Code</Form.Label>
                              <Form.Select aria-label="Please Select" {...register("TaskCodeItem2")} isInvalid={ !!errors.TaskCodeItem2 }>
                                <option value="">Please Select</option>
                                {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                      return  ( 
                                        <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                      );
                                })}
                              </Form.Select>
                              <Form.Control.Feedback type="invalid">
                                {errors.TaskCodeItem2?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                          <Col>
                            <Form.Group className="mb-3" >
                                <Form.Label>Initial Forecast Amount</Form.Label>
                                <Form.Control type="text" id="txtInitialAmountItem2" {...register("InitialAmountItem2")} isInvalid={!!errors.InitialAmountItem2 }/>
                                <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem2?.message}
                                </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                        </Row>
                        <Row>
                            <Col>
                            <Form.Group className="mb-3" >
                                <Form.Label>Description</Form.Label>
                                <Form.Control type="textarea" {...register("DescriptionItem2")} isInvalid={ !!errors.DescriptionItem2 }/>
                                <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem2?.message}
                                </Form.Control.Feedback>
                            </Form.Group>
                            </Col>
                        </Row>
                      </Card.Body>
                    </Card>
                    <Card className="mb-3" style={{ width: '100%'}}  hidden = {PCOLI === "3" ? false : true}>
                      <Card.Header className="h5">Line Item 3</Card.Header>
                        <Card.Body>
                        <Row>
                          <Col>
                            <Form.Group className="mb-3">
                              <Form.Label className={styles.required}>Task Code</Form.Label>
                              <Form.Select aria-label="Please Select" {...register("TaskCodeItem3")} isInvalid={ !!errors.TaskCodeItem3 }>
                                <option value="">Please Select</option>
                                {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                      return  ( 
                                        <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                      );
                                })}
                              </Form.Select>
                              <Form.Control.Feedback type="invalid">
                                {errors.TaskCodeItem3?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                          <Col>
                            <Form.Group className="mb-3" >
                                <Form.Label >Initial Forecast Amount</Form.Label>
                                <Form.Control type="text" id="txtInitialAmountItem3" {...register("InitialAmountItem3")} isInvalid={!!errors.InitialAmountItem3 }/>
                                <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem3?.message}
                                </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                        </Row>
                        <Row>
                            <Col>
                            <Form.Group className="mb-3" >
                                <Form.Label>Description</Form.Label>
                                <Form.Control type="textarea" {...register("DescriptionItem3")} isInvalid={ !!errors.DescriptionItem3 }/>
                                <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem3?.message}
                                </Form.Control.Feedback>
                            </Form.Group>
                            </Col>
                        </Row>
                      </Card.Body>
                    </Card> 
                    <Row className="mb-5">
                      <Col>
                        <Card style={{ width: '100%' }}>
                          <Card.Header>CC Users</Card.Header>
                          <Card.Body>
                          <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                            <Form.Group className="mb-3" >
                              <Form.Check
                                inline
                                label="Yes"
                                value="true"
                                {...register("CCUser")}
                                onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                              />
                            </Form.Group>
                            <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                              <Form.Label className={styles.required}>Email Addresses</Form.Label>
                              <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                              <Form.Control.Feedback type="invalid">
                                {errors.CCEmails?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                            <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                              <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                              <Form.Control as="textarea" rows={3} {...register("CCComment")}/>
                            </Form.Group>
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
                    <Row className='mt-4'>
                      <Col>
                        <Form.Group className="mb-5">
                          <Form.Label >Attachments</Form.Label>
                          <Form.Control type="file" id="FileAttachment" multiple />
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row className="mb-4">
                      <Col>
                        <div className="d-grid gap-2">
                          <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting }>
                            <Spinner
                              as="span"
                              animation="border"
                              size="sm"
                              role="status"
                              aria-hidden={ !!isSubmitting }
                              className={ "visually-hidden" } />
                            { isSubmitting ? "...Submitting" : "SUBMIT" }
                          </Button>
                        </div>
                      </Col>
                    </Row>
                { ShowSuccess && (
                    <Alert 
                      key={ MessageType } 
                      variant={ MessageType } 
                      dismissible 
                      onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                        { message }
                    </Alert>
                )}
                </Card.Body>
              </Card>
        </Container>
      </form>
      <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
          <Modal.Header>
              <Modal.Title>SharePoint</Modal.Title>
          </Modal.Header>
          <Modal.Body>
              <Alert variant="primary">
                  <Alert.Heading>{ message }</Alert.Heading>
                  <p hidden={MessageType === "danger" ? true : false}>
                  Thank you! You can now close this tab or window.
                  </p>
              </Alert>
          </Modal.Body>
          <Modal.Footer hidden={MessageType === "danger" ? false : true}>
              <Button variant="secondary" onClick={handleClose}>
                  Continue
              </Button>
          </Modal.Footer>
      </Modal>
    </section>
  );
}

