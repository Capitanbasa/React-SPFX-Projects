/* tslint:disable */
require("./Pco.module.css");
const styles = {
  pco: 'pco_e0079630',
  teams: 'teams_e0079630',
  welcome: 'welcome_e0079630',
  welcomeImage: 'welcomeImage_e0079630',
  links: 'links_e0079630',
  required: 'required_e0079630',
  divDropArea: 'divDropArea_e0079630'
};

export default styles;
/* tslint:enable */