import * as React from 'react';
import styles from './Pco.module.scss';
import type { IPcoProps } from './IPcoProps';
//import { escape } from '@microsoft/sp-lodash-subset';
import { Alert, Button, Card, Col, Container, Form, Modal, Row, Spinner } from 'react-bootstrap';
import { DatePicker } from 'antd';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup";
import { getSP } from '../pnpjsConfig';
import { IAttachmentInfo } from '@pnp/sp/attachments';
import addFilesPromise from '../utils/addFilesPromise';
import { PprcReviewFormSchema, pcrReviewFormSchema } from '../utils/types';
import WorkFlowSubmit from '../utils/Submit';
import { IoDocumentAttachOutline } from "react-icons/io5";
import { IPeoplePickerContext, PeoplePicker, PrincipalType } from '@pnp/spfx-controls-react/lib/PeoplePicker';
import * as dayjs from 'dayjs';



export default function PRCreatorReview(Props:IPcoProps):React.ReactElement{
    const [ShowSuccess, setShowSuccess] = React.useState( false );
    const [message, setmessage]= React.useState( "" );
    const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
    const [CCGroup, setCCGroup ] = React.useState(false);
    const [nextStage , setnextStage] = React.useState("");
    const [theAttachmentFiles, settheAttachmentFiles] = React.useState<IAttachmentInfo[]>([]);
    const [NRTC, setNRTC] = React.useState(true);
    const [NUND, setNUND] = React.useState(true);
    const [ModalShow, setModalShow ] = React.useState(false);
    const handleClose = ():void => setModalShow(false);

    const peoplePickerContext: IPeoplePickerContext = {
        absoluteUrl: Props.spContext.pageContext.web.absoluteUrl,
        msGraphClientFactory: Props.spContext.msGraphClientFactory,
        spHttpClient: Props.spContext.spHttpClient
    };

    const { 
        register, 
        handleSubmit,
        formState: {errors, isSubmitting},
        reset, setValue
      } = useForm<PprcReviewFormSchema>({
        resolver: yupResolver(pcrReviewFormSchema),
    });

    /* eslint-disable  @typescript-eslint/no-explicit-any */
    const _getPeoplePickerDelegate = (items:any[]):void => {
        console.log("Delegated User:",items );
        items.map((item) => { 
          setValue("DelegatedTo", item.loginName);
        });
    }

    const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
        if(FileAttachment && FileAttachment?.length > 0){
            for(let i =0; i < FileAttachment.length; i++){
                /* eslint-disable no-useless-escape */
                const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
                if(match){
                    setShowSuccess(true);
                    setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
                    setMessageType('danger');
                    return true;
                }else{
                    return false;
                }
            }
        }
        return false;
    }


    const onSubmit = async (data: PprcReviewFormSchema):Promise<void> => {
        const sp = getSP(Props.spContext);
        const Attachment = document.getElementById("FileAttachment") as HTMLInputElement;
        const Attfiles = Attachment.files;
        if(filenameCharValidation(Attfiles)){ return; }

        data.CCUser = CCGroup === true ? "Yes": "No";
        data.Flag = "2";
        console.log("Schema Data:", data);
         
        let newStage: string = "";
        let newStatus:string;
            switch(data.Stage){
            case "Request PM Review":  newStatus = "Pending";  newStage = "PM 2nd Review"; break;
            case "Void":   newStatus = "Void"; newStage = "Void"; break;
            case "Ready for PR Creation":  newStatus = "Pending"; newStage = "PR Creation"; break;
            case "Delegate":  data.Stage = "PR Creator Review"; newStatus = "Delegate"; break;
            default: newStatus = "Pending"; 
            }
        data.Status = newStatus;
        data.Stage = newStage;

        await sp.web.lists.getByTitle(Props.PanePropsIPcoList).items.getById(parseInt(Props.spPCOListItems[0].Id)).update(data)
        .then(async (addResult) => {
            console.log("add result:",addResult);

            if(Attfiles && Attfiles?.length > 0){
                const PromoseArray = [];
                setShowSuccess(true);
                setmessage("Please wait while we upload the file Attachment.");
                setMessageType('warning');
                for(let i =0; i < Attfiles.length; i++){
                const UploadArray = await addFilesPromise( Props.PanePropsIPcoList, parseInt(Props.spPCOListItems[0].Id) ,Attfiles, i);
                PromoseArray.push(UploadArray);
                }

                Promise.all(PromoseArray).then( res => { 
                    console.log("Promise Upload resolve:", res);
                    setShowSuccess(true);
                    setmessage("Successfully Submitted Your Request.");
                    setMessageType('success');
                    reset();
                })
                .catch(err => { 
                    console.log("Promise Upload reject:", err);
                    setShowSuccess(true);
                    setmessage("Your Request is Submitted but there was a problem uploading the attachment");
                    setMessageType('danger');
                    reset();
                });
            }else{
                setShowSuccess(true);
                setmessage("Successfully Submitted Your Request without Attachment.");
                setMessageType('warning');
                reset();
            }
            const WFresult = await WorkFlowSubmit(Props.spPCOListItems[0].Id.toString(), false, newStatus, data.Stage, "2");
            console.log("WF Result:", WFresult);
            reset();
            setModalShow(true);
            return Promise.resolve;
        }).catch( (error) => {
            console.log("Error Submit:", error);
            setShowSuccess(true);
            setmessage("Sorry! Your Request failed to Submit. Please try again.");
                setMessageType('danger');
            return Promise.reject;
        });
            
    };

    let attachments: IAttachmentInfo[] = [];
    React.useEffect(() => {
        async function fecthData():Promise<void>{
        const sp = getSP();
        const item = sp.web.lists.getByTitle(Props.PanePropsIPcoList).items.getById(parseInt(Props.spPCOListItems[0].Id));
        attachments = await item.attachmentFiles().then(async res => {return await res});
        settheAttachmentFiles(attachments);
        console.log("await:",attachments);
        setValue("NeedByDate", Props.spPCOListItems[0].NeedByDate ,  { shouldValidate: false });
        setValue("PromiseDate", Props.spPCOListItems[0].PromiseDate ,  { shouldValidate: false });
        }
        fecthData().catch(console.error);
    },[]);

    return(
        <section className={`${styles.pco} ${Props.hasTeamsContext ? styles.teams : ''}`}>
            <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
                <fieldset disabled={Props.spView}>
                    <Container>
                        <Card>
                            <Card.Header className="h5">Purchase Change Order (PCO) - PR Creator Review</Card.Header>
                                <Card.Body>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Project Number and Name</Form.Label>
                                                <Form.Control type="text" defaultValue={Props.spPCOListItems[0].ProjectName} disabled/>
                                            </Form.Group>
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Instance Number</Form.Label>
                                                <Form.Control type="text" defaultValue={Props.spPCOListItems[0].Id} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Requester Name</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].RequesterName} disabled/>
                                            </Form.Group>
                        
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Requester Email</Form.Label>
                                                <Form.Control type="email"  defaultValue={Props.spPCOListItems[0].RequesterEmail} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Subject</Form.Label>
                                                <Form.Control type="text" defaultValue={Props.spPCOListItems[0].Subject} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Vendor</Form.Label>
                                                <Form.Control type="text" defaultValue={Props.spPCOListItems[0].Vendor} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>PCO Description</Form.Label>
                                                <Form.Control as="textarea"  defaultValue={Props.spPCOListItems[0].PCODescription} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Due Date</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].DueDate} disabled/>
                                            </Form.Group>
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Contractor PCO Number</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ContractorPCONumber} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Contractor PCO Document (link to SharePoint)</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ContractorPCODocument} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Estimated Work Completion</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].EstimatedWorkCompletion} disabled/>
                                            </Form.Group>
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Zero Cost PCO</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ZeroCostPCO} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Can we request a Change Order to the client in regards to this PCO?</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].CanWeRequestaChangeOrdertotheCli} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>If no, provide feedback of source to the change.</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].IfNoProvideFeedbackofSourcetothe} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Schedule Impact</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ScheduleImpact} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Schedule Impact Notes</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ScheduleImpactNotes} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row clssname="mb-3">
                                        <Col>
                                        <Card style={{ width: '100%'}}>
                                            <Card.Header className="h5">Commitments</Card.Header>
                                                <Card.Body>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3" >
                                                                <Form.Label>Commitment Name</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].CommitmentName} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>PO Number</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].PONumber} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3" >
                                                                <Form.Label>PCO Amount</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].PCOAmount} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>Reason Code</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ReasonCode} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label># PCO Line Items</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].PCOLineItems} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>Line Item 1</Form.Label>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>Task Code</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].TaskCodeItem1} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>InitialForecastAmount</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].InitialAmountItem1} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>FinalCommitmentAmount</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].FinalAmountItem1} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>Description</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].DescriptionItem1} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>Line Item 2</Form.Label>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>Task Code</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].TaskCodeItem2} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>InitialForecastAmount</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].InitialAmountItem2} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>FinalCommitmentAmount</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].FinalAmountItem2} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>Description</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].DescriptionItem2} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>Line Item 3</Form.Label>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>Task Code</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].TaskCodeItem3} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>InitialForecastAmount</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].InitialAmountItem3} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>FinalCommitmentAmount</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].FinalAmountItem3} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label>Description</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].DescriptionItem3} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                </Card.Body>
                                        </Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label className={styles.required}>Need to revise task code?</Form.Label>
                                                <Form.Select aria-label="Please Select" 
                                                    {...register("NeedtoReviseTaskCode")} 
                                                    isInvalid={!!errors.NeedtoReviseTaskCode }
                                                    onChange={(e) => { setNRTC(e.currentTarget.value === "No" ? true : false)}}>
                                                    <option key='nrtcno' value="No">No</option> 
                                                    <option key='nrtcyes' value="Yes">Yes</option>
                                                </Form.Select>
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.NeedtoReviseTaskCode?.message}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                        <Col hidden={NRTC}>
                                            <Form.Group className="mb-3" >
                                                <Form.Label className={styles.required}>Reason for cost code revision</Form.Label>
                                                <Form.Control type="text" id="txtReasonforCostCodeRevision" {...register("ReasonforCostCodeRevision")} isInvalid={!!errors.ReasonforCostCodeRevision }/>
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.ReasonforCostCodeRevision?.message}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row className="mb-5">
                                        <Col>
                                            <Card style={{ width: '100%' }}>
                                                <Card.Header>Initiator Attachments</Card.Header>
                                                    <Card.Body>
                                                        <div className="d-grid gap-2">
                                                        {
                                                            theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                                                            return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                                                            })
                                                        }
                                                        </div>
                                                    </Card.Body>
                                            </Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Label>Special Instructions for Procurement</Form.Label>
                                            <Form.Group className="mb-3">
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].SpecialInstructionsProcurement} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Label className={styles.required}>Description of Root Cause</Form.Label>
                                            <Form.Group className="mb-3">
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].DescriptionofRootCause} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label className={styles.required}>Need to update Need by Date?</Form.Label>
                                                <Form.Select aria-label="Please Select" 
                                                    {...register("NeedtoUpdate")} 
                                                    isInvalid={!!errors.NeedtoUpdate }
                                                    onChange={(e) => { setNUND(e.currentTarget.value === "Yes" ? false : true)}}>
                                                    <option key='nundno' value="No">No</option> 
                                                    <option key='nundyes' value="Yes">Yes</option>
                                                </Form.Select>
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.NeedtoUpdate?.message}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label className={styles.required}>Need by Date</Form.Label>
                                                <DatePicker 
                                                    disabled={NUND}
                                                    className='form-control' 
                                                    allowClear={true}
                                                    format={"MMM DD, YYYY"}
                                                    {...register("NeedByDate")}
                                                    defaultValue={dayjs(Props.spPCOListItems[0].NeedByDate, "MMM DD, YYYY")}
                                                    onChange={(e): void => {  if(e){ setValue("NeedByDate", e.format("MMM DD, YYYY").toString(),  { shouldValidate: true }) } }} />
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.NeedByDate?.message}
                                                </Form.Control.Feedback>
                                                <p className="link-danger">{errors.NeedByDate?.message}</p>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" hidden={NUND}>
                                                <Form.Label className={styles.required}>Procurement Reason on changing the Need by Date</Form.Label>
                                                <Form.Control as="textarea" {...register("ProcurementReasonChange")} isInvalid={ !!errors.ProcurementReasonChange }/>
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.ProcurementReasonChange?.message}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row className="mb-5">
                                        <Col>
                                            <Card style={{ width: '100%' }}>
                                                <Card.Header>CC Users</Card.Header>
                                                    <Card.Body>
                                                        <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                                                            <Form.Group className="mb-3" >
                                                            <Form.Check
                                                                inline
                                                                label="Yes"
                                                                value="true"
                                                                {...register("CCUser")} 
                                                                onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}/>
                                                            </Form.Group>
                                                            <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                                                                <Form.Label className={styles.required}>Email Addresses</Form.Label>
                                                                <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails } defaultValue={Props.spPCOListItems[0].CCEmails}/>
                                                                <Form.Control.Feedback type="invalid">
                                                                    {errors.CCEmails?.message}
                                                                </Form.Control.Feedback>
                                                            </Form.Group>
                                                            <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                                                                <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                                                                <Form.Control as="textarea" rows={3} {...register("CCComment")} defaultValue={Props.spPCOListItems[0].CCComment}/>
                                                            </Form.Group>
                                                </Card.Body>
                                            </Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-5">
                                                <Form.Label >Attachments</Form.Label>
                                                <Form.Control type="file" id="FileAttachment" multiple />
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-5">
                                                <Form.Label className={styles.required}>Next step</Form.Label>
                                                <Form.Select aria-label="Please Select Next Step" {...register("Stage")} isInvalid={!!errors.Stage } onChange={(e)=>{setnextStage(e.currentTarget.value )}} >
                                                    <option value="">Please Select Next Step</option>
                                                    <option key='ns1' value="Request PM Review">Request PM Review</option>
                                                    <option key='ns2' value="Void">Void</option>
                                                    <option key='ns3' value="Ready for PR Creation">Ready for PR Creation</option>
                                                    <option key='ns4' value="Delegate">Delegate</option>
                                                </Form.Select>
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.Stage?.message}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-5" hidden={nextStage === "Request PM Review" ? false: true}>
                                                <Form.Label className={styles.required}>Comments</Form.Label>
                                                <Form.Control as="textarea" rows={3} defaultValue={Props.spPCOListItems[0].RequestPMRComments} {...register("RequestPMRComments")} isInvalid={!!errors.RequestPMRComments }/>
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.RequestPMRComments?.message}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-5" hidden={nextStage === "Void" ? false: true}>
                                                <Form.Label className={styles.required}>Comments</Form.Label>
                                                <Form.Control as="textarea" rows={3} defaultValue={Props.spPCOListItems[0].VoidComments} {...register("VoidComments")} isInvalid={!!errors.VoidComments }/>
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.VoidComments?.message}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-5" hidden={nextStage === "Ready for PR Creation" ? false: true}>
                                                <Form.Label className={styles.required}>PCO Type</Form.Label>
                                                <Form.Select aria-label="Please Select" {...register("PCOType")} isInvalid={!!errors.PCOType }
                                                defaultValue={Props.spPCOListItems[0].PCOType}>
                                                    <option value="">Please Select</option>
                                                    <option key='pco1' value="Deductive Change Order">Deductive Change Order</option>
                                                    <option key='pco2' value="PO Increase">PO Increase</option>
                                                    <option key='pco3' value="N/A">N/A</option> 
                                                </Form.Select>
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.PCOType?.message}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-5" hidden={nextStage === "Ready for PR Creation" ? false: true}>
                                                <Form.Label className={styles.required}>SPWR Executed CO Number</Form.Label>
                                                <Form.Control type="text" {...register("SPWRExecutedCONumber")} isInvalid={ !!errors.SPWRExecutedCONumber }
                                                defaultValue={Props.spPCOListItems[0].SPWRExecutedCONumber}/>
                                                <Form.Control.Feedback type="invalid">
                                                {errors.SPWRExecutedCONumber?.message}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-5" hidden={nextStage === "Ready for PR Creation" ? false: true}>
                                                <Form.Label className={styles.required}>Pricing Methodology</Form.Label>
                                                <Form.Select aria-label="Please Select" {...register("PricingMethodology")} isInvalid={!!errors.PricingMethodology }
                                                defaultValue={Props.spPCOListItems[0].PricingMethodology}>
                                                    <option value="">Please Select</option>
                                                    <option key='p1' value="No Change">No Change</option>
                                                    <option key='pm2' value="Cost Plus A Fee (GPM)">Cost Plus A Fee (GPM)</option>
                                                    <option key='pm3' value="Unit Price">Unit Price</option>
                                                    <option key='pm4' value="Lump Sum">Lump Sum</option> 
                                                    <option key='pm5' value="Time & Materials (NTE)">Time & Materials (NTE)</option>  
                                                </Form.Select>
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.PricingMethodology?.message}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-5" hidden={nextStage === "Ready for PR Creation" ? false: true}>
                                                <Form.Label className={styles.required}>Promise Date</Form.Label>
                                                <DatePicker 
                                                    className='form-control' 
                                                    allowClear={true}
                                                    format={"MMM DD, YYYY"}
                                                    minDate={dayjs()}
                                                    {...register("PromiseDate")}
                                                    onChange={(e): void => {  if(e){ setValue("PromiseDate", e.format("MMM DD, YYYY").toString(),  { shouldValidate: true }) } }}
                                                    //defaultValue={dayjs(Props.spPCOListItems[0].PromiseDate, "MMM DD, YYYY")} remove default since this stage will populate the date
                                                    />
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.PromiseDate?.message}
                                                </Form.Control.Feedback>
                                                <p className="link-danger">{errors.PromiseDate?.message}</p>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-5" hidden={nextStage === "Delegate" ? false: true}>
                                                <PeoplePicker
                                                    {...register("DelegatedTo")}
                                                    context={peoplePickerContext}
                                                    titleText="Delegation Email"
                                                    personSelectionLimit={1}
                                                    showtooltip={true}
                                                    required={true}
                                                    ensureUser={true}
                                                    onChange={ items => _getPeoplePickerDelegate(items) }
                                                    principalTypes={[PrincipalType.User]}
                                                    resolveDelay={1000} />
                                                <p className="link-danger">{errors.DelegatedTo?.message}</p>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row className="mb-4">
                                        <Col>
                                            <div className="d-grid gap-2">
                                                <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting } >
                                                    <Spinner
                                                        as="span"
                                                        animation="border"
                                                        size="sm"
                                                        role="status"
                                                        aria-hidden={ !!isSubmitting }
                                                        className={ "visually-hidden" } />
                                                    { isSubmitting ? "...Submitting" : "SUBMIT" }
                                                </Button>
                                            </div>
                                        </Col>
                                    </Row>
                                    { ShowSuccess && (
                                        <Alert 
                                        key={ MessageType } 
                                        variant={ MessageType } 
                                        dismissible 
                                        onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                                            { message }
                                        </Alert>
                                    )}
                            </Card.Body>
                        </Card>
                    </Container>
                </fieldset>
            </form>
            <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
                <Modal.Header>
                    <Modal.Title>SharePoint</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Alert variant="primary">
                        <Alert.Heading>{ message }</Alert.Heading>
                        <p hidden={MessageType === "danger" ? true : false}>
                        Thank you! You can now close this tab or window.
                        </p>
                    </Alert>
                </Modal.Body>
                <Modal.Footer hidden={MessageType === "danger" ? false : true}>
                    <Button variant="secondary" onClick={handleClose}>
                        Continue
                    </Button>
                </Modal.Footer>
            </Modal>
        </section>
    );
}



