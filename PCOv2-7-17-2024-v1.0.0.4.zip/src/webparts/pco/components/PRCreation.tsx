import * as React from 'react';
import styles from './Pco.module.scss';
import type { IPcoProps } from './IPcoProps';
//import { escape } from '@microsoft/sp-lodash-subset';
import { Alert, Button, Card, Col, Container, Form, Modal, Row, Spinner } from 'react-bootstrap';
import { DatePicker } from 'antd';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup";
import { getSP } from '../pnpjsConfig';
import { IAttachmentInfo } from '@pnp/sp/attachments';
import addFilesPromise from '../utils/addFilesPromise';
import { PprCreationFormSchema, prCreationFormSchema } from '../utils/types';
import WorkFlowSubmit from '../utils/Submit';
import { IoDocumentAttachOutline } from "react-icons/io5";
import * as dayjs from 'dayjs';



export default function PRCreation(Props:IPcoProps):React.ReactElement{
    const [ShowSuccess, setShowSuccess] = React.useState( false );
    const [message, setmessage]= React.useState( "" );
    const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
    const [CCGroup, setCCGroup ] = React.useState(false);
    const [nextStage , setnextStage] = React.useState("");
    const [theAttachmentFiles, settheAttachmentFiles] = React.useState<IAttachmentInfo[]>([]);
    const [ModalShow, setModalShow ] = React.useState(false);
    const handleClose = ():void => setModalShow(false);

    const { 
        register, 
        handleSubmit,
        formState: {errors, isSubmitting},
        reset, setValue
      } = useForm<PprCreationFormSchema>({
        resolver: yupResolver(prCreationFormSchema),
      });
    
    const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
        if(FileAttachment && FileAttachment?.length > 0){
            for(let i =0; i < FileAttachment.length; i++){
                /* eslint-disable no-useless-escape */
                const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
                if(match){
                    setShowSuccess(true);
                    setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
                    setMessageType('danger');
                    return true;
                }else{
                    return false;
                }
            }
        }
        return false;
    }

    const onSubmit = async (data: PprCreationFormSchema):Promise<void> => {
        const sp = getSP(Props.spContext);
        const Attachment = document.getElementById("FileAttachment") as HTMLInputElement;
        const Attfiles = Attachment.files;
        if(filenameCharValidation(Attfiles)){ return; }

        data.CCUser = CCGroup === true ? "Yes": "No";
        data.Flag = "2";
        console.log("Schema Data:", data);

        let newStage: string = "";
        let newStatus:string;
            switch(data.Stage){
            case "PR Rejected":  newStatus = "Void";  newStage = "Void"; break;
            case "PR Approved":   newStatus = "PR Approved"; newStage = "PO Creation"; break;
            case "Initiator Revision":   newStatus = "Pending"; newStage = "Initiator Revision"; break;
            default: newStatus = "Pending"; 
        }
        data.Status = newStatus;
        data.Stage = newStage;

        await sp.web.lists.getByTitle(Props.PanePropsIPcoList).items.getById(parseInt(Props.spPCOListItems[0].Id)).update(data)
        .then(async (addResult) => {
            console.log("add result:",addResult);

            if(Attfiles && Attfiles?.length > 0){
                const PromoseArray = [];
                setShowSuccess(true);
                setmessage("Please wait while we upload the file Attachment.");
                setMessageType('warning');
                for(let i =0; i < Attfiles.length; i++){
                const UploadArray = await addFilesPromise( Props.PanePropsIPcoList, parseInt(Props.spPCOListItems[0].Id) ,Attfiles, i);
                PromoseArray.push(UploadArray);
                }

                Promise.all(PromoseArray).then( res => { 
                    console.log("Promise Upload resolve:", res);
                    setShowSuccess(true);
                    setmessage("Successfully Submitted Your Request.");
                    setMessageType('success');
                    reset();
                })
                .catch(err => { 
                    console.log("Promise Upload reject:", err);
                    setShowSuccess(true);
                    setmessage("Your Request is Submitted but there was a problem uploading the attachment");
                    setMessageType('danger');
                    reset();
                });
            }else{
                setShowSuccess(true);
                setmessage("Successfully Submitted Your Request without Attachment.");
                setMessageType('warning');
                reset();
            }
            const WFresult = await WorkFlowSubmit(Props.spPCOListItems[0].Id.toString(), false, newStatus, data.Stage, "2");
            console.log("WF Result:", WFresult);
            reset();
            setModalShow(true);
            return Promise.resolve;
        }).catch( (error) => {
            console.log("Error Submit:", error);
            setShowSuccess(true);
            setmessage("Sorry! Your Request failed to Submit. Please try again.");
                setMessageType('danger');
            return Promise.reject;
        });
            
    };

    let attachments: IAttachmentInfo[] = [];
    React.useEffect(() => {
        async function fecthData():Promise<void>{
        const sp = getSP();
        const item = sp.web.lists.getByTitle(Props.PanePropsIPcoList).items.getById(parseInt(Props.spPCOListItems[0].Id));
        attachments = await item.attachmentFiles().then(async res => {return await res});
        settheAttachmentFiles(attachments);
        console.log("await:",attachments);
        }
        fecthData().catch(console.error);
    },[]);

    return(
        <section className={`${styles.pco} ${Props.hasTeamsContext ? styles.teams : ''}`}>
            <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
                <fieldset disabled={Props.spView}>
                    <Container>
                        <Card>
                            <Card.Header className="h5">Purchase Change Order (PCO) - PR Creation</Card.Header>
                                <Card.Body>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Project Number and Name</Form.Label>
                                                <Form.Control type="text" defaultValue={Props.spPCOListItems[0].ProjectName} disabled/>
                                            </Form.Group>
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Instance Number</Form.Label>
                                                <Form.Control type="text" defaultValue={Props.spPCOListItems[0].Id} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Requester Name</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].RequesterName} disabled/>
                                            </Form.Group>
                        
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Requester Email</Form.Label>
                                                <Form.Control type="email"  defaultValue={Props.spPCOListItems[0].RequesterEmail} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Subject</Form.Label>
                                                <Form.Control type="text" defaultValue={Props.spPCOListItems[0].Subject} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Vendor</Form.Label>
                                                <Form.Control type="text" defaultValue={Props.spPCOListItems[0].Vendor} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Does the contact need a copy of the PO?</Form.Label>
                                                <Form.Control type="textarea"  defaultValue={Props.spPCOListItems[0].DoestheContactneedaCopyofthePO} disabled/>
                                            </Form.Group>
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Is this contact a replacement of the previous PO receiver?</Form.Label>
                                                <Form.Control type="textarea"  defaultValue={Props.spPCOListItems[0].IsthisContactaReplacementofthePr} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>If Contact Replacement, please specify the contact to be removed</Form.Label>
                                                <Form.Control type="textarea"  defaultValue={Props.spPCOListItems[0].ContacttoRemoved} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>PCO Description</Form.Label>
                                                <Form.Control type="textarea"  defaultValue={Props.spPCOListItems[0].PCODescription} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Due Date</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].DueDate} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Contractor PCO Number</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ContractorPCONumber} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Contractor PCO Document (link to SharePoint)</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ContractorPCODocument} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Estimated Work Completion</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].EstimatedWorkCompletion} disabled/>
                                            </Form.Group>
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Zero Cost PCO</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ZeroCostPCO} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Schedule Impact</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ScheduleImpact} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Schedule Impact Notes</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ScheduleImpactNotes} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row clssname="mb-3">
                                        <Col>
                                        <Card className="mb-3" style={{ width: '100%'}}>
                                            <Card.Header className="h5">Commitments</Card.Header>
                                                <Card.Body>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3" >
                                                                <Form.Label className={styles.required}>Commitment Name</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].CommitmentName} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label className={styles.required}>PO Number</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].PONumber} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3" >
                                                                <Form.Label className={styles.required}>PCO Amount</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].PCOAmount} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label className={styles.required}>Reason Code</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ReasonCode} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                </Card.Body>
                                        </Card>
                                        </Col>
                                    </Row>
                                    <Card className="mb-3" style={{ width: '100%'}}><Card.Header className="h5">Line Item 1</Card.Header>
                                        <Card.Body>
                                            <Row>
                                                <Col>
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>Task Code</Form.Label>
                                                        <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].TaskCodeItem1} disabled/>
                                                    </Form.Group>
                                                </Col>
                                                <Col>
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>InitialForecastAmount</Form.Label>
                                                        <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].InitialAmountItem1} disabled/>
                                                    </Form.Group>
                                                </Col>
                                                <Col>
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>FinalCommitmentAmount</Form.Label>
                                                        <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].FinalAmountItem1} disabled/>
                                                    </Form.Group>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col>
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>Description</Form.Label>
                                                        <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].DescriptionItem1} disabled/>
                                                    </Form.Group>
                                                </Col>
                                            </Row>
                                        </Card.Body>
                                    </Card>
                                    <Card className="mb-3" style={{ width: '100%'}}><Card.Header className="h5">Line Item 2</Card.Header>
                                        <Card.Body>
                                            <Row>
                                                <Col>
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>Task Code</Form.Label>
                                                        <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].TaskCodeItem2} disabled/>
                                                    </Form.Group>
                                                </Col>
                                                <Col>
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>InitialForecastAmount</Form.Label>
                                                        <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].InitialAmountItem2} disabled/>
                                                    </Form.Group>
                                                </Col>
                                                <Col>
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>FinalCommitmentAmount</Form.Label>
                                                        <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].FinalAmountItem2} disabled/>
                                                    </Form.Group>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col>
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>Description</Form.Label>
                                                        <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].DescriptionItem2} disabled/>
                                                    </Form.Group>
                                                </Col>
                                            </Row>
                                        </Card.Body>
                                    </Card>
                                    <Card className="mb-3" style={{ width: '100%'}}><Card.Header className="h5">Line Item 3</Card.Header>
                                        <Card.Body>
                                            <Row>
                                                <Col>
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>Task Code</Form.Label>
                                                        <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].TaskCodeItem3} disabled/>
                                                    </Form.Group>
                                                </Col>
                                                <Col>
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>InitialForecastAmount</Form.Label>
                                                        <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].InitialAmountItem3} disabled/>
                                                    </Form.Group>
                                                </Col>
                                                <Col>
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>FinalCommitmentAmount</Form.Label>
                                                        <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].FinalAmountItem3} disabled/>
                                                    </Form.Group>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col>
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>Description</Form.Label>
                                                        <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].DescriptionItem3} disabled/>
                                                    </Form.Group>
                                                </Col>
                                            </Row>
                                        </Card.Body>
                                    </Card>    
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Need by Date</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].NeedByDate} disabled/>
                                            </Form.Group>
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-3" >
                                                <Form.Label>Procurement Reason for Need By Date Update</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].ProcurementReasonChange} disabled/>
                                            </Form.Group>
                                        </Col>       
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-3">
                                                <Form.Label>Description of Root Cause</Form.Label>
                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].DescriptionofRootCause} disabled/>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row clssname="mb-3">
                                        <Col>
                                        <Card style={{ width: '100%'}}>
                                            <Card.Header className="h5">Ready for PR Creation</Card.Header>
                                                <Card.Body>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3" >
                                                                <Form.Label className={styles.required}>PCO Type</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].PCOType} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label className={styles.required}>SPWR Executed CO Numer</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].SPWRExecutedCONumber} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col>
                                                            <Form.Group className="mb-3" >
                                                                <Form.Label className={styles.required}>Pricing Methodology</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].PricingMethodology} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                        <Col>
                                                            <Form.Group className="mb-3">
                                                                <Form.Label className={styles.required}>Promise Date</Form.Label>
                                                                <Form.Control type="text"  defaultValue={Props.spPCOListItems[0].PromiseDate} disabled/>
                                                            </Form.Group>
                                                        </Col>
                                                    </Row>
                                                </Card.Body>
                                        </Card>
                                        </Col>
                                    </Row>
                                    <Row className="mb-5">
                                        <Col>
                                            <Card style={{ width: '100%' }}>
                                                <Card.Header>Initiator Attachments</Card.Header>
                                                    <Card.Body>
                                                        <div className="d-grid gap-2">
                                                        {
                                                            theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                                                            return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                                                            })
                                                        }
                                                        </div>
                                                    </Card.Body>
                                            </Card>
                                        </Col>
                                    </Row>
                                    <Row className="mb-5">
                                        <Col>
                                            <Card style={{ width: '100%' }}>
                                                <Card.Header>CC Users</Card.Header>
                                                    <Card.Body>
                                                        <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                                                            <Form.Group className="mb-3" >
                                                            <Form.Check
                                                                inline
                                                                label="Yes"
                                                                value="true"
                                                                {...register("CCUser")} 
                                                                onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}/>
                                                            </Form.Group>
                                                            <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                                                                <Form.Label className={styles.required}>Email Addresses</Form.Label>
                                                                <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails } defaultValue={Props.spPCOListItems[0].CCEmails}/>
                                                                <Form.Control.Feedback type="invalid">
                                                                    {errors.CCEmails?.message}
                                                                </Form.Control.Feedback>
                                                            </Form.Group>
                                                            <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                                                                <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                                                                <Form.Control as="textarea" rows={3} {...register("CCComment")} defaultValue={Props.spPCOListItems[0].CCComment} />
                                                            </Form.Group>
                                                    </Card.Body>
                                            </Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-5">
                                                <Form.Label >Attachments</Form.Label>
                                                <Form.Control type="file" id="FileAttachment" multiple />
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-5">
                                                <Form.Label className={styles.required}>Next step</Form.Label>
                                                <Form.Select aria-label="Please Select Next Step" {...register("Stage")} isInvalid={!!errors.Stage } onChange={(e)=>{setnextStage(e.currentTarget.value )}} >
                                                    <option value="">Please Select Next Step</option>
                                                    <option key='ns1' value="PR Rejected">PR Rejected</option>
                                                    <option key='ns2' value="PR Approved">PR Approved</option>
                                                    <option key='ns3' value="Initiator Revision">Initiator Revision</option>
                                                </Form.Select>
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.Stage?.message}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-5" hidden={nextStage === "PR Rejected" ? false: true}>
                                                <Form.Label className={styles.required}>Comments</Form.Label>
                                                <Form.Control as="textarea" rows={3} defaultValue={Props.spPCOListItems[0].PRRejectedComments} {...register("PRRejectedComments")} isInvalid={!!errors.PRRejectedComments }/>
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.PRRejectedComments?.message}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-5" hidden={nextStage === "PR Approved" ? false: true}>
                                                <Form.Label className={styles.required}>PR Number</Form.Label>
                                                <Form.Control type="textarea"  defaultValue={Props.spPCOListItems[0].VoidComments} {...register("PRNumber")} isInvalid={!!errors.PRNumber }/>
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.PRNumber?.message}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                        <Col>
                                            <Form.Group className="mb-5" hidden={nextStage === "PR Approved" ? false: true}>
                                                <Form.Label className={styles.required}>Date PR Entered</Form.Label>
                                                <DatePicker 
                                                        className='form-control' 
                                                        allowClear={true}
                                                        format={"MMM DD, YYYY"}
                                                        minDate={dayjs()}
                                                        {...register("DatePREntered") } 
                                                        onChange={(e): void => {  if(e){ setValue("DatePREntered", e.format("MMM DD, YYYY").toString(),  { shouldValidate: true }) } }} />
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.DatePREntered?.message}
                                                </Form.Control.Feedback>
                                                <p className="link-danger">{errors.DatePREntered?.message}</p>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <Form.Group className="mb-5" hidden={nextStage === "Initiator Revision" ? false: true}>
                                                <Form.Label className={styles.required}>Comments-Revise</Form.Label>
                                                <Form.Control as="textarea" rows={3} defaultValue={Props.spPCOListItems[0].CommentsRevise} {...register("CommentsRevise")} isInvalid={!!errors.CommentsRevise }/>
                                                <Form.Control.Feedback type="invalid">
                                                    {errors.CommentsRevise?.message}
                                                </Form.Control.Feedback>
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <Row className="mb-4">
                                        <Col>
                                            <div className="d-grid gap-2">
                                                <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting } >
                                                    <Spinner
                                                        as="span"
                                                        animation="border"
                                                        size="sm"
                                                        role="status"
                                                        aria-hidden={ !!isSubmitting }
                                                        className={ "visually-hidden" } />
                                                    { isSubmitting ? "...Submitting" : "SUBMIT" }
                                                </Button>
                                            </div>
                                        </Col>
                                    </Row>
                                    { ShowSuccess && (
                                        <Alert 
                                        key={ MessageType } 
                                        variant={ MessageType } 
                                        dismissible 
                                        onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                                            { message }
                                        </Alert>
                                    )}
                            </Card.Body>
                        </Card>
                    </Container>
                </fieldset>
            </form>
            <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
                <Modal.Header>
                    <Modal.Title>SharePoint</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Alert variant="primary">
                        <Alert.Heading>{ message }</Alert.Heading>
                        <p hidden={MessageType === "danger" ? true : false}>
                        Thank you! You can now close this tab or window.
                        </p>
                    </Alert>
                </Modal.Body>
                <Modal.Footer hidden={MessageType === "danger" ? false : true}>
                    <Button variant="secondary" onClick={handleClose}>
                        Continue
                    </Button>
                </Modal.Footer>
            </Modal>
        </section>
    );
}



