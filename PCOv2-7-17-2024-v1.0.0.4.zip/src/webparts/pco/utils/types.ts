import * as yup from 'yup';

export const pcoFormSchema = yup.object().shape({
    Flag: yup.string().notRequired(),
    Stage: yup.string().default("PM Review").notRequired(),
    Status: yup.string().default("Pending").notRequired(),
    ProjectType: yup.string().notRequired(),
    ProjectName: yup.string().required("Project Number - Project Name is required"),
    RequesterName: yup.string().required("Requester Name is required"),
    RequesterEmail: yup.string().required().email("Requester Email is required"),
    Subject: yup.string().required("Subject is required"),
    ProposedVendor: yup.string().required("Vendor First Initial Range is required"),
    Vendor: yup.string().required("Vendor is required"),
    DoestheContactneedaCopyofthePO: yup.string().notRequired(),
    IsthisContactaReplacementofthePr: yup.string().notRequired(),
    PCODescription: yup.string().required("PCO Description is required"),
    DueDate: yup.string().required("Due Date is required"),
    ContractorPCONumber: yup.string().notRequired(),
    ContractorPCODocument: yup.string().notRequired(),
    EstimatedWorkCompletion: yup.string().required("Estimated Work Completion is required"),
    IsContractorPerformingWorkonSite: yup.string().required("Is Contractor Performing Work on Site? is required"),
    ZeroCostPCO: yup.string().notRequired(),
    RelatedRFI: yup.string().notRequired(),
    CanWeRequestaChangeOrdertotheCli: yup.string().required("Can we request a Change Order to the client in regards to this PCO is required"),
    IfNoProvideFeedbackofSourcetothe: yup.string().when("CanWeRequestaChangeOrdertotheCli", {is: (cwrco:string) => cwrco === "No", then: () => yup.string().required("If NO, provide Feedback of source to the change is required"), otherwise: () => yup.string().notRequired()}),
    ScheduleImpact: yup.string().required("Schedule Impact is required"),
    ScheduleImpactNotes: yup.string().required("Schedule Impact Notes is required"),
    CommitmentName: yup.string().required("Commitment Name is required"),
    PONumber:yup.string().required("PO Number is required"),
    PCOAmount: yup.string().typeError("PCO Amount must be a number").min(0.1, "PCO Amount should not be 0 value").required("PCO Amount is required"),
    ReasonCode:yup.string().required("Reason Code is required"),
    PCOLineItems:yup.string().required("PCO Line Items is required"),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    TaskCodeItem2:yup.string().when('PCOLineItems', {is: (itemnumber: string) => itemnumber === "2" || itemnumber === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem2:yup.string().notRequired(),
    DescriptionItem2:yup.string().notRequired(),
    TaskCodeItem1: yup.string().when('PCOLineItems', {is: (itemnumber: string) => itemnumber === "1" || itemnumber === "2" || itemnumber === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem1:yup.string().notRequired(),
    DescriptionItem1:yup.string().notRequired(),
    TaskCodeItem3:yup.string().when('PCOLineItems', {is: (itemnumber: string) => itemnumber === "3" , then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem3:yup.string().notRequired(),
    DescriptionItem3:yup.string().notRequired(),
    ContacttoRemoved: yup.string().when('IsthisContactaReplacementofthePr', {is: (cc: string) => cc==="Yes", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
});

export type PpcoFormSchema = yup.InferType<typeof pcoFormSchema>

export const pcoPMReviewFormSchema = yup.object().shape({
    Flag: yup.string().notRequired(),
    Stage: yup.string().required("Next step is required"),
    Status: yup.string().notRequired(),
    CommitmentName: yup.string().required("Commitment Name is required"),
    PONumber:yup.string().required("PO Number is required"),
    PCOAmount: yup.string().typeError("PCO Amount must be a number").min(0.1, "PCO Amount should not be 0 value").required("PCO Amount is required"),
    ReasonCode:yup.string().required("Reason Code is required"),
    CommentsforInitiator: yup.string().when('Stage', {is: (stage:string) => stage==="Revise", then: () => yup.string().required("Comments for Initiator is required"), otherwise: () => yup.string().notRequired() }),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    NeedByDate:yup.string().when('Stage', {is: (stage:string) => stage==="Approve", then: () => yup.string().required("Need By Date is required"), otherwise: () => yup.string().notRequired() }),
    SpecialInstructionsProcurement: yup.string().when('Stage', {is: (stage:string) => stage==="Approve", then: () => yup.string().required("Special Instruction for Procurement is required"), otherwise: () => yup.string().notRequired() }),
    RelatedRisk: yup.string().notRequired(),
    DescriptionofRootCause:yup.string().when('Stage', {is: (stage:string) => stage==="Approve", then: () => yup.string().required("Description of Root Cause is required"), otherwise: () => yup.string().notRequired() }),
    DelegatedTo: yup.string().when('Stage', {is: (stage:string) => stage==="Delegate", then: () => yup.string().required("Please select a User"), otherwise: () => yup.number().notRequired() }),
});

export type PpcoPMReviewFormSchema = yup.InferType<typeof pcoPMReviewFormSchema>

export const cerFormSchema = yup.object().shape({
    Flag: yup.string().notRequired(),
    Stage: yup.string().required("Next step is required"),
    Status: yup.string().notRequired(),
    PCODescription: yup.string().required("PCO Description is required"),
    DueDate: yup.string().required("Due Date is required"),
    ContractorPCONumber: yup.string().notRequired(),
    ContractorPCODocument: yup.string().notRequired(),
    EstimatedWorkCompletion: yup.string().required("Estimated Work Completion is required"),
    IsContractorPerformingWorkonSite: yup.array().typeError("Is Contractor performing Work on Site is required").min(1, "at least one of the option must be selected"),
    ZeroCostPCO: yup.string().notRequired(),
    RelatedRFI: yup.string().notRequired(),
    CanWeRequestaChangeOrdertotheCli: yup.string().required("Can we request a Change Order to the client in regards to this PCO is required"),
    IfNoProvideFeedbackofSourcetothe: yup.string().required("If NO, provide Feedback of source to the change is required"),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    DelegatedTo: yup.string().when('Stage', {is: (stage:string) => stage==="Delegate", then: () => yup.string().required("Please select a User"), otherwise: () => yup.number().notRequired() }),
    CommentsforPM: yup.string().when('Stage', {is: (stage:string) => stage==="Cost Engineer Review", then: () => yup.string().required("Comments for PM is required"), otherwise: () => yup.string().notRequired() }),
});

export type CcerFormSchema = yup.InferType<typeof cerFormSchema>

export const irFormSchema = yup.object().shape({
    Flag: yup.string().notRequired(),
    Stage: yup.string().required("Next step is required"),
    Status: yup.string().notRequired(),
    DoestheContactneedaCopyofthePO: yup.string().notRequired(),
    IsthisContactaReplacementofthePr: yup.string().notRequired(),
    PCODescription: yup.string().required("PCO Description is required"),
    DueDate: yup.string().required("Due Date is required"),
    ContractorPCONumber: yup.string().notRequired(),
    ContractorPCODocument: yup.string().notRequired(),
    EstimatedWorkCompletion: yup.string().required("Estimated Work Completion is required"),
    IsContractorPerformingWorkonSite: yup.string().required("Is Contractor Performing Work on Site? is required"),
    ZeroCostPCO: yup.string().notRequired(),
    RelatedRFI: yup.string().notRequired(),
    CanWeRequestaChangeOrdertotheCli: yup.string().required("Can we request a Change Order to the client in regards to this PCO is required"),
    IfNoProvideFeedbackofSourcetothe: yup.string().when("CanWeRequestaChangeOrdertotheCli", {is: (cwrco:string) => cwrco === "No", then: () => yup.string().required("If NO, provide Feedback of source to the change is required"), otherwise: () => yup.string().notRequired()}),
    ScheduleImpact: yup.string().required("Schedule Impact is required"),
    ScheduleImpactNotes: yup.string().required("Schedule Impact Notes is required"),
    CommitmentName: yup.string().required("Commitment Name is required"),
    PONumber:yup.string().required("PO Number is required"),
    PCOAmount: yup.string().typeError("PCO Amount must be a number").min(0.1, "PCO Amount should not be 0 value").required("PCO Amount is required"),
    ReasonCode:yup.string().required("Reason Code is required"),
    PCOLineItems:yup.string().required("PCO Line Items is required"),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    TaskCodeItem2:yup.string().when('PCOLineItems', {is: (itemnumber: string) => itemnumber === "2" || itemnumber === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem2:yup.string().notRequired(),
    DescriptionItem2:yup.string().notRequired(),
    TaskCodeItem1: yup.string().when('PCOLineItems', {is: (itemnumber: string) => itemnumber === "1" || itemnumber === "2" || itemnumber === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem1:yup.string().notRequired(),
    DescriptionItem1:yup.string().notRequired(),
    TaskCodeItem3:yup.string().when('PCOLineItems', {is: (itemnumber: string) => itemnumber === "3" , then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem3:yup.string().notRequired(),
    DescriptionItem3:yup.string().notRequired(),
    ContacttoRemoved: yup.string().when('IsthisContactaReplacementofthePr', {is: (cc: string) => cc==="Yes", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
});

export type IirFormSchema = yup.InferType<typeof irFormSchema>

export const pcrReviewFormSchema = yup.object().shape({
    Flag: yup.string().notRequired(),
    Stage: yup.string().required("Next step is required"),
    Status: yup.string().notRequired(),
    ProjectManagerComments: yup.string().notRequired(),
    ProcurementComments: yup.string().notRequired(),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    DelegatedTo: yup.string().when('Stage', {is: (stage:string) => stage==="Delegate", then: () => yup.string().required("Please select a User"), otherwise: () => yup.number().notRequired() }),
    RequestPMRComments: yup.string().when('Stage', {is: (stage:string) => stage==="PR Creator Review", then: () => yup.string().required("Request PM Review is required"), otherwise: () => yup.string().notRequired() }),
    NeedtoReviseTaskCode: yup.string().required("Need to revise task code is required"),
    ReasonforCostCodeRevision: yup.string().when("NeedtoReviseTaskCode", {is: (NRTC:string) => NRTC === "Yes", then: () => yup.string().required("Reason for cost code revision is required"), otherwise: () => yup.string().notRequired()}),
    NeedtoUpdate: yup.string().required("Need to revise task code is required"),
    NeedByDate: yup.string().when('NeedtoUpdate', {is: (NeedUpdate: string) => NeedUpdate ==="Yes", then: () =>  yup.string().required("Need by Date is required"), otherwise: () => yup.string().notRequired() }),
    ProcurementReasonChange: yup.string().when('NeedtoUpdate', {is: (NeedUpdate: string) => NeedUpdate ==="Yes", then: () =>  yup.string().required("Procurement Reason on changing the Need by Date is required"), otherwise: () => yup.string().notRequired() }),
    PCOType:yup.string().when('Stage', {is: (stage:string) => stage==="Ready for PR Creation", then: () => yup.string().required("PCO Type is required"), otherwise: () => yup.string().notRequired() }),
    SPWRExecutedCONumber:yup.string().when('Stage', {is: (stage:string) => stage==="Ready for PR Creation", then: () => yup.string().required("SPWR Executed CO is required"), otherwise: () => yup.string().notRequired() }),
    PricingMethodology:yup.string().when('Stage', {is: (stage:string) => stage==="Ready for PR Creation", then: () => yup.string().required("Pricing Methodology is required"), otherwise: () => yup.string().notRequired() }),
    PromiseDate :yup.string().when('Stage', {is: (stage:string) => stage==="Ready for PR Creation", then: () => yup.string().required("Promise Date is required"), otherwise: () => yup.string().notRequired() }),
    VoidComments: yup.string().when('Stage', {is: (stage:string) => stage==="Void", then: () => yup.string().required("Void Comments is required"), otherwise: () => yup.string().notRequired() }),
});

export type PprcReviewFormSchema = yup.InferType<typeof pcrReviewFormSchema>

export const pm2ReviewFormSchema = yup.object().shape({
    Flag: yup.string().notRequired(),
    Stage: yup.string().required("Next step is required"),
    Status: yup.string().notRequired(),
    ProcurementMngrComts: yup.string().required("Procurement Manager Comments is required"),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    CommentsforPM2ndReview: yup.string().when('Stage', {is: (stage:string) => stage==="PM 2nd Review", then: () => yup.string().required("Comments for PM 2nd Review is required"), otherwise: () => yup.string().notRequired() }),
    VoidComments: yup.string().when('Stage', {is: (stage:string) => stage==="Void", then: () => yup.string().required("Void Comments is required"), otherwise: () => yup.string().notRequired() }),
    PCOLineItems:yup.string().notRequired(),
    InitialAmountItem1: yup.string().when('PCOLineItems', {is: (li:string) => li=== "1" || li === "2" || li === "3", then: () => yup.string().required("Initial Forecast Amount is required"), otherwise: () => yup.string().notRequired() }),
    InitialAmountItem2: yup.string().when('PCOLineItems', {is: (li:string) => li === "2" || li === "3", then: () => yup.string().required("Initial Forecast Amount is required"), otherwise: () => yup.string().notRequired() }),
    InitialAmountItem3: yup.string().when('PCOLineItems', {is: (li:string) => li === "3", then: () => yup.string().required("Initial Forecast Amount is required"), otherwise: () => yup.string().notRequired() }),
    FinalAmountItem1: yup.string().when('PCOLineItems', {is: (li:string) => li=== "1" || li === "2" || li === "3", then: () => yup.string().required("Final Commitment Amount is required"), otherwise: () => yup.string().notRequired() }),
    FinalAmountItem2: yup.string().when('PCOLineItems', {is: (li:string) => li === "2" || li === "3", then: () => yup.string().required("Final Commitment Amount is required"), otherwise: () => yup.string().notRequired() }),
    FinalAmountItem3: yup.string().when('PCOLineItems', {is: (li:string) => li === "3", then: () => yup.string().required("Final Commitment Amount is required"), otherwise: () => yup.string().notRequired() }),
});

export type Ppm2ReviewFormSchema = yup.InferType<typeof pm2ReviewFormSchema>

export const prCreationFormSchema = yup.object().shape({
    Flag: yup.string().notRequired(),
    Stage: yup.string().required("Next step is required"),
    Status: yup.string().notRequired(),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    PRRejectedComments: yup.string().when('Stage', {is: (stage:string) => stage==="PR Rejected", then: () => yup.string().required("PR Rejected Comments is required"), otherwise: () => yup.string().notRequired() }),
    PRNumber:yup.string().when('Stage', {is: (stage:string) => stage==="PR Approved", then: () => yup.string().required("PR NUmber is required"), otherwise: () => yup.string().notRequired() }),
    DatePREntered:yup.string().when('Stage', {is: (stage:string) => stage==="PR Approved", then: () => yup.string().required("Date PR Entered is required"), otherwise: () => yup.string().notRequired() }),
    CommentsRevise: yup.string().when('Stage', {is: (stage:string) => stage==="Initiator Revision", then: () => yup.string().required("Comments Revise is required"), otherwise: () => yup.string().notRequired() }),
});

export type PprCreationFormSchema = yup.InferType<typeof prCreationFormSchema>

export const poCreationFormSchema = yup.object().shape({
    Flag: yup.string().notRequired(),
    Stage: yup.string().required("Next step is required"),
    Status: yup.string().notRequired(),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    DatePRApproved: yup.string().when('Stage', {is: (stage:string) => stage==="PO Created", then: () => yup.string().required("Date PR Approved is required"), otherwise: () => yup.string().notRequired() }),
    DatePOApproved: yup.string().when('Stage', {is: (stage:string) => stage==="PO Created", then: () => yup.string().required("Date PO Approved is required"), otherwise: () => yup.string().notRequired() }),
    ApprovedPOAmount: yup.string().when('Stage', {is: (stage:string) => stage==="PO Created", then: () => yup.string().typeError("Approved PO Amount must be a number").min(0.1, "Approved PO Amount should not be 0 value").required("Approved PO Amount is required"), otherwise: () => yup.string().notRequired() }),
    NewPromiseDate: yup.string().notRequired(),
    NewPromisedDateComment: yup.string().when('Stage', {is: (stage:string) => stage==="PO Created", then: () => yup.string().required("New Promised Date Comment is required"), otherwise: () => yup.string().notRequired() }),
    NewRequiredbyDate: yup.string().when('Stage', {is: (stage:string) => stage==="PO Created", then: () => yup.string().required("New Required by Date is required"), otherwise: () => yup.string().notRequired() }),
    NewRequiredbyComment: yup.string().when('Stage', {is: (stage:string) => stage==="PO Created", then: () => yup.string().required("New Required by Comment is required"), otherwise: () => yup.string().notRequired() }),
});

export type PpoCreationFormSchema = yup.InferType<typeof poCreationFormSchema>

export const poAttachedFormSchema = yup.object().shape({
    Flag: yup.string().notRequired(),
    Stage: yup.string().required("Next step is required"),
    Status: yup.string().notRequired(),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    COAttached:  yup.string().oneOf(["Yes"], "This is required."),
    FileAttachment: yup.mixed().test("FileAttachment", "File Attachment is required", (file:FileList) => { if(file?.length > 0) { return true;}else{ return false;} }),
});

export type PpoAttachedFormSchema = yup.InferType<typeof poAttachedFormSchema>

export interface IWrorkFlow{
    Id?: number;
    itemID?: string;
    Transaction?: string;
    Stage: string;
    Status:string;
    flag?: string;
}

export interface IDelegateItem{
    id: string;
    imageInitials: string;
    imageUrl: string;
    loginName:string;
    optionalText:string;
    secondaryText:string;
    tertiaryText:string;
    text:string;
}

export interface IProposeVendor{
    id: string;
    VendorName: string;
    Range: string;
  }