declare interface IPcoWebPartStrings {
  PanePropsPropsedVendor: string | undefined;
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  AppLocalEnvironmentSharePoint: string;
  AppLocalEnvironmentTeams: string;
  AppLocalEnvironmentOffice: string;
  AppLocalEnvironmentOutlook: string;
  AppSharePointEnvironment: string;
  AppTeamsTabEnvironment: string;
  AppOfficeEnvironment: string;
  AppOutlookEnvironment: string;
  UnknownEnvironment: string;
  PanePropsProjectNumberName: string;
  PanePropsProjectType: string;
  PanePropsPcoList: string;
  PanePropsProjectNumberNameDev:string;
  PanePropsProposedVendor:string;
  PanePropsTaskCodeList: string;
}

declare module 'PcoWebPartStrings' {
  const strings: IPcoWebPartStrings;
  export = strings;
}
