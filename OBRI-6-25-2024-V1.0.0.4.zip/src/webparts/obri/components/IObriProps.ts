import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IObriProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  spProjectListItems?: IProjectListItem[];
  PanePropsProjectNumberName: string;
  PanePropsObriList:string;
  spContext: WebPartContext;
  userEmail?:string;
  spOriItem:IObriListItems[];
  spBaseURL:string;
}

export interface IProjectListItem{
  id: string;
  ProjectName: string;
  ProjectType: string;
}

export interface IObriListItems{
  AssignedTo:string;
  AssignedToId:number;
  Id: string;
  Stage: string;
  Status: string;
  ProjectName:string;
  RequesterName: string;
  RequesterEmail: string;
  Subject: string;
  CCUser: string;
  CCEmails?: string;
  CCComment?:string;
  flag:string;
  RiskManagers: string;
  MobilizationDate: string;
  VoidComment: string;
  RejectComment: string;
}
