import * as React from 'react';
import styles from './Obri.module.scss';
import type { IObriProps } from './IObriProps';
import { Alert, Button, Card, Col, Container, Form, Modal, Row, Spinner } from 'react-bootstrap';
import { TObriACSchema, ObriACSchema } from '../utils/types';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup"
import { getSP } from '../utils/pnpjsConfig';
import WorkFlowSubmit from '../utils/WorkFlowSubmit';
import { IAttachmentInfo } from '@pnp/sp/attachments';
import { IoDocumentAttachOutline } from "react-icons/io5";
import addFilesPromise from '../utils/addFilesPromise';

export default function ObriAC(Props:IObriProps):React.ReactElement{
  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [CCGroup, setCCGroup ] = React.useState(false);
  const [nextStage , setnextStage] = React.useState("");
  const [theAttachmentFiles, settheAttachmentFiles] = React.useState<IAttachmentInfo[]>([]);
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);

  let attachments: IAttachmentInfo[] = [];
  React.useEffect(() => {
    async function fecthData():Promise<void>{
      const sp = getSP();
      const item = sp.web.lists.getByTitle(Props.PanePropsObriList).items.getById(parseInt(Props.spOriItem[0].Id));
      attachments = await item.attachmentFiles().then(async res => {return res});
      settheAttachmentFiles(attachments);
      console.log("await:",attachments);
    }
    fecthData().catch(console.error);
  },[]);

  const { 
    register,
    handleSubmit,
    formState: {errors, isSubmitting},
    reset
  } = useForm<TObriACSchema>({
    resolver: yupResolver(ObriACSchema)
  });

    const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
      if(FileAttachment && FileAttachment?.length > 0){
        for(let i =0; i < FileAttachment.length; i++){
          /* eslint-disable no-useless-escape */
          const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
          if(match){
            setShowSuccess(true);
            setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
            setMessageType('danger');
            return true;
          }else{
            return false;
          }
        }
      }
      return false;
    }
  
    const onSubmit = async (data: TObriACSchema):Promise<void> => {
      const sp = getSP(Props.spContext);
      const Attachment = document.getElementById("FileAttachment") as HTMLInputElement;
      const Attfiles = Attachment.files;
      if(filenameCharValidation(Attfiles)){ return; }
      
      data.CCUser = CCGroup === true ? "Yes": "No";
      data.flag = "1";
      console.log("Schema Data:", data);

      let newStatus:string = "Pending";
      let newStage:string = "Attach Certificate";
      switch(data.Stage){
        case "Submit": newStatus = "Completed"; newStage = "Completed"; break;
        case "Void": newStatus = "Void"; newStage = "Void"; break;
        default: newStatus = "Pending"; newStage = "Attach Certificate";
      }
      data.Status = newStatus;
      data.Stage = newStage;

      await sp.web.lists.getByTitle(Props.PanePropsObriList).items.getById(parseInt(Props.spOriItem[0].Id)).update(data)
      .then(async (addResult) => {
        console.log("add result:",addResult);
  
        if(Attfiles && Attfiles?.length > 0){
          const PromoseArray = [];
          setShowSuccess(true);
          setmessage("Please wait while we upload the file Attachment.");
          setMessageType('primary');
          for(let i =0; i < Attfiles.length; i++){
            const UploadArray = await addFilesPromise( Props.PanePropsObriList, parseInt(Props.spOriItem[0].Id) ,Attfiles, i);
            PromoseArray.push(UploadArray);
          }
          Promise.all(PromoseArray).then( res => { 
            console.log("Promise Upload resolve:", res);
            setShowSuccess(true);
            setmessage("Successfully Submitted and Completed the step.");
            setMessageType('success');
            reset();
          })
          .catch(err => { 
            console.log("Promise Upload reject:", err);
            setShowSuccess(true);
            setmessage("Your Request is Submitted but there was a problem uploading the attachment");
            setMessageType('danger');
            reset();
          });
        }else{
          setShowSuccess(true);
          setmessage("Successfully Submitted Your Request without Attachment and Completed the step.");
          setMessageType('info');
          reset();
        }
        const WFresult = await WorkFlowSubmit(Props.spOriItem[0].Id, false, newStatus, newStage, "2");
        console.log("WF Result:", WFresult);
        setModalShow(true);
        reset();
        return Promise.resolve;
      })
      .catch( (error) => {
          console.log("Error Submit:", error);
          setShowSuccess(true);
          setmessage("Sorry! Your Request failed to Submit. Please try again.");
           setMessageType('danger');
          return Promise.reject;
      });
      
    };
    
  
    return(
      <section className={`${styles.obri} ${Props.hasTeamsContext ? styles.teams : ''}`}>
        <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
          <Container>
              <Card>
                <Card.Header className="h5">Obtain Builders Risk Insurance (OBRI) - MARSH STEP</Card.Header>
                <Card.Body>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label>Project Number and Name</Form.Label>
                        <Form.Control type="text" value={Props.spOriItem[0].ProjectName} disabled/>
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label>Instance Number</Form.Label>
                        <Form.Control type="text" value={Props.spOriItem[0].Id} disabled/>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label>Requester Name</Form.Label>
                        <Form.Control type="text" value={Props.spOriItem[0].RequesterName} disabled/>
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label>Requester Email</Form.Label>
                        <Form.Control type="text" value={Props.spOriItem[0].RequesterEmail} disabled/>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Label>Subject</Form.Label>
                        <Form.Control type="text"  value={Props.spOriItem[0].Subject} disabled/>
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Label>Mobilization Date</Form.Label>
                        <Form.Control type="text"  value={Props.spOriItem[0].MobilizationDate} disabled/>
                      </Form.Group>
                    </Col>
                  </Row>
                  
                  <Row className='mb-3'>
                      <Col>
                        <Card>
                          <Card.Header className="h5">Initiator Attachments</Card.Header>
                          <Card.Body>
                            <div className="d-grid gap-2">
                            {
                              theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                                return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                              })
                            }
                            </div>
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
                  <Row className="mb-5">
                    <Col>
                      <Card style={{ width: '100%' }}>
                        <Card.Header className='h6'>CC Users</Card.Header>
                        <Card.Body>
                        <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                          <Form.Group className="mb-3">
                            <Form.Check
                              inline
                              label="Yes"
                              value="true"
                              {...register("CCUser")} 
                              onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                            />
                          </Form.Group>
                          <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                            <Form.Label className={styles.required}>Email Addresses</Form.Label>
                            <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                            <Form.Control.Feedback type="invalid">
                              {errors.CCEmails?.message}
                            </Form.Control.Feedback>
                          </Form.Group>
                          <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                            <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                            <Form.Control as="textarea" rows={3} {...register("CCComment")} />
                          </Form.Group>
                        </Card.Body>
                      </Card>
                    </Col>
                  </Row>
                  <Card className='mb-4'>
                    <Card.Header className="h5">Next Step</Card.Header>
                    <Card.Body>
                      <Form.Group className="mb-5">
                        <Form.Label className={styles.required}>Outcome</Form.Label>
                        <Form.Select aria-label="Please Select Next Step" {...register("Stage")} isInvalid={!!errors.Stage } onChange={(e)=>{setnextStage(e.currentTarget.value )}} >
                          <option value="">Please Select Next Step</option>
                          <option key='ns4' value="Submit">Submit</option>
                          <option key='ns3' value="Void">Void</option>
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">
                          {errors.Stage?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                      <Row>
                        <Col>
                          <Form.Group className="mb-5">
                            <Form.Label className={styles.required}>Taken action by:</Form.Label>
                            <Form.Select aria-label="Please Select Next Step" {...register("MarshWhoTakesAction")} isInvalid={!!errors.MarshWhoTakesAction }>
                              <option value="">Please Select</option>
                              <option key='gen' value="jennifer.wampler@sunpowercorp.com">jennifer.wampler@sunpowercorp.com</option>
                              <option key='step' value="stephanie.martinez@sunpowercorp.com">stephanie.martinez@sunpowercorp.com</option>
                              <option key='rowin' value="rowin.raneses@sunpowercorp.com">rowin.raneses@sunpowercorp.com</option>
                              <option key='box' value="boxadmin2@sunpowercorp.com">boxadmin2@sunpowercorp.com</option>
                            </Form.Select>
                            <Form.Control.Feedback type="invalid">
                              {errors.MarshWhoTakesAction?.message}
                            </Form.Control.Feedback>
                          </Form.Group>
                          <Form.Group className="mb-5" hidden={nextStage === "Void" ? false: true}>
                            <Form.Label>Comment - Void</Form.Label>
                            <Form.Control as="textarea" rows={3} {...register("VoidComment")} isInvalid={ !!errors.VoidComment }/>
                            <Form.Control.Feedback type="invalid">
                              {errors.VoidComment?.message}
                            </Form.Control.Feedback>
                          </Form.Group>
                          <Row className='mb-5'  hidden={nextStage === "Submit" ? false: true}>
                            <Col>
                              <Card style={{ width: '100%' }}>
                                <Card.Header className='h6'>Attachments</Card.Header>
                                <Card.Body>
                                  <Form.Group>
                                    <Form.Control type="file" id="FileAttachment" multiple />
                                  </Form.Group>
                                </Card.Body>
                                </Card>
                            </Col>
                          </Row>
                        </Col>
                      </Row>
                    </Card.Body>
                  </Card>
                  <Row className='mb-5'>
                    <Col>
                      <Card style={{ width: '100%' }}>
                        <Card.Header className='h6'>GRID Portal</Card.Header>
                        <Card.Body>
                          <Card.Text>Want to know more? Visit our <a href="https://jam4.sapjam.com/groups/gFBuRkYzruRh7evCqnKHiE/overview_page/N6UQPCcrwhyxRyK7VSGW6s?edit_mode=true">Grid</a> page.</Card.Text>
                        </Card.Body>
                      </Card>
                    </Col>
                  </Row>
                  
                  <Row className="mb-4">
                    <Col>
                      <div className="d-grid gap-2">
                        <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting } >
                        <Spinner
                          as="span"
                          animation="border"
                          size="sm"
                          role="status"
                          aria-hidden={ !!isSubmitting }
                          className={ isSubmitting ? "me-2": "visually-hidden" } />
                        { isSubmitting ? "...Submitting" : "SUBMIT" }
                        </Button>
                      </div>
                    </Col>
                  </Row>
                  { ShowSuccess && (
                      <Alert 
                        key={ MessageType } 
                        variant={ MessageType } 
                        dismissible 
                        onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                          { message }
                      </Alert>
                  )}
                </Card.Body>
              </Card>
            </Container>
          </form>
          <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
            <Modal.Header>
              <Modal.Title>SharePoint</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Alert variant="primary">
                <Alert.Heading>{ message }</Alert.Heading>
                <p hidden={MessageType === "danger" ? true : false}>
                  Thank you! You can now close this tab or window.
                </p>
              </Alert>
            </Modal.Body>
            <Modal.Footer hidden={MessageType === "danger" ? false : true}>
              <Button variant="secondary" onClick={handleClose}>
                Continue
              </Button>
            </Modal.Footer>
          </Modal>
        </section>
    );
  }
