/* tslint:disable */
require("./Obri.module.css");
const styles = {
  obri: 'obri_5a662e81',
  teams: 'teams_5a662e81',
  welcome: 'welcome_5a662e81',
  welcomeImage: 'welcomeImage_5a662e81',
  links: 'links_5a662e81',
  required: 'required_5a662e81',
  divDropArea: 'divDropArea_5a662e81'
};

export default styles;
/* tslint:enable */