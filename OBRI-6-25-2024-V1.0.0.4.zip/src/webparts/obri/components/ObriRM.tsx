import * as React from 'react';
import styles from './Obri.module.scss';
import type { IObriProps } from './IObriProps';
import { Alert, Button, Card, Col, Container, Form, Modal, Row, Spinner } from 'react-bootstrap';
import { TObriRMSchema, ObriRMSchema } from '../utils/types';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup"
import { getSP } from '../utils/pnpjsConfig';
import WorkFlowSubmit from '../utils/WorkFlowSubmit';
import { IAttachmentInfo } from '@pnp/sp/attachments';
import { IoDocumentAttachOutline } from "react-icons/io5";
import { IPeoplePickerContext, PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";

export default function ObriRM(Props:IObriProps):React.ReactElement{
    const [ShowSuccess, setShowSuccess] = React.useState( false );
    const [message, setmessage]= React.useState( "" );
    const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
    const [CCGroup, setCCGroup ] = React.useState(false);
    const [nextStage , setnextStage] = React.useState("");
    const [theAttachmentFiles, settheAttachmentFiles] = React.useState<IAttachmentInfo[]>([]);
    const [ModalShow, setModalShow ] = React.useState(false);
    const handleClose = ():void => setModalShow(false);

    const peoplePickerContext: IPeoplePickerContext = {
      absoluteUrl: Props.spContext.pageContext.web.absoluteUrl,
      msGraphClientFactory: Props.spContext.msGraphClientFactory,
      spHttpClient: Props.spContext.spHttpClient
    };

    let attachments: IAttachmentInfo[] = [];
    React.useEffect(() => {
      async function fecthData():Promise<void>{
        const sp = getSP();
        const item = sp.web.lists.getByTitle(Props.PanePropsObriList).items.getById(parseInt(Props.spOriItem[0].Id));
        attachments = await item.attachmentFiles().then(async res => {return res});
        settheAttachmentFiles(attachments);
        console.log("await:",attachments);
      }
      fecthData().catch(console.error);
    },[]);

    const { 
      register,
      handleSubmit,
      formState: {errors, isSubmitting},
      reset, setValue
    } = useForm<TObriRMSchema>({
      resolver: yupResolver(ObriRMSchema)
    });

    /* eslint-disable  @typescript-eslint/no-explicit-any */
    const _getPeoplePickerDelegate = (items:any[]):void => {
      console.log("Delegated User:",items );
      items.map((item) => { 
        setValue("DelegatedTo", item.loginName);
      });
    }

     /* eslint-disable  @typescript-eslint/no-explicit-any */
     const _getPeoplePickerRiskManager = (items:any[]):void => {
      console.log("Risk User:",items );
      items.map((item) => { 
        setValue("RiskManagers", item.loginName);
      });
    }

  
    const onSubmit = async (data: TObriRMSchema):Promise<void> => {
      const sp = getSP(Props.spContext);
      // const Attachment = document.getElementById("FileAttachment") as HTMLInputElement;
      // const Attfiles = Attachment.files;
      
      data.CCUser = CCGroup === true ? "Yes": "No";
      data.flag = "1";
      console.log("Schema Data:", data);

      let newStatus:string = "Pending";
      let newStage:string = "Risk Manager Review";
      switch(data.Stage){
        case "AttachCertificate": newStatus = "Pending"; newStage = "Attach Certificate";break;
        case "Rejected": newStatus = "Pending"; newStage = "Initiator Revision"; break;
        case "Delegate": newStatus = "Delegate"; newStage = "Risk Manager Review"; break;
        default: newStatus = "Pending"; newStage = "Risk Manager Review";
      }
      data.Status = newStatus;
      data.Stage = newStage;

      await sp.web.lists.getByTitle(Props.PanePropsObriList).items.getById(parseInt(Props.spOriItem[0].Id)).update(data)
      .then(async (addResult) => {
        console.log("add result:",addResult);
        setShowSuccess(true);
        setmessage("Successfully Submitted Your Request for the Next Step.");
        setMessageType('info');

        const WFresult = await WorkFlowSubmit(Props.spOriItem[0].Id, false, newStatus, newStage, "2");
        console.log("WF Result:", WFresult);
        reset();
        setModalShow(true);
        return Promise.resolve;
      })
      .catch( (error) => {
          console.log("Error Submit:", error);
          setShowSuccess(true);
          setmessage("Sorry! Your Request failed to Submit. Please try again.");
           setMessageType('danger');
          return Promise.reject;
      });
      
    };
    
  
    return(
      <section className={`${styles.obri} ${Props.hasTeamsContext ? styles.teams : ''}`}>
        <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
          <Container>
              <Card>
                <Card.Header className="h5">Obtain Builders Risk Insurance (OBRI) - RISK MANAGER REVIEW</Card.Header>
                <Card.Body>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label>Project Number and Name</Form.Label>
                        <Form.Control type="text" value={Props.spOriItem[0].ProjectName} disabled/>
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label>Instance Number</Form.Label>
                        <Form.Control type="text" value={Props.spOriItem[0].Id} disabled/>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label>Requester Name</Form.Label>
                        <Form.Control type="text" value={Props.spOriItem[0].RequesterName} disabled/>
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label>Requester Email</Form.Label>
                        <Form.Control type="text" value={Props.spOriItem[0].RequesterEmail} disabled/>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Label>Subject</Form.Label>
                        <Form.Control type="text"  value={Props.spOriItem[0].Subject} disabled/>
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group className="mb-3" >
                        <Form.Label>Mobilization Date</Form.Label>
                        <Form.Control type="text"  value={Props.spOriItem[0].MobilizationDate} disabled/>
                      </Form.Group>
                    </Col>
                  </Row>
                  
                  <Row className='mb-3'>
                      <Col>
                        <Card>
                          <Card.Header className="h5">Initiator Attachments</Card.Header>
                          <Card.Body>
                            <div className="d-grid gap-2">
                            {
                              theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                                return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                              })
                            }
                            </div>
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
                  <Row className="mb-5">
                    <Col>
                      <Card style={{ width: '100%' }}>
                        <Card.Header className='h6'>CC Users</Card.Header>
                        <Card.Body>
                        <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                          <Form.Group className="mb-3">
                            <Form.Check
                              inline
                              label="Yes"
                              value="true"
                              {...register("CCUser")} 
                              onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                            />
                          </Form.Group>
                          <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                            <Form.Label className={styles.required}>Email Addresses</Form.Label>
                            <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                            <Form.Control.Feedback type="invalid">
                              {errors.CCEmails?.message}
                            </Form.Control.Feedback>
                          </Form.Group>
                          <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                            <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                            <Form.Control as="textarea" rows={3} {...register("CCComment")} />
                          </Form.Group>
                        </Card.Body>
                      </Card>
                    </Col>
                  </Row>
                  <Card className='mb-4'>
                    <Card.Header className="h5">Next Step</Card.Header>
                    <Card.Body>
                      <Form.Group className="mb-5">
                        <Form.Label className={styles.required}>Outcome</Form.Label>
                        <Form.Select aria-label="Please Select Next Step" {...register("Stage")} isInvalid={!!errors.Stage } onChange={(e)=>{setnextStage(e.currentTarget.value )}} >
                          <option value="">Please Select Next Step</option>
                          <option key='ns4' value="Rejected">Rejected</option>
                          <option key='ns2' value="AttachCertificate">Submit to Insurance Company</option>
                          <option key='ns3' value="Delegate">Delegate</option>
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">
                          {errors.Stage?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                      <Row>
                        <Col>
                          <Form.Group className="mb-5" hidden={nextStage === "Delegate" ? false: true}>
                            <PeoplePicker
                              context={peoplePickerContext}
                              {...register("DelegatedTo")}
                              titleText="Choose user to delegate"
                              personSelectionLimit={1}
                              showtooltip={true}
                              required={true}
                              ensureUser={true}
                              onChange={ items => _getPeoplePickerDelegate(items) }
                              principalTypes={[PrincipalType.User]}
                              resolveDelay={1000} />
                            <p className="link-danger">{errors.DelegatedTo?.message}</p>
                          </Form.Group>
                          <Form.Group className="mb-5" hidden={nextStage === "Rejected" ? false: true}>
                            <Form.Label>Comments</Form.Label>
                            <Form.Control as="textarea" rows={3} {...register("RejectComment")} isInvalid={ !!errors.RejectComment }/>
                            <Form.Control.Feedback type="invalid">
                              {errors.RejectComment?.message}
                            </Form.Control.Feedback>
                          </Form.Group>
                          <Row className='mb-5'  hidden={nextStage === "AttachCertificate" ? false: true}>
                            <Col>
                                <Form.Group className="mb-5">
                                  <Form.Label className={styles.required}>Risk Manager</Form.Label>
                                  <PeoplePicker
                                    context={peoplePickerContext}
                                    {...register("RiskManagers")}
                                    titleText="Search and Select Risk Managers"
                                    personSelectionLimit={5}
                                    showtooltip={true}
                                    required={true}
                                    ensureUser={true}
                                    onChange={ items => _getPeoplePickerRiskManager(items) }
                                    principalTypes={[PrincipalType.User]}
                                    resolveDelay={1000} />
                                  <p className="link-danger">{errors.RiskManagers?.message}</p>
                                </Form.Group>
                            </Col>
                          </Row>
                        </Col>
                      </Row>
                    </Card.Body>
                  </Card>
                  <Row className='mb-5'>
                    <Col>
                      <Card style={{ width: '100%' }}>
                        <Card.Header className='h6'>GRID Portal</Card.Header>
                        <Card.Body>
                          <Card.Text>Want to know more? Visit our <a href="https://jam4.sapjam.com/groups/gFBuRkYzruRh7evCqnKHiE/overview_page/N6UQPCcrwhyxRyK7VSGW6s?edit_mode=true">Grid</a> page.</Card.Text>
                        </Card.Body>
                      </Card>
                    </Col>
                  </Row>
                  
                  <Row className="mb-4">
                    <Col>
                      <div className="d-grid gap-2">
                        <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting } >
                        <Spinner
                          as="span"
                          animation="border"
                          size="sm"
                          role="status"
                          aria-hidden={ !!isSubmitting }
                          className={ isSubmitting ? "me-2": "visually-hidden" } />
                        { isSubmitting ? "...Submitting" : "SUBMIT" }
                        </Button>
                      </div>
                    </Col>
                  </Row>
                  { ShowSuccess && (
                      <Alert 
                        key={ MessageType } 
                        variant={ MessageType } 
                        dismissible 
                        onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                          { message }
                      </Alert>
                  )}
                </Card.Body>
              </Card>
            </Container>
          </form>
          <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
            <Modal.Header>
              <Modal.Title>SharePoint</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Alert variant="primary">
                <Alert.Heading>{ message }</Alert.Heading>
                <p hidden={MessageType === "danger" ? true : false}>
                  Thank you! You can now close this tab or window.
                </p>
              </Alert>
            </Modal.Body>
            <Modal.Footer hidden={MessageType === "danger" ? false : true}>
              <Button variant="secondary" onClick={handleClose}>
                Continue
              </Button>
            </Modal.Footer>
          </Modal>
        </section>
    );
  }
