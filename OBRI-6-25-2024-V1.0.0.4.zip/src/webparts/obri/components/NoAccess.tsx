import * as React from 'react';
import Modal from 'react-bootstrap/Modal';


export default function NoAccess():React.ReactElement {
  return (
    <div className="modal show" style={{ display: 'block', position: 'initial' }}>
      <Modal.Dialog>
        <Modal.Header>
          <Modal.Title>Warning</Modal.Title>
        </Modal.Header>

        <Modal.Body>
            <p>You do not have access this Request.</p>
        </Modal.Body>
      </Modal.Dialog>
    </div>
  );
}
