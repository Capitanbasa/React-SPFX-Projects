import * as yup from 'yup';

export const ObriFormSchema = yup.object().shape({
    Stage: yup.string().default("Risk Manager Review").notRequired(),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),
    ProjectName: yup.string().required("Project Number - Project Name is required"),
    RequesterName: yup.string().required("Requester Name is required"),
    RequesterEmail: yup.string().required().email("Requester Email is required"),
    Subject: yup.string().required("Subject is required"),
    MobilizationDate: yup.string().required("Mobilization Date is required"),
    RiskManagers: yup.string().required("This is required"),
    //FileAttachment: yup.mixed().test("FileAttachment", "You need to provide a BRIA Template file", (file:FileList) => { if(file?.length > 0) { return true;}else{ return false;} }),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TObriFormSchema = yup.InferType<typeof ObriFormSchema>

export const ObriRMSchema = yup.object().shape({
    Stage: yup.string().default("Risk Manager Review").required(),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),
    DelegatedTo:  yup.string().when('Stage', {is: (s: string) => s==="Delegate", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    RejectComment:  yup.string().when('Stage', {is: (s: string) => s==="Rejected", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    RiskManagers:  yup.string().when('Stage', {is: (s: string) => s==="AttachCertificate", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TObriRMSchema = yup.InferType<typeof ObriRMSchema>

export const ObriACSchema = yup.object().shape({
    Stage: yup.string().default("Attach Certificate").required(),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),
    MarshWhoTakesAction: yup.string().required("This is required"),
    VoidComment:  yup.string().when('Stage', {is: (s: string) => s==="Void", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TObriACSchema = yup.InferType<typeof ObriACSchema>

export interface IWrorkFlow{
    Id?: number;
    itemID?: string;
    Transaction?: string;
    Stage: string;
    Status:string;
    flag?: string;
}

export interface IDelegateItem{
    id: string;
    imageInitials: string;
    imageUrl: string;
    loginName:string;
    optionalText:string;
    secondaryText:string;
    tertiaryText:string;
    text:string;
}