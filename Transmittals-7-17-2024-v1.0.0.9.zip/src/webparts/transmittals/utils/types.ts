import * as yup from 'yup';

export const transmittalFormSchema = yup.object().shape({
    flag: yup.string().default("1").notRequired(),
    ProjectName: yup.string().required("Project Number - Project Name is required"),
    RequesterName: yup.string().required("Requester Name is required"),
    RequesterEmail: yup.string().required().email("Requester Email is required"),
    Subject: yup.string().required("Subject is required"),
    DateSent: yup.string().required("Date Sent is required"),
    SendVia: yup.string().required("Send Via is required"),
    Others: yup.string().when('SendVia', {is: (SendVia: string) => SendVia ==='Other', then: () =>  yup.string().required("Other is required"), otherwise: () => yup.string().notRequired() }),
    TrackingNumber: yup.string().notRequired(),
    ProjectRole: yup.string().required("Project Role is required"),
    FaxNumber: yup.string().notRequired(),
    CompanyName: yup.string().required("Company Name is required"),
    Attn: yup.string().required("Attn is required"),
    Address: yup.string().notRequired(),
    Phone: yup.string().notRequired(),

    NumberofItems: yup.string().required("Number of items is required"),

    Item1Item:  yup.string().required("Item is required"),
    Item1Description:  yup.string().required("Item Description is required"),
    Item1FileDate:  yup.string().required("Item file date is required"),
    Item1NumCopies:  yup.string().required("Number of copy/copies is required"),

    Item2Item:  yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "2" || itemcount === "3" || itemcount === "4" || itemcount === "5", then: () => yup.string().required("Item is required"), otherwise: () => yup.string().notRequired()}),
    Item2Description:  yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "2" || itemcount === "3" || itemcount === "4" || itemcount === "5", then: () => yup.string().required("Item Description is required"), otherwise: () => yup.string().notRequired()}),
    Item2FileDate: yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "2" || itemcount === "3" || itemcount === "4" || itemcount === "5", then: () => yup.string().required("Item File is required"), otherwise: () => yup.string().notRequired()}),
    Item2NumCopies:  yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "2" || itemcount === "3" || itemcount === "4" || itemcount === "5", then: () => yup.string().required("Item copy/copies is required"), otherwise: () => yup.string().notRequired()}),

    Item3Item:  yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "3" || itemcount === "4" || itemcount === "5", then: () => yup.string().required("Item is required"), otherwise: () => yup.string().notRequired()}),
    Item3Description:  yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "3" || itemcount === "4" || itemcount === "5", then: () => yup.string().required("Item Description is required"), otherwise: () => yup.string().notRequired()}),
    Item3FileDate: yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "3" || itemcount === "4" || itemcount === "5", then: () => yup.string().required("Item File is required"), otherwise: () => yup.string().notRequired()}),
    Item3NumCopies:  yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "3" || itemcount === "4" || itemcount === "5", then: () => yup.string().required("Item copy/copies is required"), otherwise: () => yup.string().notRequired()}),

    Item4Item:  yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "4" || itemcount === "5", then: () => yup.string().required("Item is required"), otherwise: () => yup.string().notRequired()}),
    Item4Description:  yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "4" || itemcount === "5", then: () => yup.string().required("Item Description is required"), otherwise: () => yup.string().notRequired()}),
    Item4FileDate: yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "4" || itemcount === "5", then: () => yup.string().required("Item File is required"), otherwise: () => yup.string().notRequired()}),
    Item4NumCopies:  yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "4" || itemcount === "5", then: () => yup.string().required("Item copy/copies is required"), otherwise: () => yup.string().notRequired()}),

    Item5Item:  yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "5", then: () => yup.string().required("Item is required"), otherwise: () => yup.string().notRequired()}),
    Item5Description:  yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "5", then: () => yup.string().required("Item Description is required"), otherwise: () => yup.string().notRequired()}),
    Item5FileDate: yup.string().when('NumberofItems', {is: (itemcount: string) =>  itemcount === "5", then: () => yup.string().required("Item File is required"), otherwise: () => yup.string().notRequired()}),
    Item5NumCopies:  yup.string().when('NumberofItems', {is: (itemcount: string) => itemcount === "5", then: () => yup.string().required("Item copy/copies is required"), otherwise: () => yup.string().notRequired()}),

    Transmittedas: yup.string().required("Transmitted As is required"),
    Remarks: yup.string().notRequired(),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TtransmittalFormSchema = yup.InferType<typeof transmittalFormSchema>

export interface IWrorkFlow{
    itemID: string;
    Transaction: string;
    Stage: string;
    Status:string;
    flag: string;
    ProjectName: string;
}