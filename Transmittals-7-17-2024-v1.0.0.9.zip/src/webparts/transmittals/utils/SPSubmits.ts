import { getSP } from "../components/pnpjsConfig";
import { IWrorkFlow } from "./types";

export async function WorkFlowSubmit(ID:string, ProjectName: string):Promise<string>{

    const WFData:IWrorkFlow = {
        itemID: ID,
        Transaction: 'Transmittals',
        Stage: 'NA',
        Status: 'NA',
        flag: '1',
        ProjectName: ProjectName,
      };
      const sp = getSP();
      return await sp.web.lists.getByTitle("Workflow List").items.add(WFData)
      .then((res)=>{ return Promise.resolve("WF Success")}).catch((error)=>{ return Promise.reject("WF Error")});
}

export async function addFilesPromise(SPList:string, itemID: number, file: FileList, index:number ):Promise<string> {
  const sp = getSP();
  return await sp.web.lists.getByTitle(SPList).items.getById(itemID)
    .attachmentFiles.add(file[index].name, file[index])
    .then((res) =>{ return Promise.resolve("Done uploading:" +file[index].name) } )
    .catch((error)=>{ return Promise.reject(error) });
}