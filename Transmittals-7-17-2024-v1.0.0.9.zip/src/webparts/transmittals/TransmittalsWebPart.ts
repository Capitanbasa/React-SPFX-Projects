import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  type IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
import { SPHttpClient } from '@microsoft/sp-http';

import * as strings from 'TransmittalsWebPartStrings';
import Transmittals from './components/Transmittals';
import { IProjectListItem, ITransmittalsProps, ITransmittalsWebPartProps } from './components/ITransmittalsProps';
import 'bootstrap/dist/css/bootstrap.min.css';



export default class TransmittalsWebPart extends BaseClientSideWebPart<ITransmittalsWebPartProps> {

  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = '';
  private _projectsList:  IProjectListItem[];


  public render(): void {
    const element: React.ReactElement<ITransmittalsProps> = React.createElement(
      Transmittals,
      {
        description: this.properties.description,
        isDarkTheme: this._isDarkTheme,
        environmentMessage: this._environmentMessage,
        hasTeamsContext: !!this.context.sdks.microsoftTeams,
        userDisplayName: this.context.pageContext.user.displayName,
        userEmail: this.context.pageContext.user.email,
        spContext: this.context,
        spProjectListItems: this._projectsList,
        PanePropsProjectNumberName: this.properties.PanePropsProjectNumberName,
        PanePropsTransmittalsList : this.properties.PanePropsTransmittalsList
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected async onInit(): Promise<void> {
    await this._onGetProjectListItems();
    return this._getEnvironmentMessage().then(message => {
      this._environmentMessage = message;
    });
  }

  private _onGetProjectListItems = async (): Promise<void> => {
    const response: IProjectListItem[] = await this._getProjectListItems();
    this._projectsList = response;
  }

  private async _getProjectListItems(): Promise<IProjectListItem[]> {

    const response = await this.context.spHttpClient.get(
      this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${this.properties.PanePropsProjectNumberName}')/items?$select=Id,ProjectName&$filter=Transaction eq 'Transmittals' and ProjectType eq 'Prod'`,
      SPHttpClient.configurations.v1)
    if (!response.ok) {
      const responseText = await response.text();
      throw new Error(responseText);
    }
    
    const responseJson = await response.json();
  
    return responseJson.value as IProjectListItem[];
  }



  private _getEnvironmentMessage(): Promise<string> {
    if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
      return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
        .then(context => {
          let environmentMessage: string = '';
          switch (context.app.host.name) {
            case 'Office': // running in Office
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOffice : strings.AppOfficeEnvironment;
              break;
            case 'Outlook': // running in Outlook
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOutlook : strings.AppOutlookEnvironment;
              break;
            case 'Teams': // running in Teams
            case 'TeamsModern':
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentTeams : strings.AppTeamsTabEnvironment;
              break;
            default:
              environmentMessage = strings.UnknownEnvironment;
          }

          return environmentMessage;
        });
    }

    return Promise.resolve(this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentSharePoint : strings.AppSharePointEnvironment);
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }

    this._isDarkTheme = !!currentTheme.isInverted;
    const {
      semanticColors
    } = currentTheme;

    if (semanticColors) {
      this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
      this.domElement.style.setProperty('--link', semanticColors.link || null);
      this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
    }

  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('PanePropsTransmittalsList', {
                  label: strings.PanePropsTransmittalsList,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
                PropertyPaneTextField('PanePropsProjectNumberName', {
                  label: strings.PanePropsProjectNumberName,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
              ]
            }
          ]
        }
      ]
    };
  }

  private async validatePaneProps(value: string): Promise<string> {
    if (value === null || value.length === 0) {
      return "Provide the list name";
    }
    try{
      const response = await this.context.spHttpClient.get(
      this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${value}')/items?$select=Id`,
      SPHttpClient.configurations.v1);
      if (response.ok) {
        return "";
      } else if (response.status === 404) {
        return `List '${escape(value)}' doesn't exist in the current site`;
      }else{
        return `Error: ${response.statusText}. Please try again`;
      }
    }catch(error){
      return error.message;
    }
  }
}
