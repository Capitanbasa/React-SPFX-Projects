declare interface ITransmittalsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  AppLocalEnvironmentSharePoint: string;
  AppLocalEnvironmentTeams: string;
  AppLocalEnvironmentOffice: string;
  AppLocalEnvironmentOutlook: string;
  AppSharePointEnvironment: string;
  AppTeamsTabEnvironment: string;
  AppOfficeEnvironment: string;
  AppOutlookEnvironment: string;
  UnknownEnvironment: string;
  PanePropsProjectNumberName: string;
  PanePropsTransmittalsList: string;
}

declare module 'TransmittalsWebPartStrings' {
  const strings: ITransmittalsWebPartStrings;
  export = strings;
}
