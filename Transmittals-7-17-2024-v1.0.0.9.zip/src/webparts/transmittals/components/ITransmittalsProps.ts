import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface ITransmittalsProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  userEmail:string;
  spProjectListItems?: IProjectListItem[];
  PanePropsProjectNumberName: string;
  PanePropsTransmittalsList:string;
  spContext: WebPartContext;
}

export interface ITransmittalsWebPartProps {
  description: string;
  PanePropsProjectNumberName: string;
  PanePropsTransmittalsList:string;
}

export interface IProjectListItem{
  id: string;
  ProjectName: string;
  ProjectLeadId: number;
  RequesterName: string;
  RequesterEmail: string;
  Subject: string;
  DateSent: string;
  TrackingNumber: string;
  SendVia: string;
  ProjectRole	: string;
  FaxNumber	: string;
  CompanyName: string;
  Attn: string;
  Phone: string;
  NumberofItems: string;
  Item1Item: string;
  Item1Description: string;
  Item1FileDate	: string;
  Item1NumCopies	: string;
  CCUser: string;
  CCEmails	: string;
  CCComment: string;
}