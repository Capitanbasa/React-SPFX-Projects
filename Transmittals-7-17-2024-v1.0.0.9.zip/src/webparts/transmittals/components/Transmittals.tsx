import * as React from 'react';
import styles from './Transmittals.module.scss';
import type { ITransmittalsProps } from './ITransmittalsProps';
import { Alert, Button, Card, Col, Container, Form, Row, Spinner, Modal } from 'react-bootstrap';
import { DatePicker } from 'antd';

import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup"
import { transmittalFormSchema, TtransmittalFormSchema} from "../utils/types";
import { getSP } from './pnpjsConfig';

import "@pnp/sp/webs";
import "@pnp/sp/lists/web";
import "@pnp/sp/items";
import "@pnp/sp/attachments";
import { WorkFlowSubmit, addFilesPromise } from '../utils/SPSubmits';

export default function Transmittals(Props:ITransmittalsProps):React.ReactElement{

  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [SendViaOther, setSendViaOther ] = React.useState("");
  const [NIS, setNIS ] = React.useState("1");
  const [CCGroup, setCCGroup ] = React.useState(false);
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);

  const DTFormat = (d:string): string => {
    const newdate = new Date(d);
    return newdate.toLocaleDateString('default', { month: 'short', day: 'numeric', year: 'numeric'});
  }

  const { 
    register, 
    handleSubmit,
    formState: {errors, isSubmitting},
    reset, setValue
  } = useForm<TtransmittalFormSchema>({
    resolver: yupResolver(transmittalFormSchema),
  });

  const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
    if(FileAttachment && FileAttachment?.length > 0){
      for(let i =0; i < FileAttachment.length; i++){
        /* eslint-disable no-useless-escape */
        const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
        if(match){
          setShowSuccess(true);
          setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
          setMessageType('danger');
          return true;
        }else{
          return false;
        }
      }
    }
    return false;
  }

  const onSubmit = async (data: TtransmittalFormSchema):Promise<void> => {
    const sp = getSP(Props.spContext);
    const Attachment = document.getElementById("FileAttachment") as HTMLInputElement;
    const Attfiles = Attachment.files;
    if(filenameCharValidation(Attfiles)){ return; }
    data.CCUser = CCGroup === true ? "Yes": "No";
    console.log("Schema Data:", data);

    await sp.web.lists.getByTitle(Props.PanePropsTransmittalsList).items.add(data)
    .then(async (addResult) => {
      console.log("add result:",addResult);

      if(Attfiles && Attfiles?.length > 0){
        const PromoseArray = [];
        setShowSuccess(true);
        setmessage("Please wait while we upload the file Attachment.");
        setMessageType('primary');
        for(let i =0; i < Attfiles.length; i++){
          const UploadArray = await addFilesPromise( Props.PanePropsTransmittalsList, addResult.ID ,Attfiles, i);
          PromoseArray.push(UploadArray);
        }
        Promise.all(PromoseArray).then( res => { 
          console.log("Promise Upload resolve:", res);
          setShowSuccess(true);
          setmessage("Successfully Submitted Your Request.");
          setMessageType('success');
          reset();
        })
        .catch(err => { 
          console.log("Promise Upload reject:", err);
          setShowSuccess(true);
          setmessage("Your Request is Submitted but there was a problem uploading the attachment");
          setMessageType('danger');
          reset();
        });
      }else{
        setShowSuccess(true);
        setmessage("Successfully Submitted Your Request without Attachment.");
        setMessageType('primary');
        reset();
      }
      const WFresult = await WorkFlowSubmit(addResult.ID.toString(), data.ProjectName);
      console.log("WF Result:", WFresult);
      reset();
      setModalShow(true);
      return Promise.resolve;
    })
    .catch( (error) => {
        console.log("Error Submit:", error);
        setShowSuccess(true);
        setmessage("Sorry! Your Request failed to Submit. Please try again.");
         setMessageType('danger');
        return Promise.reject;
    });
    
  };
  
  return (
    <section className={`${styles.transmittals} ${Props.hasTeamsContext ? styles.teams : ''}`}>
       <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
       <Container>
            <Card>
              <Card.Header className="h5">Transmittals</Card.Header>
              <Card.Body>
                <Row>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label className={styles.required}>Project Number and Name</Form.Label>
                      <Form.Select aria-label="Please Select Project" {...register("ProjectName")} isInvalid={ !!errors.ProjectName }>
                        <option value="">Please Select Project</option> 
                          {Props.spProjectListItems && Props.spProjectListItems.map((list) => {
                                return  ( 
                                  <option key={list.id} value={list.ProjectName}>{list.ProjectName}</option> 
                                );
                          })}
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.ProjectName?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label className={styles.required}>Requester Name</Form.Label>
                      <Form.Control type="text" {...register("RequesterName")} defaultValue={Props.userDisplayName} isInvalid={ !!errors.RequesterName }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.RequesterName?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label className={styles.required}>Requester Email</Form.Label>
                      <Form.Control type="email" {...register("RequesterEmail")} defaultValue={Props.userEmail} isInvalid={ !!errors.RequesterEmail }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.RequesterEmail?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label className={styles.required}>Subject</Form.Label>
                      <Form.Control type="text"  {...register("Subject")} isInvalid={ !!errors.Subject }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.Subject?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>Send Options</Card.Header>
                      <Card.Body>
                        <Row>
                          <Col>
                          <Form.Group className="mb-4" >
                            <Form.Label className={styles.required}>Date Sent</Form.Label>
                            <DatePicker 
                              className='form-control' 
                              allowClear={true}
                              format={"MMM DD, YYYY"}
                              {...register("DateSent")}
                              onChange={(e): void => {  if(e){ setValue("DateSent", DTFormat(e.toString()),  { shouldValidate: true }) } }} 
                              />
                            <Form.Control.Feedback type="invalid">
                              {errors.DateSent?.message}
                            </Form.Control.Feedback>
                            <p className="link-danger">{errors.DateSent?.message}</p>
                          </Form.Group>
                          </Col>
                          <Col>
                            <Form.Group className="mb-3" >
                              <Form.Label>Tracking Number</Form.Label>
                              <Form.Control type="text" {...register("TrackingNumber")}/>
                            </Form.Group>
                          </Col>
                        </Row>
                        <Row>
                          <Col>
                            <Form.Group className="mb-3">
                              <Form.Label className={styles.required}>Send Via</Form.Label>
                              <Form.Select aria-label="Please Select Project" {...register("SendVia", { onChange: (e) => { setSendViaOther(e.currentTarget.value)}})} isInvalid={ !!errors.SendVia }>
                                <option value="">Please Select</option> 
                                <option value="Electronically">Electronically</option> 
                                <option value="US Mail">US Mail</option> 
                                <option value="FedEx">FedEx</option> 
                                <option value="UPS">UPS</option> 
                                <option value="Hand Delivery">Hand Delivery</option> 
                                <option value="Fax">Fax</option> 
                                <option value="Other">Other</option> 
                              </Form.Select>
                              <Form.Control.Feedback type="invalid">
                                {errors.SendVia?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                          <Col>
                            <Form.Group className="mb-3" hidden={ SendViaOther === "Other" ? false: true}>
                              <Form.Label className={styles.required}>If Other</Form.Label>
                              <Form.Control type="text" {...register("Others")} isInvalid={ !!errors.Others }/>
                              <Form.Control.Feedback type="invalid">
                                {errors.Others?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                        </Row>
                        <Row>
                          <Col>
                            <Form.Group className="mb-3">
                              <Form.Label className={styles.required}>Project Role</Form.Label>
                              <Form.Select aria-label="Please Select Project"{...register("ProjectRole")} isInvalid={ !!errors.ProjectRole }>
                                <option value="">Please Select</option>
                                <option value="Senior Project Manager">Senior Project Manager</option> 
                                <option value="Project Manager">Project Manager</option> 
                                <option value="Assistant Project Manager">Assistant Project Manager</option> 
                                <option value="Project Administrator">Project Administrator</option> 
                                <option value="Project Engineer">Project Engineer</option> 
                                <option value="Construction Manager">Construction Manager</option> 
                                <option value="Design Engineer">Design Engineer</option> 
                                <option value="Project Billing Coordinator">Project Billing Coordinator</option> 
                                <option value="Other">Other</option> 
                              </Form.Select>
                              <Form.Control.Feedback type="invalid">
                                {errors.ProjectRole?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                          <Col>
                            <Form.Group className="mb-3" >
                              <Form.Label>Fax Number</Form.Label>
                              <Form.Control type="text" {...register("FaxNumber")}/>
                            </Form.Group>
                          </Col>
                        </Row>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>Recipient</Card.Header>
                      <Card.Body>
                        <Row>
                          <Col>
                            <Form.Group className="mb-3" >
                              <Form.Label className={styles.required}>Company Name</Form.Label>
                              <Form.Control type="text" {...register("CompanyName")} isInvalid={ !!errors.CompanyName }/>
                              <Form.Control.Feedback type="invalid">
                                {errors.CompanyName?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                        </Row>
                        <Row>
                          <Col>
                            <Form.Group className="mb-3" >
                              <Form.Label className={styles.required}>Attn</Form.Label>
                              <Form.Control type="text" {...register("Attn")} isInvalid={ !!errors.Attn }/>
                              <Form.Control.Feedback type="invalid">
                                {errors.Attn?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                        </Row>
                        <Row>
                          <Col>
                            <Form.Group className="mb-3" >
                              <Form.Label>Address</Form.Label>
                              <Form.Control as="textarea" rows={3} {...register("Address")}/>
                            </Form.Group>
                          </Col>
                        </Row>
                        <Row>
                          <Col>
                            <Form.Group className="mb-3" >
                              <Form.Label >Phone</Form.Label>
                              <Form.Control type="text" {...register("Phone")}/>
                            </Form.Group>
                          </Col>
                        </Row>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row>
                  <Col>
                      <Card>
                        <Card.Header>Contents</Card.Header>
                        <Card.Body>
                          <Form.Group className="mb-3">
                            <Form.Label className={styles.required}>Number of Items</Form.Label>
                            <Form.Select aria-label="Please Select Project" defaultValue={1} {...register("NumberofItems")} onChange={(e) => {setNIS(e.currentTarget.value)}} isInvalid={ !!errors.NumberofItems }>
                              <option value="1">1</option>
                              <option value="2">2</option>
                              <option value="3">3</option>
                              <option value="4">4</option>
                              <option value="5">5</option>
                            </Form.Select>
                            <Form.Control.Feedback type="invalid">
                              {errors.NumberofItems?.message}
                            </Form.Control.Feedback>
                          </Form.Group>
                          <Row>
                            <Col>
                              <Card className='mb-2'>
                                <Card.Header>Item 1</Card.Header>
                                <Card.Body>
                                  <Row>
                                    <Col>
                                      <Form.Group className="mb-3">
                                        <Form.Label className={styles.required}>Item</Form.Label>
                                        <Form.Select aria-label="Please Select Project" {...register("Item1Item")} isInvalid={ !!errors.Item1Item }>
                                          <option value="">Please Select</option>
                                          <option value="Agreement(s)">Agreement(s)</option>
                                          <option value="ASI (Arch. Supp. Instrument)">ASI (Arch. Supp. Instrument)</option>
                                          <option value="Bulletin">Bulletin</option>
                                          <option value="Clarification">Clarification</option>
                                          <option value="Change Order">Change Order</option>
                                          <option value="Close Out Document(s) - as-built; punch list; owner manual; etc">Close Out Document(s) - as-built; punch list; owner manual; etc</option>
                                          <option value="Design Document(s)">Design Document(s)</option>
                                          <option value="NA">NA</option>
                                          <option value="Other">Other</option>
                                          <option value="Owner Submittal">Owner Submittal</option>
                                          <option value="Payment Application">Payment Application</option>
                                          <option value="Report(s)">Report(s)</option>
                                          <option value="Request for Quote (RFQ)">Request for Quote (RFQ)</option>
                                          <option value="Specifications">Specifications</option>
                                          <option value="Submittal">Submittal</option>
                                          <option value="Utility Interconnect Documentation">Utility Interconnect Documentation</option>
                                          <option value="Work Order">Work Order</option>
                                          <option value="Bonds">Bonds</option>
                                          <option value="Insurance">Insurance</option>
                                        </Form.Select>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item1Item?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                      <Form.Group className="mb-3" >
                                        <Form.Label className={styles.required}>Description</Form.Label>
                                        <Form.Control type="text"  {...register("Item1Description")} isInvalid={ !!errors.Item1Description }/>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item1Description?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                    <Form.Group className="mb-4" >
                                      <Form.Label className={styles.required}>File Date</Form.Label>
                                      <DatePicker 
                                        className='form-control' 
                                        allowClear={true}
                                        format={"MMM DD, YYYY"}
                                        {...register("Item1FileDate")}
                                        onChange={(e): void => {  if(e){ setValue("Item1FileDate", DTFormat(e.toString()),  { shouldValidate: true }) } }} 
                                        />
                                      <p className="link-danger"> {errors.Item1FileDate?.message}</p>
                                    </Form.Group>
                                    </Col>
                                    <Col>
                                      <Form.Group className="mb-3" >
                                        <Form.Label className={styles.required}>Number of Copies</Form.Label>
                                        <Form.Control type="text"  {...register("Item1NumCopies")} isInvalid={ !!errors.Item1NumCopies }/>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item1NumCopies?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                </Card.Body>
                              </Card>
                              <Card className='mb-2' hidden={NIS === "2" || NIS === "3" || NIS === "4" || NIS === "5" ? false : true }>
                                <Card.Header>Item 2</Card.Header>
                                <Card.Body>
                                  <Row>
                                    <Col>
                                      <Form.Group className="mb-3">
                                        <Form.Label className={styles.required}>Item</Form.Label>
                                        <Form.Select aria-label="Please Select Project" {...register("Item2Item")} isInvalid={ !!errors.Item2Item }>
                                          <option value="">Please Select</option>
                                          <option value="Agreement(s)">Agreement(s)</option>
                                          <option value="ASI (Arch. Supp. Instrument)">ASI (Arch. Supp. Instrument)</option>
                                          <option value="Bulletin">Bulletin</option>
                                          <option value="Clarification">Clarification</option>
                                          <option value="Change Order">Change Order</option>
                                          <option value="Close Out Document(s) - as-built; punch list; owner manual; etc">Close Out Document(s) - as-built; punch list; owner manual; etc</option>
                                          <option value="Design Document(s)">Design Document(s)</option>
                                          <option value="NA">NA</option>
                                          <option value="Other">Other</option>
                                          <option value="Owner Submittal">Owner Submittal</option>
                                          <option value="Payment Application">Payment Application</option>
                                          <option value="Report(s)">Report(s)</option>
                                          <option value="Request for Quote (RFQ)">Request for Quote (RFQ)</option>
                                          <option value="Specifications">Specifications</option>
                                          <option value="Submittal">Submittal</option>
                                          <option value="Utility Interconnect Documentation">Utility Interconnect Documentation</option>
                                          <option value="Work Order">Work Order</option>
                                          <option value="Bonds">Bonds</option>
                                          <option value="Insurance">Insurance</option>
                                        </Form.Select>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item2Item?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                      <Form.Group className="mb-3" >
                                        <Form.Label className={styles.required}>Description</Form.Label>
                                        <Form.Control type="text"  {...register("Item2Description")} isInvalid={ !!errors.Item2Description }/>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item2Description?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                    <Form.Group className="mb-4" >
                                      <Form.Label className={styles.required}>File Date</Form.Label>
                                      <DatePicker 
                                        className='form-control' 
                                        allowClear={true}
                                        format={"MMM DD, YYYY"}
                                        {...register("Item2FileDate")}
                                        onChange={(e): void => {  if(e){ setValue("Item2FileDate", DTFormat(e.toString()),  { shouldValidate: true }) } }} 
                                        />
                                      <p className="link-danger"> {errors.Item2FileDate?.message}</p>
                                    </Form.Group>
                                    </Col>
                                    <Col>
                                      <Form.Group className="mb-3" >
                                        <Form.Label className={styles.required}>Number of Copies</Form.Label>
                                        <Form.Control type="text"  {...register("Item2NumCopies")} isInvalid={ !!errors.Item2NumCopies }/>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item2NumCopies?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                </Card.Body>
                              </Card>
                              <Card className='mb-2' hidden={ NIS === "3" || NIS === "4" || NIS === "5" ? false : true }>
                                <Card.Header>Item 3</Card.Header>
                                <Card.Body>
                                  <Row>
                                    <Col>
                                      <Form.Group className="mb-3">
                                        <Form.Label className={styles.required}>Item</Form.Label>
                                        <Form.Select aria-label="Please Select Project" {...register("Item3Item")} isInvalid={ !!errors.Item3Item }>
                                          <option value="">Please Select</option>
                                          <option value="Agreement(s)">Agreement(s)</option>
                                          <option value="ASI (Arch. Supp. Instrument)">ASI (Arch. Supp. Instrument)</option>
                                          <option value="Bulletin">Bulletin</option>
                                          <option value="Clarification">Clarification</option>
                                          <option value="Change Order">Change Order</option>
                                          <option value="Close Out Document(s) - as-built; punch list; owner manual; etc">Close Out Document(s) - as-built; punch list; owner manual; etc</option>
                                          <option value="Design Document(s)">Design Document(s)</option>
                                          <option value="NA">NA</option>
                                          <option value="Other">Other</option>
                                          <option value="Owner Submittal">Owner Submittal</option>
                                          <option value="Payment Application">Payment Application</option>
                                          <option value="Report(s)">Report(s)</option>
                                          <option value="Request for Quote (RFQ)">Request for Quote (RFQ)</option>
                                          <option value="Specifications">Specifications</option>
                                          <option value="Submittal">Submittal</option>
                                          <option value="Utility Interconnect Documentation">Utility Interconnect Documentation</option>
                                          <option value="Work Order">Work Order</option>
                                          <option value="Bonds">Bonds</option>
                                          <option value="Insurance">Insurance</option>
                                        </Form.Select>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item3Item?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                      <Form.Group className="mb-3" >
                                        <Form.Label className={styles.required}>Description</Form.Label>
                                        <Form.Control type="text"  {...register("Item3Description")} isInvalid={ !!errors.Item3Description }/>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item3Description?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                    <Form.Group className="mb-4" >
                                      <Form.Label className={styles.required}>File Date</Form.Label>
                                      <DatePicker 
                                        className='form-control' 
                                        allowClear={true}
                                        format={"MMM DD, YYYY"}
                                        {...register("Item3FileDate")}
                                        onChange={(e): void => {  if(e){ setValue("Item3FileDate", DTFormat(e.toString()),  { shouldValidate: true }) } }} 
                                        />
                                      <p className="link-danger"> {errors.Item3FileDate?.message}</p>
                                    </Form.Group>
                                    </Col>
                                    <Col>
                                      <Form.Group className="mb-3" >
                                        <Form.Label className={styles.required}>Number of Copies</Form.Label>
                                        <Form.Control type="text"  {...register("Item3NumCopies")} isInvalid={ !!errors.Item3NumCopies }/>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item3NumCopies?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                </Card.Body>
                              </Card>
                              <Card className='mb-2' hidden={ NIS === "4" || NIS === "5" ? false : true }>
                                <Card.Header>Item 4</Card.Header>
                                <Card.Body>
                                  <Row>
                                    <Col>
                                      <Form.Group className="mb-3">
                                        <Form.Label className={styles.required}>Item</Form.Label>
                                        <Form.Select aria-label="Please Select Project" {...register("Item4Item")} isInvalid={ !!errors.Item4Item }>
                                          <option value="">Please Select</option>
                                          <option value="Agreement(s)">Agreement(s)</option>
                                          <option value="ASI (Arch. Supp. Instrument)">ASI (Arch. Supp. Instrument)</option>
                                          <option value="Bulletin">Bulletin</option>
                                          <option value="Clarification">Clarification</option>
                                          <option value="Change Order">Change Order</option>
                                          <option value="Close Out Document(s) - as-built; punch list; owner manual; etc">Close Out Document(s) - as-built; punch list; owner manual; etc</option>
                                          <option value="Design Document(s)">Design Document(s)</option>
                                          <option value="NA">NA</option>
                                          <option value="Other">Other</option>
                                          <option value="Owner Submittal">Owner Submittal</option>
                                          <option value="Payment Application">Payment Application</option>
                                          <option value="Report(s)">Report(s)</option>
                                          <option value="Request for Quote (RFQ)">Request for Quote (RFQ)</option>
                                          <option value="Specifications">Specifications</option>
                                          <option value="Submittal">Submittal</option>
                                          <option value="Utility Interconnect Documentation">Utility Interconnect Documentation</option>
                                          <option value="Work Order">Work Order</option>
                                          <option value="Bonds">Bonds</option>
                                          <option value="Insurance">Insurance</option>
                                        </Form.Select>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item4Item?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                      <Form.Group className="mb-3" >
                                        <Form.Label className={styles.required}>Description</Form.Label>
                                        <Form.Control type="text"  {...register("Item4Description")} isInvalid={ !!errors.Item4Description }/>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item4Description?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                    <Form.Group className="mb-4" >
                                      <Form.Label className={styles.required}>File Date</Form.Label>
                                      <DatePicker 
                                        className='form-control' 
                                        allowClear={true}
                                        format={"MMM DD, YYYY"}
                                        {...register("Item4FileDate")}
                                        onChange={(e): void => {  if(e){ setValue("Item4FileDate", DTFormat(e.toString()),  { shouldValidate: true }) } }} 
                                        />
                                      <p className="link-danger"> {errors.Item4FileDate?.message}</p>
                                    </Form.Group>
                                    </Col>
                                    <Col>
                                      <Form.Group className="mb-3" >
                                        <Form.Label className={styles.required}>Number of Copies</Form.Label>
                                        <Form.Control type="text"  {...register("Item4NumCopies")} isInvalid={ !!errors.Item4NumCopies }/>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item4NumCopies?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                </Card.Body>
                              </Card>
                              <Card className='mb-2' hidden={ NIS === "5" ? false : true }>
                                <Card.Header>Item 5</Card.Header>
                                <Card.Body>
                                  <Row>
                                    <Col>
                                      <Form.Group className="mb-3">
                                        <Form.Label className={styles.required}>Item</Form.Label>
                                        <Form.Select aria-label="Please Select Project" {...register("Item5Item")} isInvalid={ !!errors.Item5Item }>
                                          <option value="">Please Select</option>
                                          <option value="Agreement(s)">Agreement(s)</option>
                                          <option value="ASI (Arch. Supp. Instrument)">ASI (Arch. Supp. Instrument)</option>
                                          <option value="Bulletin">Bulletin</option>
                                          <option value="Clarification">Clarification</option>
                                          <option value="Change Order">Change Order</option>
                                          <option value="Close Out Document(s) - as-built; punch list; owner manual; etc">Close Out Document(s) - as-built; punch list; owner manual; etc</option>
                                          <option value="Design Document(s)">Design Document(s)</option>
                                          <option value="NA">NA</option>
                                          <option value="Other">Other</option>
                                          <option value="Owner Submittal">Owner Submittal</option>
                                          <option value="Payment Application">Payment Application</option>
                                          <option value="Report(s)">Report(s)</option>
                                          <option value="Request for Quote (RFQ)">Request for Quote (RFQ)</option>
                                          <option value="Specifications">Specifications</option>
                                          <option value="Submittal">Submittal</option>
                                          <option value="Utility Interconnect Documentation">Utility Interconnect Documentation</option>
                                          <option value="Work Order">Work Order</option>
                                          <option value="Bonds">Bonds</option>
                                          <option value="Insurance">Insurance</option>
                                        </Form.Select>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item5Item?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                      <Form.Group className="mb-3" >
                                        <Form.Label className={styles.required}>Description</Form.Label>
                                        <Form.Control type="text"  {...register("Item5Description")} isInvalid={ !!errors.Item5Description }/>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item5Description?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                    <Form.Group className="mb-4" >
                                      <Form.Label className={styles.required}>File Date</Form.Label>
                                      <DatePicker 
                                        className='form-control' 
                                        allowClear={true}
                                        format={"MMM DD, YYYY"}
                                        {...register("Item5FileDate")}
                                        onChange={(e): void => {  if(e){ setValue("Item5FileDate", DTFormat(e.toString()),  { shouldValidate: true }) } }} 
                                        />
                                      <p className="link-danger"> {errors.Item5FileDate?.message}</p>
                                    </Form.Group>
                                    </Col>
                                    <Col>
                                      <Form.Group className="mb-3" >
                                        <Form.Label className={styles.required}>Number of Copies</Form.Label>
                                        <Form.Control type="text"  {...register("Item5NumCopies")} isInvalid={ !!errors.Item5NumCopies }/>
                                        <Form.Control.Feedback type="invalid">
                                          {errors.Item5NumCopies?.message}
                                        </Form.Control.Feedback>
                                      </Form.Group>
                                    </Col>
                                  </Row>
                                </Card.Body>
                              </Card>
                            </Col>
                          </Row>
                          <Row>
                            <Col>
                              <Form.Group className="mb-3">
                                <Form.Label className={styles.required}>These are transmitted</Form.Label>
                                <Form.Select aria-label="Please Select Project" {...register("Transmittedas")} isInvalid={ !!errors.Transmittedas }>
                                  <option value="">Please select</option>
                                  <option value="Information">As Information</option>
                                  <option value="Requested">As Requested</option>
                                  <option value="For Approval">For Approval</option>
                                  <option value="For Payment">For Payment</option>
                                  <option value="Other">Other</option>
                                </Form.Select>
                                <Form.Control.Feedback type="invalid">
                                  {errors.Transmittedas?.message}
                                </Form.Control.Feedback>
                              </Form.Group>
                            </Col>
                          </Row>
                          <Row>
                            <Col>
                              <Form.Group className="mb-3">
                                <Form.Label>Remarks</Form.Label>
                                <Form.Control as="textarea" rows={3} {...register("Remarks")} />
                              </Form.Group>
                            </Col>
                          </Row>
                        </Card.Body>
                      </Card>
                  </Col>
                </Row>
                <Row className='mt-4'>
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label >Attachments</Form.Label>
                      <Form.Control type="file" id="FileAttachment" multiple />
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>CC Users</Card.Header>
                      <Card.Body>
                      <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                        <Form.Group className="mb-3" >
                          <Form.Check
                            inline
                            label="Yes"
                            value="true"
                            {...register("CCUser")} 
                            onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                          />
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label className={styles.required}>Email Addresses</Form.Label>
                          <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CCEmails?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("CCComment")} />
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row className="mb-4">
                  <Col>
                    <div className="d-grid gap-2">
                      <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting } >
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden={ !!isSubmitting }
                        className={ "visually-hidden" } />
                      { isSubmitting ? "...Submitting" : "SUBMIT" }
                      </Button>
                    </div>
                  </Col>
                </Row>
                { ShowSuccess && (
                    <Alert 
                      key={ MessageType } 
                      variant={ MessageType } 
                      dismissible 
                      onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                        { message }
                    </Alert>
                )}
              </Card.Body>
            </Card>
          </Container>
       </form>
       <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
        <Modal.Header>
          <Modal.Title>SharePoint</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Alert variant="primary">
            <Alert.Heading>{ message }</Alert.Heading>
            <p hidden={MessageType === "danger" ? true : false}>
              Thank you! You can now close this tab or window.
            </p>
          </Alert>
        </Modal.Body>
        <Modal.Footer hidden={MessageType === "danger" ? false : true}>
          <Button variant="secondary" onClick={handleClose}>
            Continue
          </Button>
        </Modal.Footer>
      </Modal>
    </section>
  );
}