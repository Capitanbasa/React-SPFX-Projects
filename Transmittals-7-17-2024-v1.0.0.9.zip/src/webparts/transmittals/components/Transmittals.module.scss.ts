/* tslint:disable */
require("./Transmittals.module.css");
const styles = {
  transmittals: 'transmittals_2ec72ada',
  teams: 'teams_2ec72ada',
  welcome: 'welcome_2ec72ada',
  welcomeImage: 'welcomeImage_2ec72ada',
  links: 'links_2ec72ada',
  buttons: 'buttons_2ec72ada',
  required: 'required_2ec72ada',
  divDropArea: 'divDropArea_2ec72ada'
};

export default styles;
/* tslint:enable */