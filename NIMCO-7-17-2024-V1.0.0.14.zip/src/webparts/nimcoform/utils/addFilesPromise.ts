import { getSP } from "./pnpjsConfig";
import "@pnp/sp/webs";
import "@pnp/sp/lists/web";
import "@pnp/sp/items";
import "@pnp/sp/attachments";

const addFilesPromise = async (SPList:string, itemID: number, file: FileList, index:number ):Promise<string> => {
    const sp = getSP();
    return await sp.web.lists.getByTitle(SPList).items.getById(itemID)
        .attachmentFiles.add(file[index].name, file[index])
        .then(() =>{ return Promise.resolve("Done uploading:" +file[index].name) } )
        .catch((error)=>{ console.log(error.error.message); return Promise.reject(error) });
}
export default addFilesPromise;

export const addFilesPromiseRename = async (SPList:string, itemID: number, file: FileList, index:number, prefix:string = "" ):Promise<string> => {
    const sp = getSP();
    let filename = file[index].name;
    if(prefix !== ""){
        filename = prefix+file[index].name;
    }
    return await sp.web.lists.getByTitle(SPList).items.getById(itemID)
        .attachmentFiles.add(filename, file[index])
        .then(() =>{ return Promise.resolve("Done uploading:" +filename) } )
        .catch((error)=>{ console.log(error.error.message); return Promise.reject(error) });
}

