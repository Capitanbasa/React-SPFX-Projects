import * as yup from 'yup';

export const nimcoFormSchema = yup.object().shape({
    Stage: yup.string().default("Procurement Plannning").notRequired(),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),
    ProjectName: yup.string().required("Project Number - Project Name is required"),
    RequesterName: yup.string().required("Requester Name is required"),
    RequesterEmail: yup.string().required().email("Requester Email is required"),
    Subject: yup.string().required("Subject is required"),
    ProposedVendor: yup.string().required("Vendor Range is required"),
    Vendor: yup.string().required("Vendor is required"),

    Category:yup.string().required("NIMCO Category is required"),
    PONumber:yup.string().required("PO# is required"),
    EstimatedPricing: yup.number().default(0).notRequired(),
    SupplierContactName:yup.string().notRequired(),
    SupplierEmail:yup.string().notRequired(),
    ContactNeedCopy:yup.string().notRequired(),
    ContactReplacement:yup.string().notRequired(),
    Contacttoberemoved: yup.string().when('ContactReplacement', {is: (cr: string) => cr==="Yes", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    RequestedOnsiteDate: yup.string().required("Requested Onsite Date is required"),
    EstimatedLeadTime:yup.string().notRequired(),
    EstimatedTransitTime: yup.string().notRequired(),
    DeliveryAddressLocation: yup.string().notRequired(),
    Notesforprocurement: yup.string().notRequired(),
    NumberofLineItems: yup.string().required("Number of Line Item is required"),

    TaskCodeItem1: yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "1" || itemcount === "2" || itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem1: yup.string().notRequired(),
    DescriptionItem1:yup.string().notRequired(),

    TaskCodeItem2: yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "2" || itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem2: yup.string().notRequired(),
    DescriptionItem2:yup.string().notRequired(),

    TaskCodeItem3:yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem3: yup.string().notRequired(),
    DescriptionItem3:yup.string().notRequired(),

    TotalAmount: yup.string().notRequired(),

    fileLineItem: yup.mixed().when('NumberofLineItems', {is: (itemcount:string) => itemcount === "more", then: () => yup.mixed().test("fileLineItem", "You need to provide a Attach Line Items Template file", (file:FileList) => { if(file?.length > 0) { return true;}else{ return false;} }), otherwise: () => yup.mixed().notRequired() }),
    TechnicalSpecNotes: yup.string().notRequired(),
    SkipReview: yup.string().required("Skip Review is Required"),

    TCName: yup.string().notRequired(),
    TCCompany: yup.string().notRequired(),
    TCEmail: yup.string().notRequired(),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TnimcoFormSchema = yup.InferType<typeof nimcoFormSchema>

export const nimcoFormPPSchema = yup.object().shape({
    Stage: yup.string().required("Outcome is required"),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),

    ProcurementStrategy: yup.string().required("Procurement Strategy is required"),
    Notesforprocurement: yup.string().notRequired(),
    POIssueDate: yup.string().notRequired(),
    RequestedOnsiteDate: yup.string().notRequired(),
    EstimatedLeadTime:yup.string().notRequired(),
    EstimatedTransitTime: yup.string().notRequired(),
    DeliveryAddressLocation: yup.string().notRequired(),
    DelegatedTo: yup.string().when('Stage', {is: (stage:string) => stage === "Delegate", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    ReviseComment: yup.string().when('Stage', {is: (stage:string) => stage === "Revise", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    CloseComment: yup.string().when('Stage', {is: (stage:string) => stage === "Close", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    PRCreatorClaims: yup.string().when('Stage', {is: (stage:string) => stage === "PO Creation", then: () => yup.string().required("PR Creator is required"), otherwise: () => yup.string().notRequired()}),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TnimcoFormPPSchema = yup.InferType<typeof nimcoFormPPSchema>

export const nimcoFormPRSchema = yup.object().shape({
    Stage: yup.string().required("Outcome is required"),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),

    InitialQuotedAmount: yup.string().required("This is required"),
    ApprovedPOAmount: yup.string().required("This is required"),
    NeedtoRevisetaskcode: yup.string().required("This is required"),
    ReasonTCRevision: yup.string().when('NeedtoRevisetaskcode', {is: (ntrtc: string) => ntrtc==="Yes", then: () =>  yup.string().required("This is required"), otherwise: () => yup.string().notRequired() }),
    PRNumber: yup.string().notRequired(),
    TaskCodeItem1: yup.string().notRequired(),
    TaskCodeItem2: yup.string().notRequired(),
    TaskCodeItem3: yup.string().notRequired(),
    PRCreationDate: yup.string().notRequired(),
    PRApprovalDate: yup.string().notRequired(),
    Notesforprocurement: yup.string().notRequired(),

    DelegatedTo: yup.string().when('Stage', {is: (stage:string) => stage === "Delegate", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    ReviseComment: yup.string().when('Stage', {is: (stage:string) => stage === "Revise", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TnimcoFormPRSchema = yup.InferType<typeof nimcoFormPRSchema>

export const nimcoFormPOSchema = yup.object().shape({
    Stage: yup.string().required("Outcome is required"),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),

    Notesforprocurement: yup.string().notRequired(),
    ApprovedPOAmount: yup.string().required("This is required"),
    PONumber: yup.string().notRequired(),
    filePODoc: yup.mixed().test("filePODoc", "PO Document is required", (file:FileList) => { if(file?.length > 0) { return true;}else{ return false;} }),
    POPromiseDate: yup.string().required("PO Promise Date is required"),
    POApprovalDate: yup.string().required("PO Approval Date is required"),
    PoPDateChangeReason: yup.string().required("PO Promise Date Change Reason is required"),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TnimcoFormPOSchema = yup.InferType<typeof nimcoFormPOSchema>

export const nimcoFormADRSchema = yup.object().shape({
    Stage: yup.string().required("Outcome is required"),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),

    ReviewResponseFinal: yup.string().required("Review Response Final is required"),
    ApprovingEORFinal: yup.string().required("Approving EOR Final is required"),
    ReviewCommentsFinal: yup.string().notRequired(),
    ADRReviseComment: yup.string().when('Stage', {is: (stage: string) => stage==="Revise", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    ADRCloseComment: yup.string().when('Stage', {is: (stage: string) => stage==="Close", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    ReviseComment:yup.string().notRequired(),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TnimcoFormADRSchema = yup.InferType<typeof nimcoFormADRSchema>

export const nimcoFormIRSchema = yup.object().shape({
    Stage: yup.string().required("Outcome is required"),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),

    PONumber:yup.string().required("PO# is required"),
    EstimatedPricing: yup.string().notRequired(),
    SupplierContactName:yup.string().notRequired(),
    SupplierEmail:yup.string().notRequired(),
    ContactNeedCopy:yup.string().notRequired(),
    ContactReplacement:yup.string().notRequired(),
    Contacttoberemoved: yup.string().when('ContactReplacement', {is: (cr: string) => cr==="Yes", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    RequestedOnsiteDate: yup.string().required("Requested Onsite Date is required"),
    EstimatedLeadTime:yup.string().notRequired(),
    EstimatedTransitTime: yup.string().notRequired(),
    DeliveryAddressLocation: yup.string().notRequired(),
    Notesforprocurement: yup.string().notRequired(),
    NumberofLineItems: yup.string().required("Number of Line Item is required"),

    TaskCodeItem1: yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "1" || itemcount === "2" || itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem1: yup.string().notRequired(),
    DescriptionItem1:yup.string().notRequired(),

    TaskCodeItem2: yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "2" || itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem2: yup.string().notRequired(),
    DescriptionItem2:yup.string().notRequired(),

    TaskCodeItem3:yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem3: yup.string().notRequired(),
    DescriptionItem3:yup.string().notRequired(),

    TotalAmount: yup.string().notRequired(),

    fileLineItem: yup.mixed().when('NumberofLineItems', {is: (itemcount:string) => itemcount === "more", then: () => yup.mixed().test("fileLineItem", "You need to provide a Attach Line Items Template file", (file:FileList) => { if(file?.length > 0) { return true;}else{ return false;} }), otherwise: () => yup.mixed().notRequired() }),
    TechnicalSpecNotes: yup.string().notRequired(),
    SkipReview: yup.string().required("Skip Review is Required"),

    TCName: yup.string().notRequired(),
    TCCompany: yup.string().notRequired(),
    TCEmail: yup.string().notRequired(),

    CloseComment: yup.string().when('Stage', {is: (stage:string) => stage === "Close", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TnimcoFormIRSchema = yup.InferType<typeof nimcoFormIRSchema>

export interface IWrorkFlow{
    Id?: number;
    itemID?: string;
    Transaction?: string;
    Stage: string;
    Status:string;
    flag?: string;
}

export interface IDelegateItem{
    id: string;
    imageInitials: string;
    imageUrl: string;
    loginName:string;
    optionalText:string;
    secondaryText:string;
    tertiaryText:string;
    text:string;
}

export interface IPRCreatorList{
    id: string;
    Email: string;
    TransactionType: string;
}