declare interface INimcoformWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  AppLocalEnvironmentSharePoint: string;
  AppLocalEnvironmentTeams: string;
  AppLocalEnvironmentOffice: string;
  AppLocalEnvironmentOutlook: string;
  AppSharePointEnvironment: string;
  AppTeamsTabEnvironment: string;
  AppOfficeEnvironment: string;
  AppOutlookEnvironment: string;
  UnknownEnvironment: string;
  PanePropsNimcoList:string;
  PanePropsProjectNumberName:string;
  PanePropsPropsedVendor:string;
  PanePropsTaskCodeList:string;
  PanePropsCreatorList: string;
}

declare module 'NimcoformWebPartStrings' {
  const strings: INimcoformWebPartStrings;
  export = strings;
}
