import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface INimcoformProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  spContext: WebPartContext;
  spProjectListItems?: IProjectListItem[];
  PanePropsProjectNumberName: string;
  PanePropsNimcoList:string;
  PanePropsPropsedVendor:string;
  userEmail?:string;
  spNimcoItem:INimcoListItems[];
  spTaskCodeListItems: ITaskCodes[];
  PanePropsCreatorList: string;
  spView:boolean;
}

export interface IProjectListItem{
  id: string;
  ProjectName: string;
}
export interface IProposeVendor{
  id: string;
  VendorName: string;
  Range: string;
}

export interface ITaskCodes {
  id:string;
  TaskCode: string;
}


export interface INimcoListItems{
  AssignedTo:string;
  AssignedToId:number;
  PRCreatorClaims:string;
  PRCreatorId:number;
  Id: string;
  Stage: string;
  Status: string;
  ProjectName:string;
  RequesterName: string;
  RequesterEmail: string;
  Subject: string;
  CCUser: string;
  CCEmails?: string;
  CCComment?:string;
  flag:string;
  Vendor:string;
  Category:string;
  PONumber:string;
  EstimatedPricing:number;
  SupplierContactName:string;
  SupplierEmail:string;
  ContactNeedCopy:string;
  ContactReplacement:string;
  Contacttoberemoved:string;
  RequestedOnsiteDate:string;
  EstimatedLeadTime:string;
  EstimatedTransitTime:string;
  DeliveryAddressLocation:string;
  Notesforprocurement:string;
  NumberofLineItems:string;
  TaskCodeItem1: string;
  InitialAmountItem1: string;
  DescriptionItem1: string;
  TaskCodeItem2: string;
  InitialAmountItem2: string;
  DescriptionItem2: string;
  TaskCodeItem3: string;
  InitialAmountItem3: string;
  DescriptionItem3: string;
  TotalAmount: string;
  TechnicalSpecNotes: string;
  SkipReview:string;
  POIssueDate:string;
  ProcurementStrategy:string;
  ReviseComment:string;
  DelegatedTo:string;
  CloseComment:string;
  InitialQuotedAmount: string;
  ApprovedPOAmount:  string;
  NeedtoRevisetaskcode:string;
  PRNumber:string;
  PRCreationDate:string;
  PRApprovalDate:string;
  POPromiseDate:string;
  POApprovalDate:string;
  ReviewResponseFinal:string;
  ApprovingEORFinal:string;
  ReviewCommentsFinal:string;
  ADRReviseComment: string;
  ADRCloseComment:string;
  TCName:string;
  TCCompany:string;
  TCEmail:string;
}
