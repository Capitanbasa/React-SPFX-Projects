import * as React from 'react';
import styles from './Nimcoform.module.scss';
import type { INimcoformProps } from './INimcoformProps';
import { Alert, Button, Card, Col, Container, Form, InputGroup, Modal, Row, Spinner } from 'react-bootstrap';
import {  TnimcoFormPRSchema, nimcoFormPRSchema } from '../utils/types';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup"
import { getSP } from '../utils/pnpjsConfig';
import WorkFlowSubmit from '../utils/WorkFlowSubmit';
import { DatePicker } from 'antd';
import { IAttachmentInfo } from '@pnp/sp/attachments';
import { IoDocumentAttachOutline } from "react-icons/io5";
import { IPeoplePickerContext, PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";

export default function NimcoformPR(Props:INimcoformProps):React.ReactElement{
  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [CCGroup, setCCGroup ] = React.useState(false);
  const [theAttachmentFiles, settheAttachmentFiles] = React.useState<IAttachmentInfo[]>([]);
  const [nextStage , setnextStage] = React.useState("");
  const [ReviseTaskCode, setReviseTaskCode] = React.useState("No");
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);

  const peoplePickerContext: IPeoplePickerContext = {
    absoluteUrl: Props.spContext.pageContext.web.absoluteUrl,
    msGraphClientFactory: Props.spContext.msGraphClientFactory,
    spHttpClient: Props.spContext.spHttpClient
  };

  let attachments: IAttachmentInfo[] = [];
    React.useEffect(() => {
      async function fecthData():Promise<void>{
        const sp = getSP();
        const item = sp.web.lists.getByTitle(Props.PanePropsNimcoList).items.getById(parseInt(Props.spNimcoItem[0].Id));
        attachments = await item.attachmentFiles().then(async res => {return await res});
        settheAttachmentFiles(attachments);
        console.log("await:",attachments);
      }
      fecthData().catch(console.error);
    },[]);


  const { 
    register, 
    handleSubmit,
    formState: {errors, isSubmitting},
    reset, setValue
  } = useForm<TnimcoFormPRSchema>({
    resolver: yupResolver(nimcoFormPRSchema),
  });

/* eslint-disable  @typescript-eslint/no-explicit-any */
  const _getPeoplePickerDelegate = (items:any[]):void => {
    console.log("Delegated User:",items );
    items.map((item) => { 
      setValue("DelegatedTo", item.loginName);
    });
  }

  const onSubmit = async (data: TnimcoFormPRSchema):Promise<void> => {
    const sp = getSP(Props.spContext);
    data.CCUser = CCGroup === true ? "Yes": "No";
    let newStatus:string = "";
    let newStage:string = "";

    switch(data.Stage){
      case "Revise": newStatus = "Pending"; newStage = "Initiator Revision";break;
      case "PR Approved": newStatus = "Pending"; newStage = "PO Creation"; break;
      case "PR Rejected": newStatus = "Void"; newStage = "Void"; break;
      case "Delegate": newStage = "PR Creation"; newStatus = "Delegate"; break;
      default: newStatus = "Pending"; 
    }
    data.Status = newStatus;
    data.Stage = newStage;
    data.flag = "2";
    console.log("Schema Data:", data);

    await sp.web.lists.getByTitle(Props.PanePropsNimcoList).items.getById(parseInt(Props.spNimcoItem[0].Id)).update(data)
    .then(async (addResult) => {
      console.log("add result:",addResult);
      
      setShowSuccess(true);
      setmessage("Successfully Submitted the Outcome.");
      setMessageType('success');
      const WFresult = await WorkFlowSubmit(Props.spNimcoItem[0].Id, false, newStatus, newStage, "2");
      console.log("WF Result:", WFresult);
      reset();
      setModalShow(true);
      return Promise.resolve;
    }).catch( (error) => {
      console.log("Error Submit:", error);
      setShowSuccess(true);
      setmessage("Sorry! Your Request failed to Submit. Please try again.");
      setMessageType('danger');
      return Promise.reject;
    });
    
  };

  return(
    <section className={`${styles.nimcoform} ${Props.hasTeamsContext ? styles.teams : ''}`}>
      <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
        <fieldset disabled={Props.spView}>
          <Container>
            <Card>
              <Card.Header className="h5">Non-Inventory Materials Change Order</Card.Header>
              <Card.Body>                
                <Card className='mb-4' style={{ width: '100%' }}>
                  <Card.Header className="h5">PR Creation Form</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Project Number and Name</Form.Label>
                          <Form.Control type="text" value={Props.spNimcoItem[0].ProjectName} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Instance Number</Form.Label>
                          <Form.Control type="text" value={Props.spNimcoItem[0].Id} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Requester Name</Form.Label>
                          <Form.Control type="text" value={Props.spNimcoItem[0].RequesterName} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Requester Email</Form.Label>
                          <Form.Control type="text" value={Props.spNimcoItem[0].RequesterEmail} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Subject</Form.Label>
                          <Form.Control type="text"  value={Props.spNimcoItem[0].Subject} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                      <Form.Group className="mb-3">
                        <Form.Label>NIMCO Category</Form.Label>
                        <Form.Control type="text"  value={Props.spNimcoItem[0].Category} disabled/>
                      </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Card className="mb-3" style={{ width: '100%' }}>
                  <Card.Header className="h5">Final Awarded Bid Documents</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Vendor</Form.Label>
                          <Form.Control type="text"  value={Props.spNimcoItem[0].Vendor} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Supplier Contac tName</Form.Label>
                          <Form.Control type="text"  value={Props.spNimcoItem[0].SupplierContactName} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                      <Form.Group className="mb-3">
                        <Form.Label>Supplier Contact E-mail</Form.Label>
                        <Form.Control type="text"  value={Props.spNimcoItem[0].SupplierEmail} disabled/>
                      </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Does the contact need a copy of the PO?</Form.Label>
                          <Form.Control type="text"  value={Props.spNimcoItem[0].ContactNeedCopy} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                      <Form.Group className="mb-3">
                        <Form.Label>Is this contact a replacement of the previous PO receiver?</Form.Label>
                        <Form.Control type="text"  value={Props.spNimcoItem[0].ContactReplacement} disabled/>
                      </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>If Contact Replacement, please specify the contact to be removed</Form.Label>
                          <Form.Control type="text"  value={Props.spNimcoItem[0].Contacttoberemoved} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Initial Quoted Amount</Form.Label>
                          <InputGroup className="mb-3">
                            <InputGroup.Text>$</InputGroup.Text>
                            <Form.Control type="text" {...register("InitialQuotedAmount")} isInvalid={ !!errors.InitialQuotedAmount }/>
                          </InputGroup>
                          <Form.Control.Feedback type="invalid">
                            {errors.InitialQuotedAmount?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                      <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Approved PO Amount</Form.Label>
                          <InputGroup className="mb-3">
                            <InputGroup.Text>$</InputGroup.Text>
                            <Form.Control type="text" {...register("ApprovedPOAmount")} isInvalid={ !!errors.ApprovedPOAmount }/>
                          </InputGroup>
                          <Form.Control.Feedback type="invalid">
                            {errors.ApprovedPOAmount?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Requested On-Site Date</Form.Label>
                          <Form.Control type="text"  value={Props.spNimcoItem[0].RequestedOnsiteDate} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Row className='mt-4'>
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header className="h5">Awarded Quote/ Bid Documents</Card.Header>
                      <Card.Body>
                        <Card.Text>Use this field if you already have a quote and want to proceed directly to the PO Create Step.</Card.Text>
                        <div className="d-grid gap-2">
                        {
                        theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                          if(aFile.FileName.substring(0,27) === "[AwardedQuote-BidDocuments]"){
                            return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                          }})
                        }
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Card className="mb-4" style={{ width: '100%' }}>
                  <Card.Header className="h5">Notes</Card.Header>
                  <Card.Body>
                    <h6>Notes and special directions for procurement:</h6>
                    <Form.Group className="mb-3">
                      <Form.Control as="textarea" rows={3} {...register("Notesforprocurement")} defaultValue={Props.spNimcoItem[0].Notesforprocurement}/>
                    </Form.Group>
                  </Card.Body>
                </Card>
                <Card className="mb-4" style={{ width: '100%' }}>
                  <Card.Body>
                    <Row className='mb-3'>
                      <Col>
                        <h5>LINE ITEMS</h5>
                        <h6>Instruction:</h6>
                        <p>If line items are more than 3, please refer to the attachment else you may check the expandable list.</p>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label># of Line items</Form.Label>
                          <Form.Control type="text" value={Props.spNimcoItem[0].NumberofLineItems === "more" ? "More than 3 Items" : Props.spNimcoItem[0].NumberofLineItems } disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row className='mb-3'>
                      <Col>
                        <Card>
                          <Card.Header className="h5">Initiator Attachments</Card.Header>
                          <Card.Body>
                            <div className="d-grid gap-2">
                            {
                            theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                              if(aFile.FileName.substring(0,10) === "[LineItem]"){
                                return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                              }})
                            }
                            </div>
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Card className="mb-4" style={{ width: '100%' }}>
                  <Card.Header className="h5">Line Items</Card.Header>
                  <Card.Body>
                    <Row className='mb-4'>
                      <Col>
                        <Row>
                          <h6>Line Item 1:</h6>
                          <Col>
                            <Form.Group className="mb-3">
                              <Form.Label className={styles.required}>Task Code</Form.Label>
                              <Form.Select aria-label="Please Select" 
                                {...register("TaskCodeItem1")} 
                                isInvalid={ !!errors.TaskCodeItem1 } 
                                defaultValue={ Props.spNimcoItem[0].TaskCodeItem1}
                                disabled={ ReviseTaskCode === "Yes" ? false : true }>
                                <option value="">Please Select</option>
                                {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                      return  ( 
                                        <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                      );
                                })}
                              </Form.Select>
                              <Form.Control.Feedback type="invalid">
                                {errors.TaskCodeItem1?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                          <Col>
                            <Form.Label>Initial Forecast Amount</Form.Label>
                            <InputGroup className="mb-3">
                              <InputGroup.Text>$</InputGroup.Text>
                              <Form.Control type="text"  value={Props.spNimcoItem[0].InitialAmountItem1} disabled/>
                            </InputGroup>
                          </Col>
                        </Row>
                        <Row>
                          <Col>
                            <Form.Group className="mb-3" >
                              <Form.Label>Description</Form.Label>
                              <Form.Control type="text"  value={Props.spNimcoItem[0].DescriptionItem1} disabled/>
                            </Form.Group>
                          </Col>
                        </Row>
                      </Col>
                    </Row>
                    <Row className='mb-4'>
                      <Col>
                        <Row>
                          <h6>Line Item 2:</h6>
                          <Col>
                            <Form.Group className="mb-3">
                              <Form.Label className={styles.required}>Task Code</Form.Label>
                              <Form.Select aria-label="Please Select" 
                                {...register("TaskCodeItem2")} 
                                isInvalid={ !!errors.TaskCodeItem2 } 
                                defaultValue={ Props.spNimcoItem[0].TaskCodeItem2}
                                disabled={ ReviseTaskCode === "Yes" ? false : true }>
                                <option value="">Please Select</option>
                                {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                      return  ( 
                                        <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                      );
                                })}
                              </Form.Select>
                              <Form.Control.Feedback type="invalid">
                                {errors.TaskCodeItem2?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                          <Col>
                            <Form.Label>Initial Forecast Amount</Form.Label>
                            <InputGroup className="mb-3">
                              <InputGroup.Text>$</InputGroup.Text>
                              <Form.Control type="text"  value={Props.spNimcoItem[0].InitialAmountItem2} disabled/>
                            </InputGroup>
                          </Col>
                        </Row>
                        <Row>
                          <Col>
                            <Form.Group className="mb-3" >
                              <Form.Label>Description</Form.Label>
                              <Form.Control type="text"  value={Props.spNimcoItem[0].DescriptionItem2} disabled/>
                            </Form.Group>
                          </Col>
                        </Row>
                      </Col>
                    </Row>
                    <Row className='mb-4'>
                      <Col>
                        <Row>
                          <h6>Line Item 3:</h6>
                          <Col>
                            <Form.Group className="mb-3">
                              <Form.Label className={styles.required}>Task Code</Form.Label>
                              <Form.Select aria-label="Please Select" 
                                {...register("TaskCodeItem3")} 
                                isInvalid={ !!errors.TaskCodeItem2 } 
                                defaultValue={ Props.spNimcoItem[0].TaskCodeItem3}
                                disabled={ ReviseTaskCode === "Yes" ? false : true }>
                                <option value="">Please Select</option>
                                {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                      return  ( 
                                        <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                      );
                                })}
                              </Form.Select>
                              <Form.Control.Feedback type="invalid">
                                {errors.TaskCodeItem3?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                          <Col>
                            <Form.Label>Initial Forecast Amount</Form.Label>
                            <InputGroup className="mb-3">
                              <InputGroup.Text>$</InputGroup.Text>
                              <Form.Control type="text"  value={Props.spNimcoItem[0].InitialAmountItem3} disabled/>
                            </InputGroup>
                          </Col>
                        </Row>
                        <Row>
                          <Col>
                            <Form.Group className="mb-3" >
                              <Form.Label>Description</Form.Label>
                              <Form.Control type="text"  value={Props.spNimcoItem[0].DescriptionItem3} disabled/>
                            </Form.Group>
                          </Col>
                        </Row>
                      </Col>
                    </Row>
                    <Row className='mb-4'>
                      <Col>
                        <Row>
                          <Col>
                            <Form.Group className="mb-3" >
                              <Form.Label>Total Amount</Form.Label>
                              <Form.Control type="text"  value={Props.spNimcoItem[0].TotalAmount} disabled/>
                            </Form.Group>
                          </Col>
                        </Row>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Row>
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Need to Revise task code?</Form.Label>
                      <Form.Select aria-label="Please Select" {...register("NeedtoRevisetaskcode")} isInvalid={!!errors.NeedtoRevisetaskcode } onChange={(e)=>{setReviseTaskCode(e.currentTarget.value )}} >
                        <option value="">Please Select</option>
                        <option key='revtaskcode1' value="Yes">Yes</option>
                        <option key='revtaskcode2' value="No">No</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.NeedtoRevisetaskcode?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-3" hidden={ReviseTaskCode === "No" ? true : false }>
                      <Form.Label className={styles.required}>Reason for task code revision</Form.Label>
                      <Form.Control as="textarea" rows={3} {...register("ReasonTCRevision")} isInvalid={!!errors.ReasonTCRevision }/>
                      <Form.Text muted>Please be specific with the reason and what changed as Initiator will be notified.</Form.Text>
                      <Form.Control.Feedback type="invalid">
                        {errors.ReasonTCRevision?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>



                <Card className="mb-4" style={{ width: '100%' }}>
                  <Card.Header className="h5">Schedule</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Requested Onsite Date</Form.Label>
                          <Form.Control type="text"  value={Props.spNimcoItem[0].RequestedOnsiteDate} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Estimated Lead Time (weeks)</Form.Label>
                          <Form.Control type="text"  value={Props.spNimcoItem[0].EstimatedLeadTime} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Estimated Transit Time (days)</Form.Label>
                          <Form.Control type="text"  value={Props.spNimcoItem[0].EstimatedTransitTime} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Delivery Address/Location</Form.Label>
                          <Form.Control as="textarea" rows={3} value={Props.spNimcoItem[0].DeliveryAddressLocation} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>

                <Card className="mb-4" style={{ width: '100%' }}>
                  <Card.Header className="h5">PR Tracking</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>PR#</Form.Label>
                          <Form.Control type="text" {...register("PRNumber")} isInvalid={ !!errors.PRNumber }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.PRNumber?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-4" >
                          <Form.Label>PR Creation Date</Form.Label>
                          <DatePicker
                            className='form-control' 
                            allowClear={true}
                            format={"MMM DD, YYYY"}
                            {...register("PRCreationDate")}  
                            onChange={(e): void => {  if(e){ setValue("PRCreationDate", e.format("MMM DD, YYYY").toString(),  { shouldValidate: true }) } }} />

                          <Form.Control.Feedback type="invalid">
                            {errors.PRCreationDate?.message} 
                          </Form.Control.Feedback>
                          <p className="link-danger">{errors.PRCreationDate?.message}</p>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-4" >
                          <Form.Label>PR Approval Date</Form.Label>
                          <DatePicker
                            className='form-control' 
                            allowClear={true}
                            format={"MMM DD, YYYY"}
                            {...register("PRApprovalDate")}  
                            onChange={(e): void => {  if(e){ setValue("PRApprovalDate", e.format("MMM DD, YYYY").toString(),  { shouldValidate: true }) } }} />

                          <Form.Control.Feedback type="invalid">
                            {errors.PRApprovalDate?.message} 
                          </Form.Control.Feedback>
                          <p className="link-danger">{errors.PRApprovalDate?.message}</p>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>

                <Card style={{ width: '100%' }} className='mb-4'>
                  <Card.Body>
                    <Form.Group className="mb-3">
                      <Form.Label className={styles.required}>Skip Review?</Form.Label>
                      <Form.Control type="text"  value={Props.spNimcoItem[0].SkipReview} disabled/>
                    </Form.Group>
                  </Card.Body>
                </Card>

                <Card style={{ width: '100%' }} className='mb-3'>
                  <Card.Header className="h5">Technical Approvers (Consultants / EOR)</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label >Name</Form.Label>
                          <Form.Control type='text'  defaultValue={Props.spNimcoItem[0].TCName} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label >Company</Form.Label>
                          <Form.Control type='text'  defaultValue={Props.spNimcoItem[0].TCCompany} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label >Email</Form.Label>
                          <Form.Control type='email'  defaultValue={Props.spNimcoItem[0].TCEmail} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>

                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header className="h5">CC Users</Card.Header>
                      <Card.Body>
                      <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                        <Form.Group className="mb-3" >
                          <Form.Check
                            inline
                            label="Yes"
                            value="true"
                            {...register("CCUser")} 
                            onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                          />
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label className={styles.required}>Email Addresses</Form.Label>
                          <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CCEmails?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("CCComment")} />
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Card>
                  <Card.Header className="h5">Next Step</Card.Header>
                  <Card.Body>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Outcome</Form.Label>
                      <Form.Select aria-label="Please Select Next Step" {...register("Stage")} isInvalid={!!errors.Stage } onChange={(e)=>{setnextStage(e.currentTarget.value )}} >
                        <option value="">Please Select Next Step</option>
                        <option key='ns1' value="PR Rejected">PR Rejected</option>
                        <option key='ns2' value="PR Approved">PR Approved</option>
                        <option key='ns3' value="Delegate">Delegate</option>
                        <option key='ns4' value="Revise">Initiator Revision</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.Stage?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                    <Row>
                      <Col>
                        <Form.Group className="mb-5" hidden={nextStage === "Delegate" ? false: true}>
                          <PeoplePicker
                            context={peoplePickerContext}
                            {...register("DelegatedTo")}
                            titleText="Choose user to delegate"
                            personSelectionLimit={1}
                            showtooltip={true}
                            required={true}
                            ensureUser={true}
                            onChange={ items => _getPeoplePickerDelegate(items) }
                            principalTypes={[PrincipalType.User]}
                            resolveDelay={1000} />
                          <p className="link-danger">{errors.DelegatedTo?.message}</p>
                        </Form.Group>
                        <Form.Group className="mb-5" hidden={nextStage === "Revise" ? false: true}>
                          <Form.Label>Comments - Revise</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("ReviseComment")} isInvalid={ !!errors.ReviseComment }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.ReviseComment?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Row className="mb-4">
                  <Col>
                    <div className="d-grid gap-2">
                      <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting }>
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden={ !!isSubmitting }
                        className={ "visually-hidden" } />
                      { isSubmitting ? "...Submitting" : "SUBMIT" }
                      </Button>
                    </div>
                  </Col>
                </Row>
                { ShowSuccess && (
                    <Alert 
                      key={ MessageType } 
                      variant={ MessageType } 
                      dismissible 
                      onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                        { message }
                    </Alert>
                )}
              </Card.Body>
            </Card>
          </Container>
        </fieldset>
      </form>
        <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
          <Modal.Header>
            <Modal.Title>SharePoint</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Alert variant="primary">
              <Alert.Heading>{ message }</Alert.Heading>
              <p hidden={MessageType === "danger" ? true : false}>
                Thank you! You can now close this tab or window.
              </p>
            </Alert>
          </Modal.Body>
          <Modal.Footer hidden={MessageType === "danger" ? false : true}>
            <Button variant="secondary" onClick={handleClose}>
              Continue
            </Button>
          </Modal.Footer>
        </Modal>
      </section>
  );
}