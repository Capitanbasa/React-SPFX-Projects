/* tslint:disable */
require("./Nimcoform.module.css");
const styles = {
  nimcoform: 'nimcoform_215aafb4',
  teams: 'teams_215aafb4',
  welcome: 'welcome_215aafb4',
  welcomeImage: 'welcomeImage_215aafb4',
  links: 'links_215aafb4',
  required: 'required_215aafb4',
  divDropArea: 'divDropArea_215aafb4'
};

export default styles;
/* tslint:enable */