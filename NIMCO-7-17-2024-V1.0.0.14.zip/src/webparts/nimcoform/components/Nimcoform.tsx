import * as React from 'react';
import styles from './Nimcoform.module.scss';
import type { INimcoformProps, IProposeVendor } from './INimcoformProps';
import { Alert, Button, Card, Col, Container, Form, Modal, Row, Spinner } from 'react-bootstrap';
import { TnimcoFormSchema, nimcoFormSchema } from '../utils/types';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup"
import { getSP } from '../utils/pnpjsConfig';
import { addFilesPromiseRename } from '../utils/addFilesPromise';
import WorkFlowSubmit from '../utils/WorkFlowSubmit';
import { DatePicker } from 'antd';
// import { DatePicker } from 'antd';
// import * as dayjs from 'dayjs';
//import { escape } from '@microsoft/sp-lodash-subset';

export default function Nimcoform(Props:INimcoformProps):React.ReactElement{
  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [CCGroup, setCCGroup ] = React.useState(false);

  const [Vendor, setVendor] = React.useState<IProposeVendor[]>([]);
  const [ContactReplacement, setContactReplacement] = React.useState("No");
  const [NIS, setNIS ] = React.useState("1");
  const [TotalAmount , setTotalAmount] = React.useState(0);
  const [ItemAmount1 , setItemAmount1] = React.useState(0);
  const [ItemAmount2 , setItemAmount2] = React.useState(0);
  const [ItemAmount3 , setItemAmount3] = React.useState(0);
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);
  const [VendorRange, setVendorRange]  = React.useState("");


  const { 
    register, 
    handleSubmit,
    formState: {errors, isSubmitting},
    reset, setValue
  } = useForm<TnimcoFormSchema>({
    resolver: yupResolver(nimcoFormSchema),
  });

  const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
    if(FileAttachment && FileAttachment?.length > 0){
      for(let i =0; i < FileAttachment.length; i++){
        /* eslint-disable no-useless-escape */
        const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
        if(match){
          setShowSuccess(true);
          setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
          setMessageType('danger');
          return true;
        }else{
          return false;
        }
      }
    }
    return false;
  }

  const onSubmit = async (data: TnimcoFormSchema):Promise<void> => {
    const sp = getSP(Props.spContext);
    //const Attachment = document.getElementById("FileAttachment") as HTMLInputElement;
    const fileAwardedBid = document.getElementById("fileAwardedBid") as HTMLInputElement;
    const fileLineItem = document.getElementById("fileLineItem") as HTMLInputElement;
    const fileTechSpec =  document.getElementById("fileTechSpec") as HTMLInputElement;
   // const Attfiles = Attachment.files;
    const AttfileAwardedBid = fileAwardedBid.files;
    const AttfileLineItem = fileLineItem.files;
    const AttffileTechSpec = fileTechSpec.files;
    if(filenameCharValidation(AttfileAwardedBid)){ return; }
    if(filenameCharValidation(AttfileLineItem)){ return; }
    if(filenameCharValidation(AttffileTechSpec)){ return; }


    data.CCUser = CCGroup === true ? "Yes": "No";
    data.flag = "1";
    data.Stage = "Procurement Planning";
    data.TotalAmount = TotalAmount.toString();
    delete data.fileLineItem;
    console.log("Schema Data:", data);

    await sp.web.lists.getByTitle(Props.PanePropsNimcoList).items.add(data)
    .then(async (addResult) => {
      console.log("add result:",addResult);
      

      if( ( AttfileAwardedBid && AttfileAwardedBid?.length > 0 ) || ( AttfileLineItem && AttfileLineItem?.length > 0 )  || ( AttffileTechSpec && AttffileTechSpec?.length > 0)){
        const PromoseArray = [];
        setShowSuccess(true);
        setmessage("Please wait while we upload the file Attachment.");
        setMessageType('primary');

        // if( Attfiles && Attfiles?.length > 0 ){
        //   for(let i =0; i < Attfiles.length; i++){
        //     const UploadArray = await addFilesPromise( Props.PanePropsSubmittalsList, addResult.ID , Attfiles, i);
        //     PromoseArray.push(UploadArray);
        //   }
        // }
        if( AttfileAwardedBid && AttfileAwardedBid?.length > 0){
          for(let i =0; i < AttfileAwardedBid.length; i++){
            const UploadArrayBid = await addFilesPromiseRename( Props.PanePropsNimcoList, addResult.ID , AttfileAwardedBid, i, "[AwardedQuote-BidDocuments]");
            PromoseArray.push(UploadArrayBid);
          }
        }

        if( AttfileLineItem && AttfileLineItem?.length > 0){
          for(let i =0; i < AttfileLineItem.length; i++){
            const UploadArrayBid = await addFilesPromiseRename( Props.PanePropsNimcoList, addResult.ID , AttfileLineItem, i, "[LineItem]");
            PromoseArray.push(UploadArrayBid);
          }
        }

        if( AttffileTechSpec && AttffileTechSpec?.length > 0){
          for(let i =0; i < AttffileTechSpec.length; i++){
            const UploadArrayBid = await addFilesPromiseRename( Props.PanePropsNimcoList, addResult.ID , AttffileTechSpec, i, "[Tech-Specification]");
            PromoseArray.push(UploadArrayBid);
          }
        }
        Promise.all(PromoseArray).then( res => { 
          console.log("Promise Upload resolve:", res);
          setShowSuccess(true);
          setmessage("Successfully Submitted Your Request.");
          setMessageType('success');
          reset();
        })
        .catch(err => { 
          console.log("Promise Upload reject:", err);
          setShowSuccess(true);
          setmessage("Your Request is Submitted but there was a problem uploading the attachment");
          setMessageType('danger');
          reset();
        });
      }else{
        setShowSuccess(true);
        setmessage("Successfully Submitted Your Request without Attachment.");
        setMessageType('primary');
        reset();
      }
      const WFresult = await WorkFlowSubmit(addResult.ID.toString(), true, "Pending", "Procurement Plannning", "1", data.ProjectName );
      console.log("WF Result:", WFresult);
      reset();
      setModalShow(true);
      return Promise.resolve;
    })
    .catch( (error) => {
        console.log("Error Submit:", error);
        setShowSuccess(true);
        setmessage("Sorry! Your Request failed to Submit. Please try again.");
         setMessageType('danger');
        return Promise.reject;
    });
    
  };

  // React.useEffect(() => {
  //   async function test():Promise<void>{
  //     const sp = getSP(Props.spContext);
  //     const pm:IWrorkFlow[] = await sp.web.lists.getByTitle("Workflow List").items.filter(`itemID eq '4' and Transaction eq 'Submittals'`)();
  //     console.log("WF:",pm);
  //   }
  //   test().catch(console.error);
  // },[]);
    React.useEffect(() => { 
      function updateTotal():void{ setTotalAmount(ItemAmount1 + ItemAmount2 + ItemAmount3) }
      updateTotal();
    },[ItemAmount1, ItemAmount2, ItemAmount3]);

  // const getFIlteredVendor = async (range:string):Promise<void> => {
  //   const sp = getSP(Props.spContext);
  //   const vendorsretult:IProposeVendor[] = await sp.web.lists.getByTitle(Props.PanePropsPropsedVendor).items.select("VendorName", "Id").filter("Range eq '"+range.toString()+"'")();
  //   setVendor(vendorsretult);
  // }

  React.useEffect(() => {
    async function getAllVendor():Promise<void>{
      const sp = getSP(Props.spContext);
      const countLastIDList = await sp.web.lists.getByTitle(Props.PanePropsPropsedVendor).items.select("ID").orderBy("ID", false).top(1)();
      const TopLastID = countLastIDList.length > 0 ? countLastIDList[0].ID : 0;
      const vendorsretult:IProposeVendor[] = await sp.web.lists.getByTitle(Props.PanePropsPropsedVendor).items.select("VendorName", "Id", "Range").top(TopLastID)();
      setVendor(vendorsretult);
      console.log("Vendor", vendorsretult);
    }
    getAllVendor().catch(console.error);
  },[]);

  return(
    <section className={`${styles.nimcoform} ${Props.hasTeamsContext ? styles.teams : ''}`}>
       <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
       <Container>
            <Card>
              <Card.Header className="h5">Non-Inventory Materials Change Order</Card.Header>
              <Card.Body>
              {/* <DatePicker
   style= {{width: '100%'}}
   placeholder = "Select Delivery Date" maxDate={dayjs()}

/> */}
                
                <Card className='mb-3'>
                  <Card.Header className="h5">Start Process</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                      <Form.Group className="mb-3">
                        <Form.Label className={styles.required}>Project Number and Name</Form.Label>
                        <Form.Select aria-label="Please Select Project" {...register("ProjectName")} isInvalid={ !!errors.ProjectName }>
                          <option value="">Please Select Project</option> 
                            {Props.spProjectListItems && Props.spProjectListItems.map((list) => {
                                  return  ( 
                                    <option key={list.id} value={list.ProjectName}>{list.ProjectName}</option> 
                                  );
                            })}
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">
                          {errors.ProjectName?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label className={styles.required}>Requester Name</Form.Label>
                          <Form.Control type="text" {...register("RequesterName")} defaultValue={Props.userDisplayName} isInvalid={ !!errors.RequesterName }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.RequesterName?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Requester Email</Form.Label>
                          <Form.Control type="email" {...register("RequesterEmail")} isInvalid={ !!errors.RequesterEmail } defaultValue={Props.userEmail}/>
                          <Form.Control.Feedback type="invalid">
                            {errors.RequesterEmail?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label className={styles.required}>Subject</Form.Label>
                          <Form.Control type="text"  {...register("Subject")} isInvalid={ !!errors.Subject }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.Subject?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                      <Form.Group className="mb-3">
                        <Form.Label className={styles.required}>NIMCO Category</Form.Label>
                        <Form.Select aria-label="Please Select Category" {...register("Category")} isInvalid={ !!errors.Category }>
                          <option key="cat-null" value="">Please Select Category</option>
                          <option key="cat-1" value="Mounting Equipment">Mounting Equipment</option>
                          <option key="cat-2" value="Electrical">Electrical</option>
                          <option key="cat-3" value="Miscellaneous">Miscellaneous</option>
                          <option key="cat-4" value="Rentals">Rentals</option>
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">
                          {errors.Category?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Card className="mb-3">
                  <Card.Header className="h5">Proposed Vendor</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Vendor first initial range</Form.Label>
                          <Form.Select aria-label="Please Select Range" 
                            {...register("ProposedVendor")} 
                            isInvalid={ !!errors.ProposedVendor } 
                            onChange={(e) => { setVendorRange(e.currentTarget.value) }}>
                            <option key="range-null" value="">Please Select Range</option>
                            <option key="range-ad" value="A-D">A-D</option>
                            <option key="range-em" value="E-M">E-M</option>
                            <option key="range-nr" value="N-R">N-R</option>
                            <option key="range-sz" value="S-Z">S-Z</option> 
                          </Form.Select>
                          <Form.Text id="passwordHelpBlock" muted>Please select the range that contains the first initial of the vendors name</Form.Text>
                          <Form.Control.Feedback type="invalid">
                            {errors.ProposedVendor?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Vendor</Form.Label>
                          <Form.Select aria-label="Please Select Vendor" {...register("Vendor")} isInvalid={ !!errors.Vendor }>
                            <option key="range-null" value="">Please Select Vendor</option>
                            {Vendor && Vendor.map((list) => {
                                if(list.Range === VendorRange ){
                                    return  ( 
                                      <option key={list.id} value={list.VendorName}>{list.VendorName}</option>
                                    );
                                  }
                            })}
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.Vendor?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label className={styles.required}>PO#</Form.Label>
                          <Form.Control type="text" {...register("PONumber")} isInvalid={ !!errors.PONumber }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.PONumber?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Estimated Pricing</Form.Label>
                          <Form.Control type="text" 
                            {...register("EstimatedPricing")} 
                            isInvalid={ !!errors.EstimatedPricing } 
                            defaultValue={0} />
                          <Form.Control.Feedback type="invalid">
                            {errors.EstimatedPricing?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Supplier Contact Name</Form.Label>
                          <Form.Control type="text" {...register("SupplierContactName")} isInvalid={ !!errors.SupplierContactName }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.SupplierContactName?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Supplier Contact E-mail</Form.Label>
                          <Form.Control type="email" {...register("SupplierEmail")} isInvalid={ !!errors.SupplierEmail }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.SupplierEmail?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Does the contact need a copy of the PO?</Form.Label>
                          <Form.Select aria-label="Please Select Option" {...register("ContactNeedCopy")} isInvalid={ !!errors.ContactNeedCopy } defaultValue="No">
                            <option key="cnc-null" value="">Please Select Option</option>
                            <option key="cnc-yes" value="Yes">Yes</option>
                            <option key="cnc-no" value="No">No</option>
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.ContactNeedCopy?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Is this contact a replacement of the previous PO receiver?</Form.Label>
                          <Form.Select aria-label="Please Select Option" 
                            {...register("ContactReplacement")} 
                            isInvalid={ !!errors.ContactReplacement } 
                            defaultValue="No" 
                            onChange={ (e) => { setContactReplacement(e.currentTarget.value)}}>
                            <option key="cnc-null" value="">Please Select Option</option>
                            <option key="cnc-yes" value="Yes">Yes</option>
                            <option key="cnc-no" value="No">No</option>
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.ContactReplacement?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" hidden={ContactReplacement === "No" ? true : false }>
                          <Form.Label className={styles.required}>If Contact Replacement, please specify the contact to be removed</Form.Label>
                          <Form.Control type="text"  {...register("Contacttoberemoved")} isInvalid={ !!errors.Contacttoberemoved }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.Contacttoberemoved?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row className='mt-4'>
                      <Col>
                        <Form.Group className="mb-5">
                          <Form.Label >Awarded Quote/ Bid Documents</Form.Label>
                          <Form.Control type="file" id="fileAwardedBid" multiple />
                          <Form.Text id="passwordHelpBlock" muted>Supported file types: pdf, doc, docx, xls, xlsx, ppt, pptx, txt, rtf, jpg, jpeg, png, tiff, rar, zip, dwg, dxf</Form.Text>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Card className="mb-3">
                  <Card.Header className="h5">Schedule</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-4" >
                          <Form.Label className={styles.required}>Requested Onsite Date</Form.Label>
                          <DatePicker 
                            className='form-control' 
                            allowClear={true}
                            format={"MMM DD, YYYY"}
                            {...register("RequestedOnsiteDate")}  
                            onChange={(e): void => {  if(e){ setValue("RequestedOnsiteDate", e.format("MMM DD, YYYY").toString(),  { shouldValidate: true }) } }} />

                          <Form.Control.Feedback type="invalid">
                            {errors.RequestedOnsiteDate?.message} 
                          </Form.Control.Feedback>
                          <p className="link-danger">{errors.RequestedOnsiteDate?.message}</p>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Estimated Lead Time (weeks)</Form.Label>
                          <Form.Control type="text" {...register("EstimatedLeadTime")} isInvalid={ !!errors.EstimatedLeadTime }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.EstimatedLeadTime?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Estimated Transit Time (days)</Form.Label>
                          <Form.Control type="email" {...register("EstimatedTransitTime")} isInvalid={ !!errors.EstimatedTransitTime }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.EstimatedTransitTime?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Delivery Address/Location</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("DeliveryAddressLocation")}/>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Row>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Notes and Special Directions for Procurement</Form.Label>
                      <Form.Control as="textarea" rows={3} {...register("Notesforprocurement")}/>
                    </Form.Group>
                  </Col>
                </Row>
                <Card className="mb-3">
                  <Card.Header className="h5">Line Items</Card.Header>
                  <Card.Body>
                    <Card.Subtitle>Please dont forget to fillout the line items below</Card.Subtitle>
                    <Form.Group className="mb-3">
                      <Form.Label className={styles.required}>Number of Line Items</Form.Label>
                      <Form.Select aria-label="Please Select" defaultValue={1} {...register("NumberofLineItems")} onChange={(e) => {setNIS(e.currentTarget.value)}} isInvalid={ !!errors.NumberofLineItems }>
                        <option>Please Select</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="more">more than 3 items</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.NumberofLineItems?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                    <Row>
                      <Col>
                        <Card className='mb-2' hidden={NIS === "1" || NIS === "2" || NIS === "3" ? false : true }>
                          <Card.Header>Line Item 1</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select" {...register("TaskCodeItem1")} isInvalid={ !!errors.TaskCodeItem1 }>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.TaskCodeItem1?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Initial Forecast Amount</Form.Label>
                                  <Form.Control type="text"  {...register("InitialAmountItem1")} isInvalid={ !!errors.InitialAmountItem1 } onChange={(e)=> { setItemAmount1(parseFloat(e.currentTarget.value)) } }/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem1?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text"  {...register("DescriptionItem1")} isInvalid={ !!errors.DescriptionItem1 }/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem1?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-2' hidden={NIS === "2" || NIS === "3" ? false : true }>
                          <Card.Header>Line Item 2</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select" {...register("TaskCodeItem2")} isInvalid={ !!errors.TaskCodeItem2 }>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.TaskCodeItem2?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Initial Forecast Amount</Form.Label>
                                  <Form.Control type="text"  {...register("InitialAmountItem2")} isInvalid={ !!errors.InitialAmountItem2 }  onChange={(e)=> { setItemAmount2(parseFloat(e.currentTarget.value)) } }/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem2?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text"  {...register("DescriptionItem2")} isInvalid={ !!errors.DescriptionItem2 }/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem2?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-2' hidden={ NIS === "3" ? false : true }>
                          <Card.Header>Line Item 3</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select" {...register("TaskCodeItem3")} isInvalid={ !!errors.TaskCodeItem3 }>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.TaskCodeItem3?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Initial Forecast Amount</Form.Label>
                                  <Form.Control type="text"  {...register("InitialAmountItem3")} isInvalid={ !!errors.InitialAmountItem3 }  onChange={(e)=> { setItemAmount3(parseFloat(e.currentTarget.value)) } }/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem3?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text"  {...register("DescriptionItem3")} isInvalid={ !!errors.DescriptionItem3 }/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem3?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-3' hidden={ NIS === "1" || NIS === "2" || NIS === "3" ? false : true }>
                          <Card.Header>Total Amount</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Control type="text"  {...register("TotalAmount")} value={TotalAmount}/>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-2' hidden={ NIS === "more" ? false : true }>
                          <Card.Header>Line Item</Card.Header>
                          
                          <Card.Body>
                            <Card.Subtitle className="mb-2 text-muted">For more than 3 line items, please don&apos;t forget to fill-out the line items below.</Card.Subtitle>
                            <Card.Text>Instructions: Follow the link to navigate to the Box. Download the file named &lsquo;NIMCO&lsquo; Line Items. Fill it in, save it in your computer and then attach it to the section below.</Card.Text>
                            <p><a href='https://sunpowercorp.sharepoint.com/:x:/s/NewHomesTEST/EfvqofLJCDxGrVhTi_8EWeIBNWugvslZemj21YLrvoVLPQ?e=bvHRnI&download=1' rel="opener">Download template here</a> to fill in the Line Items</p>
                            <Row>
                              <Col>
                              <Form.Group className="mb-5">
                                <Form.Label className={styles.required}>Attach Line Items</Form.Label>
                                <Form.Control type="file" id="fileLineItem" {...register("fileLineItem")} multiple />
                                <Form.Text id="passwordHelpBlock" muted>Please attach only Excel files, other files will be discarded.</Form.Text>
                                <p className="link-danger">{errors.fileLineItem?.message}</p>
                              </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>

                <Card style={{ width: '100%' }} className='mb-3'>
                  <Card.Header className="h5">Technical Specifications</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                      <Form.Group className="mb-5">
                        <Form.Label>Technical Specifications</Form.Label>
                        <Form.Control type="file" id="fileTechSpec" multiple />
                        <Form.Text id="passwordHelpBlock" muted>Supported file types: pdf, doc, docx, xls, xlsx, ppt, pptx, txt, rtf, jpg, jpeg, png, tiff, rar, zip, dwg, dxf</Form.Text>
                      </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label >Technical Specification Notes</Form.Label>
                          <Form.Control as="textarea"  {...register("TechnicalSpecNotes")}/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Skip Review?</Form.Label>
                          <Form.Select aria-label="Please Select" {...register("SkipReview")} onChange={(e) => {setNIS(e.currentTarget.value)}} isInvalid={ !!errors.SkipReview }>
                            <option>Please Select</option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.SkipReview?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>

                <Card style={{ width: '100%' }} className='mb-3'>
                  <Card.Header className="h5">Technical Approvers (Consultants / EOR)</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label >Name</Form.Label>
                          <Form.Control type='text'  {...register("TCName")}/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label >Company</Form.Label>
                          <Form.Control type='text'  {...register("TCCompany")}/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label >Email</Form.Label>
                          <Form.Control type='email'  {...register("TCEmail")}/>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header className="h5">CC Users</Card.Header>
                      <Card.Body>
                      <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                        <Form.Group className="mb-3" >
                          <Form.Check
                            inline
                            label="Yes"
                            value="true"
                            {...register("CCUser")} 
                            onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                          />
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label className={styles.required}>Email Addresses</Form.Label>
                          <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CCEmails?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("CCComment")} />
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row className="mb-4">
                  <Col>
                    <div className="d-grid gap-2">
                      <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting }>
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden={ !!isSubmitting }
                        className={ "visually-hidden" } />
                      { isSubmitting ? "...Submitting" : "SUBMIT" }
                      </Button>
                    </div>
                  </Col>
                </Row>
                { ShowSuccess && (
                    <Alert 
                      key={ MessageType } 
                      variant={ MessageType } 
                      dismissible 
                      onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                        { message }
                    </Alert>
                )}
              </Card.Body>
            </Card>
          </Container>
        </form>
        <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
          <Modal.Header>
            <Modal.Title>SharePoint</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Alert variant="primary">
              <Alert.Heading>{ message }</Alert.Heading>
              <p hidden={MessageType === "danger" ? true : false}>
                Thank you! You can now close this tab or window.
              </p>
            </Alert>
          </Modal.Body>
          <Modal.Footer hidden={MessageType === "danger" ? false : true}>
            <Button variant="secondary" onClick={handleClose}>
              Continue
            </Button>
          </Modal.Footer>
        </Modal>
      </section>
  );
}