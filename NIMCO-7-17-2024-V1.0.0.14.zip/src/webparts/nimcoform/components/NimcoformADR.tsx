import * as React from 'react';
import styles from './Nimcoform.module.scss';
import type { INimcoformProps } from './INimcoformProps';
import { Alert, Button, Card, Col, Container, Form, Modal, Row, Spinner } from 'react-bootstrap';
import {  TnimcoFormADRSchema, nimcoFormADRSchema } from '../utils/types';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup"
import { getSP } from '../utils/pnpjsConfig';
import WorkFlowSubmit from '../utils/WorkFlowSubmit';
import { IAttachmentInfo } from '@pnp/sp/attachments';
import { IoDocumentAttachOutline } from "react-icons/io5";
import { addFilesPromiseRename } from '../utils/addFilesPromise';

export default function NimcoformPO(Props:INimcoformProps):React.ReactElement{
  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [CCGroup, setCCGroup ] = React.useState(false);
  const [theAttachmentFiles, settheAttachmentFiles] = React.useState<IAttachmentInfo[]>([]);
  const [nextStage , setnextStage] = React.useState("");
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);

  let attachments: IAttachmentInfo[] = [];
    React.useEffect(() => {
      async function fecthData():Promise<void>{
        const sp = getSP();
        const item = sp.web.lists.getByTitle(Props.PanePropsNimcoList).items.getById(parseInt(Props.spNimcoItem[0].Id));
        attachments = await item.attachmentFiles().then(async res => {return await res});
        settheAttachmentFiles(attachments);
        console.log("await:",attachments);
      }
      fecthData().catch(console.error);
    },[]);


  const { 
    register, 
    handleSubmit,
    formState: {errors, isSubmitting},
    reset
  } = useForm<TnimcoFormADRSchema>({
    resolver: yupResolver(nimcoFormADRSchema),
  });

  const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
    if(FileAttachment && FileAttachment?.length > 0){
      for(let i =0; i < FileAttachment.length; i++){
        /* eslint-disable no-useless-escape */
        const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
        if(match){
          setShowSuccess(true);
          setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
          setMessageType('danger');
          return true;
        }else{
          return false;
        }
      }
    }
    return false;
  }

  const onSubmit = async (data: TnimcoFormADRSchema):Promise<void> => {
    const sp = getSP(Props.spContext);
    const fileFinalDoc = document.getElementById("fileFinalDoc") as HTMLInputElement;
    const AttfileFinalDoc = fileFinalDoc.files;
    if(filenameCharValidation(AttfileFinalDoc)){ return; }


    data.CCUser = CCGroup === true ? "Yes": "No";
    data.ReviseComment = data.ADRReviseComment;

    let newStatus:string = "";
    let newStage:string = "";

    switch(data.Stage){
      case "Approve": newStatus = "Completed"; newStage = "Completed";break;
      case "Revise": newStatus = "Pending"; newStage = "Initiator Revision"; break;
      case "Close": newStatus = "Void"; newStage = "Void"; break;
      default: newStatus = "Pending"; 
    }
    data.Status = newStatus;
    data.Stage = newStage;
    data.flag = "2";
    console.log("Schema Data:", data);

    await sp.web.lists.getByTitle(Props.PanePropsNimcoList).items.getById(parseInt(Props.spNimcoItem[0].Id)).update(data)
    .then(async (addResult) => {
      console.log("add result:",addResult);
      const PromoseArray = [];


      if( AttfileFinalDoc && AttfileFinalDoc?.length > 0){
        setShowSuccess(true);
        setmessage("Please wait while we upload the PO Dcoment file Attachment.");
        setMessageType('primary');
        for(let i =0; i < AttfileFinalDoc.length; i++){
          const UploadArrayBid = await addFilesPromiseRename( Props.PanePropsNimcoList, parseInt(Props.spNimcoItem[0].Id), AttfileFinalDoc, i, "[PO-Document]");
          PromoseArray.push(UploadArrayBid);
        }
      }

      Promise.all(PromoseArray).then( res => { 
        console.log("Promise Upload resolve:", res);
        setShowSuccess(true);
        setmessage("Successfully Submitted the PO with attachment file.");
        setMessageType('success');
        reset();
      })
      .catch(err => { 
        console.log("Promise Upload reject:", err);
        setShowSuccess(true);
        setmessage("Your Request is Submitted but there was a problem uploading the attachment");
        setMessageType('danger');
        reset();
      });
      const WFresult = await WorkFlowSubmit(Props.spNimcoItem[0].Id, false, newStatus, newStage, "2");
      console.log("WF Result:", WFresult);
      reset();
      setModalShow(true);
      return Promise.resolve;
    })
    .catch( (error) => {
        console.log("Error Submit:", error);
        setShowSuccess(true);
        setmessage("Sorry! Your PO failed to Submit. Please try again.");
         setMessageType('danger');
        return Promise.reject;
    });
    
  };

  return(
    <section className={`${styles.nimcoform} ${Props.hasTeamsContext ? styles.teams : ''}`}>
      <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
        <fieldset disabled={Props.spView}>
          <Container>
            <Card>
              <Card.Header className="h5">NIMCO - Engineer for Approval Drawing Review</Card.Header>
              <Card.Body>                
                <Card className='mb-4' style={{ width: '100%' }}>
                  <Card.Header className="h5">Approval Drawing</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Project Number and Name</Form.Label>
                          <Form.Control type="text" value={Props.spNimcoItem[0].ProjectName} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Instance Number</Form.Label>
                          <Form.Control type="text" value={Props.spNimcoItem[0].Id} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Requester Name</Form.Label>
                          <Form.Control type="text" value={Props.spNimcoItem[0].RequesterName} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Requester Email</Form.Label>
                          <Form.Control type="text" value={Props.spNimcoItem[0].RequesterEmail} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Subject</Form.Label>
                          <Form.Control type="text"  value={Props.spNimcoItem[0].Subject} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                      <Form.Group className="mb-3">
                        <Form.Label>NIMCO Category</Form.Label>
                        <Form.Control type="text"  value={Props.spNimcoItem[0].Category} disabled/>
                      </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>

                <Card className="mb-4" style={{ width: '100%' }}>
                  <Card.Header className="h5">Procurement Info</Card.Header>
                  <Card.Body>
                    <h6>Procurement Strategy</h6>
                    <Form.Group className="mb-3">
                    <Form.Control type="text"  value={Props.spNimcoItem[0].ProcurementStrategy} disabled/>
                    </Form.Group>
                  </Card.Body>
                </Card>

                <Card className="mb-3" style={{ width: '100%' }}>
                  <Card.Header className="h5">Specifications</Card.Header>
                  <Card.Body>
                    <Row className='mb-4'>
                      <Col>
                        <Card style={{ width: '100%' }}>
                          <Card.Header className="h5">Technical Specifications</Card.Header>
                          <Card.Body>
                            <div className="d-grid gap-2">
                            {
                            theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                              if(aFile.FileName.substring(0,19) === "[Tech-Specification]"){
                                return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="primary" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                              }})
                            }
                            </div>
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
                    <Row className='mb-4'>
                      <Col>
                        <h6>Technical Specification Notes</h6>
                        <Form.Group className="mb-3">
                          <Form.Control as="textarea" rows={3} defaultValue={Props.spNimcoItem[0].TechnicalSpecNotes} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row className='mb-4'>
                      <Col>
                        <Form.Group className="mb-5">
                          <Form.Label>Final Approval Documents</Form.Label>
                          <Form.Control type="file" id="fileFinalDoc"  multiple />
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>

                <Row className='mt-4'>
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header className="h5">Awarded Quote/ Bid Documents</Card.Header>
                      <Card.Body>
                        <Card.Text>Use this field if you already have a quote and want to proceed directly to the PO Create Step.</Card.Text>
                        <div className="d-grid gap-2">
                        {
                        theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                          if(aFile.FileName.substring(0,27) === "[AwardedQuote-BidDocuments]"){
                            return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                          }})
                        }
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                
                
                

                <Card className="mb-4" style={{ width: '100%' }}>
                  <Card.Header className="h5">Technical Approval</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Approving EOR Final</Form.Label>
                          <Form.Control type="text" {...register("ApprovingEORFinal")} isInvalid={ !!errors.ApprovingEORFinal }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.ApprovingEORFinal?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-5">
                          <Form.Label className={styles.required}>Review Response Final</Form.Label>
                          <Form.Select aria-label="Please Select Next Step" {...register("ReviewResponseFinal")} isInvalid={!!errors.ReviewResponseFinal} >
                            <option value="">Please Select</option>
                            <option key='rrf1' value="NoExceptions taken; Proceed">NoExceptions taken; Proceed</option>
                            <option key='rrf2' value="Make corrections shown; Proceed">Make corrections shown; Proceed</option>
                            <option key='rrf3' value="Revise and Resubmit">Revise and Resubmit</option>
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.ReviewResponseFinal?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                      <Form.Group className="mb-3">
                          <Form.Label>Review Comments Final</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("ReviewCommentsFinal")} />
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>


                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header className="h5">CC Users</Card.Header>
                      <Card.Body>
                      <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                        <Form.Group className="mb-3" >
                          <Form.Check
                            inline
                            label="Yes"
                            value="true"
                            {...register("CCUser")} 
                            onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                          />
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label className={styles.required}>Email Addresses</Form.Label>
                          <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CCEmails?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("CCComment")} />
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Card style={{ width: '100%' }} className='mb-4'>
                  <Card.Header className="h5">Next Step</Card.Header>
                  <Card.Body>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Outcome</Form.Label>
                      <Form.Select aria-label="Please Select Next Step" {...register("Stage")} isInvalid={!!errors.Stage}onChange={(e)=>{setnextStage(e.currentTarget.value )}} >
                        <option value="">Please Select</option>
                        <option key='ns1' value="Approve">Approve</option>
                        <option key='ns2' value="Revise">Revise</option>
                        <option key='ns2' value="Close">Close/Void</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.Stage?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                    <Form.Group className="mb-5" hidden={nextStage === "Revise" ? false: true}>
                      <Form.Label>Comments - Revise</Form.Label>
                      <Form.Control as="textarea" rows={3} {...register("ADRReviseComment")} isInvalid={ !!errors.ADRReviseComment }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.ADRReviseComment?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                    <Form.Group className="mb-5" hidden={nextStage === "Close" ? false: true}>
                      <Form.Label>Comments - Close</Form.Label>
                      <Form.Control as="textarea" rows={3} {...register("ADRCloseComment")} isInvalid={ !!errors.ADRCloseComment }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.ADRCloseComment?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Card.Body>
                </Card>
                <Row className="mb-4">
                  <Col>
                    <div className="d-grid gap-2">
                      <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting }>
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden={ !!isSubmitting }
                        className={ "visually-hidden" } />
                      { isSubmitting ? "...Submitting" : "SUBMIT" }
                      </Button>
                    </div>
                  </Col>
                </Row>
                { ShowSuccess && (
                    <Alert 
                      key={ MessageType } 
                      variant={ MessageType } 
                      dismissible 
                      onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                        { message }
                    </Alert>
                )}
              </Card.Body>
            </Card>
          </Container>
        </fieldset>
      </form>
        <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
          <Modal.Header>
            <Modal.Title>SharePoint</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Alert variant="primary">
              <Alert.Heading>{ message }</Alert.Heading>
              <p hidden={MessageType === "danger" ? true : false}>
                Thank you! You can now close this tab or window.
              </p>
            </Alert>
          </Modal.Body>
          <Modal.Footer hidden={MessageType === "danger" ? false : true}>
            <Button variant="secondary" onClick={handleClose}>
              Continue
            </Button>
          </Modal.Footer>
        </Modal>
      </section>
  );
}