import * as React from 'react';
import styles from './Nimcoform.module.scss';
import type { INimcoformProps } from './INimcoformProps';
import { Alert, Button, Card, Col, Container, Form, Modal, Row, Spinner } from 'react-bootstrap';
import { TnimcoFormIRSchema, nimcoFormIRSchema } from '../utils/types';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup"
import { getSP } from '../utils/pnpjsConfig';
import { addFilesPromiseRename } from '../utils/addFilesPromise';
import WorkFlowSubmit from '../utils/WorkFlowSubmit';
import { DatePicker } from 'antd';
import { IAttachmentInfo } from '@pnp/sp/attachments';
import { IoDocumentAttachOutline } from 'react-icons/io5';
import * as dayjs from 'dayjs';

export default function NimcoformIR(Props:INimcoformProps):React.ReactElement{
  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [CCGroup, setCCGroup ] = React.useState(false);
  const [theAttachmentFiles, settheAttachmentFiles] = React.useState<IAttachmentInfo[]>([]);
  const [ContactReplacement, setContactReplacement] = React.useState("No");
  const [NIS, setNIS ] = React.useState(Props.spNimcoItem[0].NumberofLineItems);
  const [nextStage , setnextStage] = React.useState("");
  const [TotalAmount , setTotalAmount] = React.useState(parseFloat(Props.spNimcoItem[0].TotalAmount));
  const [ItemAmount1 , setItemAmount1] = React.useState(Props.spNimcoItem[0].InitialAmountItem1 !== null ? parseFloat(Props.spNimcoItem[0].InitialAmountItem1) : 0);
  const [ItemAmount2 , setItemAmount2] = React.useState(Props.spNimcoItem[0].InitialAmountItem2 !== null ? parseFloat(Props.spNimcoItem[0].InitialAmountItem2) : 0);
  const [ItemAmount3 , setItemAmount3] = React.useState(Props.spNimcoItem[0].InitialAmountItem3 !== null ? parseFloat(Props.spNimcoItem[0].InitialAmountItem3) : 0);
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);


  const { 
    register, 
    handleSubmit,
    formState: {errors, isSubmitting},
    reset, setValue
  } = useForm<TnimcoFormIRSchema>({
    resolver: yupResolver(nimcoFormIRSchema),
  });

  

  let attachments: IAttachmentInfo[] = [];
  React.useEffect(() => {
    async function fecthData():Promise<void>{
      const sp = getSP();
      const item = sp.web.lists.getByTitle(Props.PanePropsNimcoList).items.getById(parseInt(Props.spNimcoItem[0].Id));
      attachments = await item.attachmentFiles().then(async res => {return res});
      settheAttachmentFiles(attachments);
      setValue("RequestedOnsiteDate", Props.spNimcoItem[0].RequestedOnsiteDate ,  { shouldValidate: false });
      console.log("await attachment:",attachments);
    }
    fecthData().catch(console.error);
  },[]);

  const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
    if(FileAttachment && FileAttachment?.length > 0){
      for(let i =0; i < FileAttachment.length; i++){
        /* eslint-disable no-useless-escape */
        const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
        if(match){
          setShowSuccess(true);
          setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
          setMessageType('danger');
          return true;
        }else{
          return false;
        }
      }
    }
    return false;
  }

  const onSubmit = async (data: TnimcoFormIRSchema):Promise<void> => {
    const sp = getSP(Props.spContext);

    const fileAwardedBid = document.getElementById("fileAwardedBid") as HTMLInputElement;
    const fileLineItem = document.getElementById("fileLineItem") as HTMLInputElement;
    const fileTechSpec =  document.getElementById("fileTechSpec") as HTMLInputElement;
    const AttfileAwardedBid = fileAwardedBid.files;
    const AttfileLineItem = fileLineItem.files;
    const AttffileTechSpec = fileTechSpec.files;
    if(filenameCharValidation(AttfileAwardedBid)){ return; }
    if(filenameCharValidation(AttfileLineItem)){ return; }
    if(filenameCharValidation(AttffileTechSpec)){ return; }

    let newStatus:string = "";
    let newStage:string = "";

    switch(data.Stage){
      case "Resubmit": newStatus = "Pending"; newStage = "Procurement Planning";break;
      case "Void": newStatus = "Void"; newStage = "Void"; break;
      case "Delegate": newStage = "PR Creation"; newStatus = "Delegate"; break;
      default: newStatus = "Pending"; 
    }
    data.Status = newStatus;
    data.Stage = newStage;

    data.CCUser = CCGroup === true ? "Yes": "No";
    data.flag = "2";
    data.TotalAmount = TotalAmount.toString();
    delete data.fileLineItem;
    console.log("Schema Data:", data);

    await sp.web.lists.getByTitle(Props.PanePropsNimcoList).items.getById(parseInt(Props.spNimcoItem[0].Id)).update(data)
    .then(async (addResult) => {
      console.log("add result:",addResult);
      

      if( ( AttfileAwardedBid && AttfileAwardedBid?.length > 0 ) || ( AttfileLineItem && AttfileLineItem?.length > 0 )  || ( AttffileTechSpec && AttffileTechSpec?.length > 0)){
        const PromoseArray = [];
        setShowSuccess(true);
        setmessage("Please wait while we upload the file Attachment.");
        setMessageType('primary');

        if( AttfileAwardedBid && AttfileAwardedBid?.length > 0){
          for(let i =0; i < AttfileAwardedBid.length; i++){
            const UploadArrayBid = await addFilesPromiseRename( Props.PanePropsNimcoList, parseInt(Props.spNimcoItem[0].Id) , AttfileAwardedBid, i, "[AwardedQuote-BidDocuments]");
            PromoseArray.push(UploadArrayBid);
          }
        }

        if( AttfileLineItem && AttfileLineItem?.length > 0){
          for(let i =0; i < AttfileLineItem.length; i++){
            const UploadArrayBid = await addFilesPromiseRename( Props.PanePropsNimcoList, parseInt(Props.spNimcoItem[0].Id) , AttfileLineItem, i, "[LineItem]");
            PromoseArray.push(UploadArrayBid);
          }
        }

        if( AttffileTechSpec && AttffileTechSpec?.length > 0){
          for(let i =0; i < AttffileTechSpec.length; i++){
            const UploadArrayBid = await addFilesPromiseRename( Props.PanePropsNimcoList, parseInt(Props.spNimcoItem[0].Id), AttffileTechSpec, i, "[Tech-Specification]");
            PromoseArray.push(UploadArrayBid);
          }
        }
        Promise.all(PromoseArray).then( res => { 
          console.log("Promise Upload resolve:", res);
          setShowSuccess(true);
          setmessage("Successfully Update Your Request.");
          setMessageType('success');
          reset();
        })
        .catch(err => { 
          console.log("Promise Upload reject:", err);
          setShowSuccess(true);
          setmessage("Your Request is Submitted but there was a problem uploading the attachment");
          setMessageType('danger');
          reset();
        });
      }else{
        setShowSuccess(true);
        setmessage("Successfully Update Your Request without Attachment.");
        setMessageType('primary');
        reset();
      }
      const WFresult = await WorkFlowSubmit(Props.spNimcoItem[0].Id, false, newStatus, newStage, "2" );
      console.log("WF Result:", WFresult);
      reset();
      setModalShow(true);
      return Promise.resolve;
    })
    .catch( (error) => {
        console.log("Error Submit:", error);
        setShowSuccess(true);
        setmessage("Sorry! Your Request failed to Submit. Please try again.");
         setMessageType('danger');
        return Promise.reject;
    });
    
  };

    React.useEffect(() => { 
      function updateTotal():void{ setTotalAmount(ItemAmount1 + ItemAmount2 + ItemAmount3) }
      updateTotal();
    },[ItemAmount1, ItemAmount2, ItemAmount3]);

  return(
    <section className={`${styles.nimcoform} ${Props.hasTeamsContext ? styles.teams : ''}`}>
      <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
        <fieldset disabled={Props.spView}>
          <Container>
            <Card style={{ width: '100%' }}>
              <Card.Header className="h5">NIMCO - Initiator Review</Card.Header>
              <Card.Body>
                <Card className='mb-4'>
                  <Card.Header className="h5">Start Process</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Project Number and Name</Form.Label>
                          <Form.Control type="text" value={Props.spNimcoItem[0].ProjectName} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Instance Number</Form.Label>
                          <Form.Control type="text" value={Props.spNimcoItem[0].Id} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Requester Name</Form.Label>
                          <Form.Control type="text" value={Props.spNimcoItem[0].RequesterName} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Requester Email</Form.Label>
                          <Form.Control type="text" value={Props.spNimcoItem[0].RequesterEmail} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Subject</Form.Label>
                          <Form.Control type="text"  value={Props.spNimcoItem[0].Subject} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>NIMCO Category</Form.Label>
                          <Form.Control type="text"  value={Props.spNimcoItem[0].Category} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Card className="mb-3" style={{ width: '100%' }}>
                      <Card.Header>Revision Comments</Card.Header>
                      <Card.Body>
                        <Row className='mb-4'>
                          <Col>
                            <h6>Comments for Revision</h6>
                            <Form.Group className="mb-3">
                              <Form.Control as="textarea" rows={3} defaultValue={Props.spNimcoItem[0].ReviseComment} disabled/>
                            </Form.Group>
                          </Col>
                        </Row>
                      </Card.Body>
                    </Card>
                  </Card.Body>
                </Card>
                <Card className="mb-4" style={{ width: '100%' }}>
                  <Card.Header className="h5">Proposed Vendor</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Vendor</Form.Label>
                          <Form.Control type="text"  value={Props.spNimcoItem[0].Vendor} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label className={styles.required}>PO#</Form.Label>
                          <Form.Control type="text" {...register("PONumber")} isInvalid={ !!errors.PONumber } defaultValue={Props.spNimcoItem[0].PONumber}/>
                          <Form.Control.Feedback type="invalid">
                            {errors.PONumber?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Estimated Pricing</Form.Label>
                          <Form.Control type="text" {...register("EstimatedPricing")} isInvalid={ !!errors.EstimatedPricing } defaultValue={Props.spNimcoItem[0].EstimatedPricing}/>
                          <Form.Control.Feedback type="invalid">
                            {errors.EstimatedPricing?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Supplier Contact Name</Form.Label>
                          <Form.Control type="text" {...register("SupplierContactName")} isInvalid={ !!errors.SupplierContactName } defaultValue={Props.spNimcoItem[0].SupplierContactName}/>
                          <Form.Control.Feedback type="invalid">
                            {errors.SupplierContactName?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Supplier Contact E-mail</Form.Label>
                          <Form.Control type="email" {...register("SupplierEmail")} isInvalid={ !!errors.SupplierEmail } defaultValue={Props.spNimcoItem[0].SupplierEmail}/>
                          <Form.Control.Feedback type="invalid">
                            {errors.SupplierEmail?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Does the contact need a copy of the PO?</Form.Label>
                          <Form.Select aria-label="Please Select Option" {...register("ContactNeedCopy")} isInvalid={ !!errors.ContactNeedCopy } defaultValue={Props.spNimcoItem[0].ContactNeedCopy}>
                            <option key="cnc-null" value="">Please Select Option</option>
                            <option key="cnc-yes" value="Yes">Yes</option>
                            <option key="cnc-no" value="No">No</option>
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.ContactNeedCopy?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Is this contact a replacement of the previous PO receiver?</Form.Label>
                          <Form.Select aria-label="Please Select Option" 
                            {...register("ContactReplacement")} 
                            isInvalid={ !!errors.ContactReplacement } 
                            defaultValue={Props.spNimcoItem[0].ContactReplacement}
                            onChange={ (e) => { setContactReplacement(e.currentTarget.value)}}>
                            <option key="cnc-null" value="">Please Select Option</option>
                            <option key="cnc-yes" value="Yes">Yes</option>
                            <option key="cnc-no" value="No">No</option>
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.ContactReplacement?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" hidden={ContactReplacement === "No" ? true : false }>
                          <Form.Label className={styles.required}>If Contact Replacement, please specify the contact to be removed</Form.Label>
                          <Form.Control type="text"  {...register("Contacttoberemoved")} isInvalid={ !!errors.Contacttoberemoved } defaultValue={Props.spNimcoItem[0].Contacttoberemoved}/>
                          <Form.Control.Feedback type="invalid">
                            {errors.Contacttoberemoved?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>

                <Row className='mb-4'>
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header className="h5">Awarded Quote/ Bid Documents</Card.Header>
                      <Card.Body>
                        <Card.Text>Use this field if you already have a quote and want to proceed directly to the PO Create Step.</Card.Text>
                        <div className="d-grid gap-2">
                        {
                        theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                          if(aFile.FileName.substring(0,27) === "[AwardedQuote-BidDocuments]"){
                            return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                          }})
                        }
                        </div>
                        <Row className='mt-4'>
                          <Col>
                            <Form.Group className="mb-5">
                              <Form.Label >Awarded Quote/ Bid Documents</Form.Label>
                              <Form.Control type="file" id="fileAwardedBid" multiple />
                              <Form.Text id="passwordHelpBlock" muted>Supported file types: pdf, doc, docx, xls, xlsx, ppt, pptx, txt, rtf, jpg, jpeg, png, tiff, rar, zip, dwg, dxf</Form.Text>
                            </Form.Group>
                          </Col>
                        </Row>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                
                
                <Card className="mb-4" style={{ width: '100%' }}>
                  <Card.Header className="h5">Line Items</Card.Header>
                  <Card.Body>
                    <Card.Subtitle>Please dont forget to fillout the line items below</Card.Subtitle>
                    <Form.Group className="mb-3">
                      <Form.Label className={styles.required}>Number of Line Items</Form.Label>
                      <Form.Select aria-label="Please Select" 
                        defaultValue={Props.spNimcoItem[0].NumberofLineItems}
                        {...register("NumberofLineItems")} 
                        onChange={(e) => {setNIS(e.currentTarget.value)}} 
                        isInvalid={ !!errors.NumberofLineItems }>
                        <option>Please Select</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="more">more than 3 items</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.NumberofLineItems?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                    <Row>
                      <Col>
                        <Card className='mb-2' hidden={NIS === "1" || NIS === "2" || NIS === "3" ? false : true }>
                          <Card.Header>Line Item 1</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select" {...register("TaskCodeItem1")} isInvalid={ !!errors.TaskCodeItem1 } defaultValue={Props.spNimcoItem[0].TaskCodeItem1}>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.TaskCodeItem1?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Initial Forecast Amount</Form.Label>
                                  <Form.Control type="text"  {...register("InitialAmountItem1")} isInvalid={ !!errors.InitialAmountItem1 } onChange={(e)=> { setItemAmount1(parseFloat(e.currentTarget.value)) } } defaultValue={Props.spNimcoItem[0].InitialAmountItem1}/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem1?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text"  {...register("DescriptionItem1")} isInvalid={ !!errors.DescriptionItem1 } defaultValue={Props.spNimcoItem[0].DescriptionItem1}/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem1?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-2' hidden={NIS === "2" || NIS === "3" ? false : true }>
                          <Card.Header>Line Item 2</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select" {...register("TaskCodeItem2")} isInvalid={ !!errors.TaskCodeItem2 } defaultValue={Props.spNimcoItem[0].TaskCodeItem2}>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.TaskCodeItem2?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Initial Forecast Amount</Form.Label>
                                  <Form.Control type="text"  {...register("InitialAmountItem2")} isInvalid={ !!errors.InitialAmountItem2 }  onChange={(e)=> { setItemAmount2(parseFloat(e.currentTarget.value)) } } defaultValue={Props.spNimcoItem[0].InitialAmountItem2}/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem2?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text"  {...register("DescriptionItem2")} isInvalid={ !!errors.DescriptionItem2 } defaultValue={Props.spNimcoItem[0].DescriptionItem2}/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem2?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-2' hidden={ NIS === "3" ? false : true }>
                          <Card.Header>Line Item 3</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select" {...register("TaskCodeItem3")} isInvalid={ !!errors.TaskCodeItem3 } defaultValue={Props.spNimcoItem[0].TaskCodeItem3}>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.TaskCodeItem3?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Initial Forecast Amount</Form.Label>
                                  <Form.Control type="text"  {...register("InitialAmountItem3")} isInvalid={ !!errors.InitialAmountItem3 }  onChange={(e)=> { setItemAmount3(parseFloat(e.currentTarget.value)) } } defaultValue={Props.spNimcoItem[0].InitialAmountItem3}/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem3?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text"  {...register("DescriptionItem3")} isInvalid={ !!errors.DescriptionItem3 } defaultValue={Props.spNimcoItem[0].DescriptionItem3}/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem3?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-3' hidden={ NIS === "1" || NIS === "2" || NIS === "3" ? false : true }>
                          <Card.Header>Total Amount</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Control type="text"  {...register("TotalAmount")} value={TotalAmount} disabled/>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>

                        <Row className='mb-3'>
                          <Col>
                            <Card>
                              <Card.Header className="h5">Initiator Attachments</Card.Header>
                              <Card.Body>
                              <div className="d-grid gap-2">
                                {
                                theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                                  if(aFile.FileName.substring(0,10) === "[LineItem]"){
                                    return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                                  }})
                                }
                              </div>
                              </Card.Body>
                            </Card>
                          </Col>
                        </Row>

                        <Card className='mb-2' hidden={ NIS === "more" ? false : true }>
                          <Card.Header>Line Item</Card.Header>
                          
                          <Card.Body>
                            <Card.Subtitle className="mb-2 text-muted">For more than 3 line items, please don&apos;t forget to fill-out the line items below.</Card.Subtitle>
                            <Card.Text>Instructions: Follow the link to navigate to the Box. Download the file named &lsquo;NIMCO&lsquo; Line Items. Fill it in, save it in your computer and then attach it to the section below.</Card.Text>
                            <p><a href='https://sunpowercorp.app.box.com/file/508906421734' rel="opener">Download template here</a> to fill in the Line Items</p>
                            <Row>
                              <Col>
                              <Form.Group className="mb-5">
                                <Form.Label className={styles.required}>Attach Line Items</Form.Label>
                                <Form.Control type="file" id="fileLineItem" {...register("fileLineItem")} multiple />
                                <Form.Text id="passwordHelpBlock" muted>Please attach only Excel files, other files will be discarded.</Form.Text>
                                <p className="link-danger">{errors.fileLineItem?.message}</p>
                              </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>

                

                <Card className="mb-3">
                  <Card.Header className="h5">Schedule</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-4" >
                          <Form.Label className={styles.required}>Requested Onsite Date</Form.Label>
                          <DatePicker 
                            className='form-control' 
                            allowClear={true}
                            format={"MMM DD, YYYY"}
                            defaultValue={dayjs(Props.spNimcoItem[0].RequestedOnsiteDate, "MMM DD, YYYY")}
                            {...register("RequestedOnsiteDate")}  
                            onChange={(e): void => {  if(e){ setValue("RequestedOnsiteDate", e.format("MMM DD, YYYY").toString()) } }} />

                          <Form.Control.Feedback type="invalid">
                            {errors.RequestedOnsiteDate?.message} 
                          </Form.Control.Feedback>
                          <p className="link-danger">{errors.RequestedOnsiteDate?.message}</p>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Estimated Lead Time (weeks)</Form.Label>
                          <Form.Control type="text" {...register("EstimatedLeadTime")} isInvalid={ !!errors.EstimatedLeadTime } defaultValue={Props.spNimcoItem[0].EstimatedLeadTime}/>
                          <Form.Control.Feedback type="invalid">
                            {errors.EstimatedLeadTime?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Estimated Transit Time (days)</Form.Label>
                          <Form.Control type="email" {...register("EstimatedTransitTime")} isInvalid={ !!errors.EstimatedTransitTime } defaultValue={Props.spNimcoItem[0].EstimatedTransitTime}/>
                          <Form.Control.Feedback type="invalid">
                            {errors.EstimatedTransitTime?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Delivery Address/Location</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("DeliveryAddressLocation")} defaultValue={Props.spNimcoItem[0].DeliveryAddressLocation}/>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>

                <Row>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Notes and Special Directions for Procurement</Form.Label>
                      <Form.Control as="textarea" rows={3} {...register("Notesforprocurement")} defaultValue={Props.spNimcoItem[0].Notesforprocurement}/>
                    </Form.Group>
                  </Col>
                </Row>

                <Card style={{ width: '100%' }} className='mb-3'>
                  <Card.Header className="h5">Technical Specifications</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                      <Form.Group className="mb-5">
                        <Form.Label>Technical Specifications</Form.Label>
                        <Form.Control type="file" id="fileTechSpec" multiple />
                        <Form.Text muted>Supported file types: pdf, doc, docx, xls, xlsx, ppt, pptx, txt, rtf, jpg, jpeg, png, tiff, rar, zip, dwg, dxf</Form.Text>
                      </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label >Technical Specification Notes</Form.Label>
                          <Form.Control as="textarea"  {...register("TechnicalSpecNotes")} defaultValue={Props.spNimcoItem[0].TechnicalSpecNotes}/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Skip Review?</Form.Label>
                          <Form.Select aria-label="Please Select" {...register("SkipReview")} onChange={(e) => {setNIS(e.currentTarget.value)}} isInvalid={ !!errors.SkipReview }>
                            <option>Please Select</option>
                            <option value="Yes">Yes - Skip Approval Drawing Review (after PO creation)</option>
                            <option value="No">No</option>
                          </Form.Select>
                          <Form.Text muted>Check if Approval Drawing Step can be skipped after creating the Purchase Order.</Form.Text>
                          <Form.Control.Feedback type="invalid">
                            {errors.SkipReview?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Card style={{ width: '100%' }} className='mb-3'>
                  <Card.Header className="h5">Technical Approvers (Consultants / EOR)</Card.Header>
                  <Card.Body>
                    <p>For Sunpower internal engineers, simply enter the name. If an external consulting firm is used enter the firm/person name.</p>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label >Name</Form.Label>
                          <Form.Control type="text" {...register("TCName")} defaultValue={Props.spNimcoItem[0].TCName}/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label >Company</Form.Label>
                          <Form.Control type="text" {...register("TCCompany")} defaultValue={Props.spNimcoItem[0].TCCompany}/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label >Email</Form.Label>
                          <Form.Control type="email" {...register("TCEmail")} defaultValue={Props.spNimcoItem[0].TCEmail}/>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>

                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header className="h5">CC Users</Card.Header>
                      <Card.Body>
                      <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                        <Form.Group className="mb-3" >
                          <Form.Check
                            inline
                            label="Yes"
                            value="true"
                            {...register("CCUser")} 
                            onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                          />
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label className={styles.required}>Email Addresses</Form.Label>
                          <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CCEmails?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("CCComment")} />
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>

                <Card className="mb-4">
                  <Card.Header className="h5">Next Step</Card.Header>
                  <Card.Body>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Outcome</Form.Label>
                      <Form.Select aria-label="Please Select Next Step" {...register("Stage")} isInvalid={!!errors.Stage } onChange={(e)=>{setnextStage(e.currentTarget.value )}} >
                        <option value="">Please Select</option>
                        <option key='ns1' value="Resubmit">Resubmit</option>
                        <option key='ns2' value="Void">Close/Void</option>
     
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.Stage?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                    <Row>
                      <Col>
                        <Form.Group className="mb-5" hidden={nextStage === "Void" ? false: true}>
                          <Form.Label>Comments - Revise</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("CloseComment")} isInvalid={ !!errors.CloseComment }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CloseComment?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>

                <Row className="mb-4">
                  <Col>
                    <div className="d-grid gap-2">
                      <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting }>
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden={ !!isSubmitting }
                        className={ "visually-hidden" } />
                      { isSubmitting ? "...Submitting" : "SUBMIT" }
                      </Button>
                    </div>
                  </Col>
                </Row>
                { ShowSuccess && (
                    <Alert 
                      key={ MessageType } 
                      variant={ MessageType } 
                      dismissible 
                      onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                        { message }
                    </Alert>
                )}
              </Card.Body>
            </Card>
          </Container>
        </fieldset>
      </form>
        <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
          <Modal.Header>
            <Modal.Title>SharePoint</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Alert variant="primary">
              <Alert.Heading>{ message }</Alert.Heading>
              <p hidden={MessageType === "danger" ? true : false}>
                Thank you! You can now close this tab or window.
              </p>
            </Alert>
          </Modal.Body>
          <Modal.Footer hidden={MessageType === "danger" ? false : true}>
            <Button variant="secondary" onClick={handleClose}>
              Continue
            </Button>
          </Modal.Footer>
        </Modal>
      </section>
  );
}