import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IBriaSpfxProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  spProjectListItems?: IProjectListItem[];
  PanePropsProjectNumberName: string;
  PanePropsBriaList:string;
  spContext: WebPartContext;
  userEmail?:string;
  spBriaItem:IBriaListItems[];
  spBaseURL:string;
}

export interface IProjectListItem{
  id: string;
  ProjectName: string;
  PCE: string;
}

export interface IBriaListItems{
  AssignedTo:string;
  AssignedToId:number;
  Id: string;
  Stage: string;
  Status: string;
  ProjectName:string;
  RequesterName: string;
  RequesterEmail: string;
  Subject: string;
  CCUser: string;
  CCEmails?: string;
  CCComment?:string;
  flag:string;
  NeedingRevision: string;
}
