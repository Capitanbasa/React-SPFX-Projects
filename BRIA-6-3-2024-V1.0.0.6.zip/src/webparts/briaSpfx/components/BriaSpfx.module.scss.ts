/* tslint:disable */
require("./BriaSpfx.module.css");
const styles = {
  briaSpfx: 'briaSpfx_d7f941f5',
  teams: 'teams_d7f941f5',
  welcome: 'welcome_d7f941f5',
  welcomeImage: 'welcomeImage_d7f941f5',
  links: 'links_d7f941f5',
  required: 'required_d7f941f5',
  divDropArea: 'divDropArea_d7f941f5'
};

export default styles;
/* tslint:enable */