import * as React from 'react';
import styles from './BriaSpfx.module.scss';
import type { IBriaSpfxProps } from './IBriaSpfxProps';
import { Alert, Button, Card, Col, Container, Form, Modal, Row, Spinner } from 'react-bootstrap';
import { BriaFormPCESchema, TBriaFormPCESchema } from '../utils/types';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup"
import { getSP } from '../utils/pnpjsConfig';
import WorkFlowSubmit from '../utils/WorkFlowSubmit';

export default function BriaSpfxPCE(Props:IBriaSpfxProps):React.ReactElement{
  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [CCGroup, setCCGroup ] = React.useState(false);
  const [nextStage , setnextStage] = React.useState("");
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);

  const { 
    register,
    handleSubmit,
    formState: {errors, isSubmitting},
    reset
  } = useForm<TBriaFormPCESchema>({
    resolver: yupResolver(BriaFormPCESchema)
  });


  const onSubmit = async (data: TBriaFormPCESchema):Promise<void> => {
    const sp = getSP(Props.spContext);
    
    data.CCUser = CCGroup === true ? "Yes": "No";
    data.flag = "1";
    console.log("Schema Data:", data);

    let newStatus:string = "Pending";
    let newStage:string = "PMO Review";
    switch(data.Stage){
      case "PMO Review":   newStatus = "Pending"; data.flag = "1"; break;
      case "Complete":  newStage = "Complete"; data.Stage = "Complete"; newStatus = "Complete"; data.flag = "2"; break;
      default: newStatus = "Pending";  newStage = "Project Controls Review"; data.flag = "2";
    }
    data.Status = newStatus;

    await sp.web.lists.getByTitle(Props.PanePropsBriaList).items.getById(parseInt(Props.spBriaItem[0].Id)).update(data)
    .then(async (addResult) => {
        console.log("update result:",addResult);
        const WFresult = await WorkFlowSubmit(Props.spBriaItem[0].Id.toString(), false, newStatus, newStage, "2");
        console.log("WF Result:", WFresult);
        setShowSuccess(true);
        setmessage("Successfully Submitted the Request.");
        setMessageType('success');
        reset();
        setModalShow(true);
        return Promise.resolve;
    })
    .catch( (error) => {
        console.log("Error update:", error);
        setShowSuccess(true);
        setmessage("Sorry! Your Request failed to Submit. Please try again.");
        setMessageType('danger');
        return Promise.reject;
    });
    
  };
  // let attachments: IAttachmentInfo[] = [];
  // React.useEffect(() => {
  //   async function fecthData():Promise<void>{
  //     const sp = getSP();
  //     const item = sp.web.lists.getByTitle(Props.PanePropsBriaList).items.getById(parseInt(Props.spBriaItem[0].Id));
  //     attachments = await item.attachmentFiles().then(async res => {return await res});
  //     settheAttachmentFiles(attachments);
  //     console.log("await:",attachments);
  //   }
  //   fecthData().catch(console.error);
  // },[]);
  // React.useEffect(() => {
  //   async function test():Promise<void>{
  //     const sp = getSP(Props.spContext);
  //     const pm:IWrorkFlow[] = await sp.web.lists.getByTitle("Workflow List").items.filter(`itemID eq '4' and Transaction eq 'Submittals'`)();
  //     console.log("WF:",pm);
  //   }
  //   test().catch(console.error);
  // },[]);
    //  React.useEffect(() => {
    //   async function test():Promise<void>{
    //     const sp = getSP(Props.spContext);
    //     const pm:IProjectListItem[] = await sp.web.lists.getByTitle("Project Lists").items.filter(`ID eq '1'`)();
    //     console.log("PROJECTLIST:",pm);
    //   }
    //   test().catch(console.error);
    // },[]);
  
    return(
      <section className={`${styles.briaSpfx} ${Props.hasTeamsContext ? styles.teams : ''}`}>
         <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
         <Container>
              <Card>
                <Card.Header className="h5">Builders Risk Ins Application Review (BRIA) -  PROJECT CONTROLS REVIEW</Card.Header>
                <Card.Body>
                <Row>
                  <Col>
                  <Form.Group className="mb-3">
                      <Form.Label>Project Number and Name</Form.Label>
                      <Form.Control type="text" value={Props.spBriaItem[0].ProjectName} disabled/>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Instance Number</Form.Label>
                      <Form.Control type="text" value={Props.spBriaItem[0].Id} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                  <Form.Group className="mb-3" >
                    <Form.Label>Requester Name</Form.Label>
                    <Form.Control type="text"  value={Props.spBriaItem[0].RequesterName} disabled/>
                  </Form.Group>
                    
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Requester Email</Form.Label>
                      <Form.Control type="email"  value={Props.spBriaItem[0].RequesterEmail} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>Subject</Form.Label>
                      <Form.Control type="text" value={Props.spBriaItem[0].Subject} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className='mt-4 mb-5'>
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>Share Point Files URL</Card.Header>
                      <Card.Body>
                        <p>Files Link Goes Here</p>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>CC Users</Card.Header>
                      <Card.Body>
                      <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                        <Form.Group className="mb-3">
                          <Form.Check
                            inline
                            label="Yes"
                            value="true"
                            {...register("CCUser")} 
                            onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                          />
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label className={styles.required}>Email Addresses</Form.Label>
                          <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CCEmails?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("CCComment")} />
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Next step</Form.Label>
                      <Form.Select aria-label="Please Select Next Step" {...register("Stage")} isInvalid={!!errors.Stage } onChange={(e)=>{setnextStage(e.currentTarget.value )}} >
                        <option value="">Please Select Next Step</option>
                        <option key='ns1' value="PMO Review">Request Revision</option>
                        <option key='ns6' value="Complete">Finish</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.Stage?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                     <Form.Group className="mb-5"  hidden={nextStage === "PMO Review" ? false: true}>
                        <Form.Label className={styles.required}>Items needing for revision</Form.Label>
                        <Form.Control as="textarea" rows={3} {...register("NeedingRevision")} isInvalid={ !!errors.NeedingRevision } defaultValue={Props.spBriaItem[0].NeedingRevision}/>
                        <Form.Control.Feedback type="invalid">
                        {errors.NeedingRevision?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-4">
                  <Col>
                    <div className="d-grid gap-2">
                      <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting } >
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden={ !!isSubmitting }
                        className={ isSubmitting ? "me-2": "visually-hidden" } />
                      { isSubmitting ? "...Submitting" : "SUBMIT" }
                      </Button>
                    </div>
                  </Col>
                </Row>
                  { ShowSuccess && (
                      <Alert 
                        key={ MessageType } 
                        variant={ MessageType } 
                        dismissible 
                        onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                          { message }
                      </Alert>
                  )}
                </Card.Body>
              </Card>
            </Container>
          </form>
          <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
            <Modal.Header>
              <Modal.Title>SharePoint</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Alert variant="primary">
                <Alert.Heading>{ message }</Alert.Heading>
                <p hidden={MessageType === "danger" ? true : false}>
                  Thank you! You can now close this tab or window.
                </p>
              </Alert>
            </Modal.Body>
            <Modal.Footer hidden={MessageType === "danger" ? false : true}>
              <Button variant="secondary" onClick={handleClose}>
                Continue
              </Button>
            </Modal.Footer>
          </Modal>
        </section>
    );
  }
