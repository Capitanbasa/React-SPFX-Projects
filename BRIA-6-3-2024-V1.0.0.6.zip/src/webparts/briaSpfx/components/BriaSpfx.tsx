import * as React from 'react';
import styles from './BriaSpfx.module.scss';
import type { IBriaSpfxProps } from './IBriaSpfxProps';
import { Alert, Button, Card, Col, Container, Form, Modal, Row, Spinner } from 'react-bootstrap';
import { TBriaFormSchema, BriaFormSchema } from '../utils/types';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup"
import { getSP } from '../utils/pnpjsConfig';
import addFilesPromise from '../utils/addFilesPromise';
import WorkFlowSubmit from '../utils/WorkFlowSubmit';

export default function BriaSpfx(Props:IBriaSpfxProps):React.ReactElement{
  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [CCGroup, setCCGroup ] = React.useState(false);
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);

  const { 
    register,
    handleSubmit,
    formState: {errors, isSubmitting},
    reset
  } = useForm<TBriaFormSchema>({
    resolver: yupResolver(BriaFormSchema)
  });

  const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
    if(FileAttachment && FileAttachment?.length > 0){
      for(let i =0; i < FileAttachment.length; i++){
        /* eslint-disable no-useless-escape */
        const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
        if(match){
          setShowSuccess(true);
          setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
          setMessageType('danger');
          return true;
        }else{
          return false;
        }
      }
    }
    return false;
  }
  
  const onSubmit = async (data: TBriaFormSchema):Promise<void> => {
    const sp = getSP(Props.spContext);
    const Attachment = document.getElementById("FileAttachment") as HTMLInputElement;
    const Attfiles = Attachment.files;
    if(filenameCharValidation(Attfiles)){ return; }
    
    data.CCUser = CCGroup === true ? "Yes": "No";
    data.flag = "1";
    delete data.FileAttachment; // remove file attachment data from schema
    console.log("Schema Data:", data);

    await sp.web.lists.getByTitle(Props.PanePropsBriaList).items.add(data)
    .then(async (addResult) => {
      console.log("add result:",addResult);

      if(Attfiles && Attfiles?.length > 0){
        const PromoseArray = [];
        setShowSuccess(true);
        setmessage("Please wait while we upload the file Attachment.");
        setMessageType('primary');
        for(let i =0; i < Attfiles.length; i++){
          const UploadArray = await addFilesPromise( Props.PanePropsBriaList, addResult.ID ,Attfiles, i);
          PromoseArray.push(UploadArray);
        }
        Promise.all(PromoseArray).then( res => { 
          console.log("Promise Upload resolve:", res);
          setShowSuccess(true);
          setmessage("Successfully Submitted Your Request.");
          setMessageType('success');
          reset();
        })
        .catch(err => { 
          console.log("Promise Upload reject:", err);
          setShowSuccess(true);
          setmessage("Your Request is Submitted but there was a problem uploading the attachment");
          setMessageType('danger');
          reset();
        });
      }else{
        setShowSuccess(true);
        setmessage("Successfully Submitted Your Request without Attachment.");
        setMessageType('info');
        reset();
      }
      const WFresult = await WorkFlowSubmit(addResult.ID.toString(), true, "Pending", "PMO Review", "2", data.ProjectName);
      console.log("WF Result:", WFresult);
      reset();
      setModalShow(true);
      return Promise.resolve;
    })
    .catch( (error) => {
        console.log("Error Submit:", error);
        setShowSuccess(true);
        setmessage("Sorry! Your Request failed to Submit. Please try again.");
          setMessageType('danger');
        return Promise.reject;
    });
    
  };
    // React.useEffect(() => {
    //   async function test():Promise<void>{
    //     const sp = getSP(Props.spContext);
    //     const pm:IWrorkFlow[] = await sp.web.lists.getByTitle("Workflow List").items.filter(`itemID eq '4' and Transaction eq 'Submittals'`)();
    //     console.log("WF:",pm);
    //   }
    //   test().catch(console.error);
    // },[]);
      //  React.useEffect(() => {
      //   async function test():Promise<void>{
      //     const sp = getSP(Props.spContext);
      //     const pm:IProjectListItem[] = await sp.web.lists.getByTitle("Project Lists").items.filter(`ID eq '1'`)();
      //     console.log("PROJECTLIST:",pm);
      //   }
      //   test().catch(console.error);
      // },[]);
  
    return(
      <section className={`${styles.briaSpfx} ${Props.hasTeamsContext ? styles.teams : ''}`}>
         <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
         <Container>
              <Card>
                <Card.Header className="h5">Builders Risk Ins Application Review (BRIA)</Card.Header>
                <Card.Body>
                {/* <DatePicker
     style= {{width: '100%'}}
     placeholder = "Select Delivery Date" maxDate={dayjs()}
  
  /> */}
                  <Row>
                    <Col>
                    <Form.Group className="mb-3">
                      <Form.Label className={styles.required}>Project Number and Name</Form.Label>
                      <Form.Select aria-label="Please Select Project" {...register("ProjectName")} isInvalid={ !!errors.ProjectName }>
                        <option value="">Please Select Project</option> 
                          {Props.spProjectListItems && Props.spProjectListItems.map((list) => {
                                return  ( 
                                  <option key={list.id} value={list.ProjectName}>{list.ProjectName}</option> 
                                );
                          })}
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.ProjectName?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label className={styles.required}>Requester Name</Form.Label>
                        <Form.Control type="text" {...register("RequesterName")} defaultValue={Props.userDisplayName} isInvalid={ !!errors.RequesterName }/>
                        <Form.Control.Feedback type="invalid">
                          {errors.RequesterName?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group className="mb-3">
                        <Form.Label className={styles.required}>Requester Email</Form.Label>
                        <Form.Control type="email" {...register("RequesterEmail")} isInvalid={ !!errors.RequesterEmail } defaultValue={Props.userEmail}/>
                        <Form.Control.Feedback type="invalid">
                          {errors.RequesterEmail?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group className="mb-5">
                        <Form.Label className={styles.required}>Subject</Form.Label>
                        <Form.Control type="text"  {...register("Subject")} isInvalid={ !!errors.Subject }/>
                        <Form.Control.Feedback type="invalid">
                          {errors.Subject?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row className='mt-4 mb-5'>
                    <Col>
                      <Card style={{ width: '100%' }}>
                        <Card.Header>BRIA Template</Card.Header>
                        <Card.Body>
                          <Form.Group>
                            <Form.Control type="file" id="FileAttachment" {...register("FileAttachment")} multiple />
                            <Form.Text id="FileAttachmentHelpBlock" muted>Please attach the blank Builders Risk Insurance Application template</Form.Text>
                            <p className="link-danger">{errors.FileAttachment?.message}</p>
                          </Form.Group>
                        </Card.Body>
                      </Card>
                    </Col>
                  </Row>
                  <Row className="mb-5">
                    <Col>
                      <Card style={{ width: '100%' }}>
                        <Card.Header>CC Users</Card.Header>
                        <Card.Body>
                        <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                          <Form.Group className="mb-3">
                            <Form.Check
                              inline
                              label="Yes"
                              value="true"
                              {...register("CCUser")} 
                              onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                            />
                          </Form.Group>
                          <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                            <Form.Label className={styles.required}>Email Addresses</Form.Label>
                            <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                            <Form.Control.Feedback type="invalid">
                              {errors.CCEmails?.message}
                            </Form.Control.Feedback>
                          </Form.Group>
                          <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                            <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                            <Form.Control as="textarea" rows={3} {...register("CCComment")} />
                          </Form.Group>
                        </Card.Body>
                      </Card>
                    </Col>
                  </Row>
                  
                  <Row className="mb-4">
                    <Col>
                      <div className="d-grid gap-2">
                        <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting } >
                        <Spinner
                          as="span"
                          animation="border"
                          size="sm"
                          role="status"
                          aria-hidden={ !!isSubmitting }
                          className={ isSubmitting ? "me-2": "visually-hidden" } />
                        { isSubmitting ? "...Submitting" : "SUBMIT" }
                        </Button>
                      </div>
                    </Col>
                  </Row>
                  { ShowSuccess && (
                      <Alert 
                        key={ MessageType } 
                        variant={ MessageType } 
                        dismissible 
                        onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                          { message }
                      </Alert>
                  )}
                </Card.Body>
              </Card>
            </Container>
          </form>
          <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
            <Modal.Header>
              <Modal.Title>SharePoint</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Alert variant="primary">
                <Alert.Heading>{ message }</Alert.Heading>
                <p hidden={MessageType === "danger" ? true : false}>
                  Thank you! You can now close this tab or window.
                </p>
              </Alert>
            </Modal.Body>
            <Modal.Footer hidden={MessageType === "danger" ? false : true}>
              <Button variant="secondary" onClick={handleClose}>
                Continue
              </Button>
            </Modal.Footer>
          </Modal>
        </section>
    );
  }
