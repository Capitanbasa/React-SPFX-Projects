  export const DTFormat = (d:string): string => {
    const newdate = new Date(d);
    return newdate.toLocaleDateString('default', { month: 'short', day: 'numeric', year: 'numeric'});
  }