import * as yup from 'yup';

export const BriaFormSchema = yup.object().shape({
    Stage: yup.string().default("PMO Review").notRequired(),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),
    ProjectName: yup.string().required("Project Number - Project Name is required"),
    RequesterName: yup.string().required("Requester Name is required"),
    RequesterEmail: yup.string().required().email("Requester Email is required"),
    Subject: yup.string().required("Subject is required"),
    FileAttachment: yup.mixed().test("FileAttachment", "You need to provide a BRIA Template file", (file:FileList) => { if(file?.length > 0) { return true;}else{ return false;} }),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TBriaFormSchema = yup.InferType<typeof BriaFormSchema>

export const BriaFormPMOSchema = yup.object().shape({
    Stage: yup.string().default("PMO Review").required("Next step is required"),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),
    
    DelegatedTo: yup.string().when('Stage', {is: (stage:string) => stage==="Delegate", then: () => yup.string().required("Please select a User"), otherwise: () => yup.number().notRequired() }),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TBriaFormPMOSchema = yup.InferType<typeof BriaFormPMOSchema>

export const BriaFormPCESchema = yup.object().shape({
    Stage: yup.string().default("PMO Review").required("Next step is required"),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),
    
    NeedingRevision: yup.string().when('Stage', {is: (stage:string) => stage === "PMO Review", then: () => yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TBriaFormPCESchema= yup.InferType<typeof BriaFormPCESchema>

export interface IWrorkFlow{
    Id?: number;
    itemID?: string;
    Transaction?: string;
    Stage: string;
    Status:string;
    flag?: string;
}

export interface IDelegateItem{
    id: string;
    imageInitials: string;
    imageUrl: string;
    loginName:string;
    optionalText:string;
    secondaryText:string;
    tertiaryText:string;
    text:string;
}