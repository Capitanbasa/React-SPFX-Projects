import * as yup from 'yup';

export const PMSchema = yup.object({
    ddnextstep: yup.string().required("Next Step is required. Please Select the Next step."),
    PMComment: yup.string().when('ddnextstep', {is: (ddnextstep: string) => ddnextstep ==='Revise' || ddnextstep ==='Customer Rejected' , then: () =>  yup.string().required("Comments is required"), otherwise: () => yup.string().notRequired() }),
    approveSizeChange: yup.string().notRequired(),
    CurrentSize: yup.string().when('approveSizeChange', {is: (approveSizeChange: string) => approveSizeChange ==='Yes', then: () =>  yup.string().required("Current Size is required"), otherwise: () => yup.string().notRequired() }),
    NewSize: yup.string().when('approveSizeChange', {is: (approveSizeChange: string) => approveSizeChange ==='Yes', then: () =>  yup.string().required("New Size is required"), otherwise: () => yup.string().notRequired() }),
    approveProductChange: yup.string().notRequired(),
    CurrentProduct: yup.string().when('approveProductChange', {is: (approveProductChange: string) => approveProductChange ==='Yes', then: () =>  yup.string().required("Current Product is required"), otherwise: () => yup.string().notRequired() }),
    NewProduct: yup.string().when('approveProductChange', {is: (approveProductChange: string) => approveProductChange ==='Yes', then: () =>  yup.string().required("New Product is required"), otherwise: () => yup.string().notRequired() }),
    approveNegativeChange: yup.string().notRequired(),
    NegativeOrderNotes: yup.string().when('approveNegativeChange', {is: (approveNegativeChange: string) => approveNegativeChange ==='Yes', then: () =>  yup.string().required("Notes is required"), otherwise: () => yup.string().notRequired() }),
    ddTaskNumber: yup.string().when('approveNegativeChange', {is: (approveNegativeChange: string) => approveNegativeChange ==='Yes', then: () =>  yup.string().required("Task Number is required"), otherwise: () => yup.string().notRequired() }),
    ExecutedLink:  yup.string().when('ddnextstep', {is: (ddnextstep: string) => ddnextstep ==='Customer Approved', then: () =>  yup.string().required("Executed CO Link is required"), otherwise: () => yup.string().notRequired() }),
    DelegationEmail: yup.string().when('ddnextstep', {is: (ddnextstep: string) => ddnextstep ==='Delegate', then: () =>  yup.string().required("Delegation User is required"), otherwise: () => yup.string().notRequired() }),
});