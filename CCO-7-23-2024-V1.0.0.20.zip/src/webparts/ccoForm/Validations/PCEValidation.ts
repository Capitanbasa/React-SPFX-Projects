import * as yup from 'yup';

export const PCESchema = yup.object().shape({
    ccUsers: yup.string().default("false"),
    CCEmail: yup.string().when('ccUsers', {is: "true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    ddnextstep: yup.string().required("Next Step is required. Please Select the Next step."),
    CommentforPM: yup.string().when('ddnextstep', {is: (ddnextstep: string) => ddnextstep ==='Return to PM', then: () =>  yup.string().required("Comments is required"), otherwise: () => yup.string().notRequired() }),
    DelegationEmail: yup.string().when('ddnextstep', {is: (ddnextstep: string) => ddnextstep ==='Delegate', then: () =>  yup.string().required("Delegation Email is required"), otherwise: () => yup.string().notRequired() }),
    OracleDate: yup.string().when('ddnextstep', {is: (ddnextstep: string) => ddnextstep ==='Oracle Updated', then: () =>  yup.string().required("Date Oracle Updated is required"), otherwise: () => yup.string().notRequired() }),
    OracleTaskNumber: yup.string().when('ddnextstep', {is: (ddnextstep: string) => ddnextstep ==='Oracle Updated', then: () =>  yup.string().required("Task Number is required"), otherwise: () => yup.string().notRequired() }),
    FinalCOAmount: yup.string().when('ddnextstep', {is: (ddnextstep: string) => ddnextstep ==='Oracle Updated', then: () =>  yup.string().required("Final CO Amount is required"), otherwise: () => yup.string().notRequired() }),
});