import * as yup from 'yup';

export const reviseSchema = yup.object().shape({
    Description: yup.string().required(),
    RootCause: yup.string().required("Root Cause is required"),
    OrderAmount: yup.number().typeError("Order Amount must be a number").min(0.1, "Order Amount should not be 0 value").required("Order Amount is required"),
    //typeofchange: yup.array().typeError("Please Select Type of Change").min(1, "at least one Type of Change must be selected"),
    typeofchange: yup.array().typeError("Please Select Type of Change").min(1, "at least one Type of Change must be selected").of(yup.string().required()).required(),
    ETAYear: yup.string().required("Please select a Year"),
    ETAQuarter: yup.string().required("Please select a Quarter"),
    TargetDate: yup.string().required("Target Completion Date is required"),
    ccUsers: yup.string().default("false"),
    CCEmail: yup.string().when('ccUsers', {is: "true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    ddnextstep: yup.string().required("Next Step is required. Please Select the Next step."),
    IRComment: yup.string().when('ddnextstep', {is: (ddnextstep: string) => ddnextstep ==='No', then: () =>  yup.string().required("Comments is required"), otherwise: () => yup.string().notRequired() }),
});