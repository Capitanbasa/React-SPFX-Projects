import * as yup from 'yup';

export const requestSchema = yup.object().shape({
    ProjectName: yup.string().required("Project Number - Project Name is required"),
    RequesterName: yup.string().required("Requester Name is required"),
    Email: yup.string().required().email("Requester Email is required"),
    Subject: yup.string().required("Subject is required"),
    PONumber: yup.string().required("SunPower's PCO Number is required"),
    Description: yup.string().required(),
    RootCause: yup.string().required("Root Cause is required"),
    OrderAmount: yup.number().typeError("Order Amount must be a number").min(0.1, "Order Amount should not be 0 value").required("Order Amount is required"),
    typeofchange: yup.array().typeError("Please Select Type of Change").min(1, "at least one Type of Change must be selected"),
    ETAYear: yup.string().required("Please select a Year"),
    ETAQuarter: yup.string().required("Please select a Quarter"),
    TargetDate: yup.string().required("Target Completion Date is required"),
    ccUsers: yup.string().default("false"),
    CCEmail: yup.string().when('ccUsers', {is: "true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() })
});