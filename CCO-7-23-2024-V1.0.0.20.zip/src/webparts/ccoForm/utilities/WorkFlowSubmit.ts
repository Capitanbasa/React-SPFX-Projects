import { IWrorkFlow } from "../components/ICcoFormProps";
import { getSP } from "../pnpjsConfig";

const WorkFlowSubmit = async (ID:string, Status: string, Stage: string, flag: string = "2" ):Promise<string> => {
    
    let WFData:IWrorkFlow = {
        Stage: Stage,
        Status: Status,
    };

    if(flag !== ""){
       WFData = { ...WFData, ...{ flag: flag }};
    }
    console.log("WF DATA:", WFData);
    const sp = getSP();
    const items: IWrorkFlow[] = await sp.web.lists.getByTitle("Workflow List").items.top(1).filter("itemID eq '"+ID+"' and Transaction eq 'CCO'")();
    console.log("WF QUERY:", items);
    if (items.length > 0 && items[0].Id) {
        return await sp.web.lists.getByTitle("Workflow List").items.getById(items[0].Id).update(WFData)
        .then((res)=>{ return Promise.resolve("WF Success")}).catch((error)=>{ return Promise.reject("WF Error")});
    }else{
        return Promise.reject("WF Error");
    }
}
export default WorkFlowSubmit;