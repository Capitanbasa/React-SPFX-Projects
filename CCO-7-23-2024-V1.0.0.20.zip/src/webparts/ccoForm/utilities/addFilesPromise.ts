import { getSP } from "../pnpjsConfig";
export const addFilesPromise = async (ListName:string, listID:number, file: FileList, index:number ):Promise<boolean> =>{
    const sp = getSP();
    return await sp.web.lists.getByTitle(ListName).items.getById(listID).attachmentFiles.add(file[index].name, file[index]).then((res) =>{ return res } ).catch((error)=>{return error });
  }