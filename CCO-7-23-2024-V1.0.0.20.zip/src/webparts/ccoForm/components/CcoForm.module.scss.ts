/* tslint:disable */
require("./CcoForm.module.css");
const styles = {
  ccoForm: 'ccoForm_bc51fb09',
  teams: 'teams_bc51fb09',
  welcome: 'welcome_bc51fb09',
  welcomeImage: 'welcomeImage_bc51fb09',
  links: 'links_bc51fb09'
};

export default styles;
/* tslint:enable */