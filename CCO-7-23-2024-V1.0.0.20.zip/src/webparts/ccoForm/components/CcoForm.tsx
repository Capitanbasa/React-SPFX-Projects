import * as React  from 'react';
import  styles from './SpFxHttpClientDemo.module.scss';
import { Container, Row, Col, Form, Button, Alert, Spinner, Card, Modal } from 'react-bootstrap';
import { getSP } from '../pnpjsConfig';
import "@pnp/sp/webs";
import "@pnp/sp/lists/web";
import "@pnp/sp/items";
import "@pnp/sp/attachments";

import { requestSchema } from '../Validations/RequestValidation';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup'
import { DatePicker } from "antd";
import { ICcoFormProps, IWrorkFlow } from './ICcoFormProps';


export function CcoForm(props:ICcoFormProps):React.ReactElement {

  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [loadingButton, setloadingButton] = React.useState( "visually-hidden" );
  const [buttonText, setbuttonText] = React.useState( "SUBMIT" );
  const [disableButton, setdisableButton]= React.useState( false );
  const [isCCGroup, setisCCGroup]= React.useState( false );
  const [completionDate, setcompletionDate]= React.useState( "" );
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);

  const DTFormat = (d:string): string => {
    const newdate = new Date(d);
    return newdate.toLocaleDateString('default', { month: 'short', day: 'numeric', year: 'numeric'});
  }
  const form = useForm({
    resolver: yupResolver(requestSchema)
  });

  const WorkFlowSubmit = async (ID:string, ProjectName:string):Promise<string> => {
    const WFData:IWrorkFlow = {
        itemID: ID,
        Transaction: 'CCO',
        Stage: 'PM Review',
        Status: 'Pending',
        flag: '1',
        ProjectName: ProjectName
      };
      const sp = getSP();
      return await sp.web.lists.getByTitle("Workflow List").items.add(WFData)
      .then((res)=>{ return Promise.resolve("WF Success")}).catch((error)=>{ return Promise.reject("WF Error")});
  }

  const addFilesPromise = async (itemID: number, file: FileList, index:number ):Promise<string> =>{
    const sp = getSP();
    return await sp.web.lists.getByTitle(props.PanePropsCCOList).items.getById(itemID)
      .attachmentFiles.add(file[index].name, file[index])
      .then((res) =>{ return Promise.resolve("Done") } )
      .catch((error)=>{ return Promise.reject(error) });
  }

  const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
    if(FileAttachment && FileAttachment?.length > 0){
      for(let i =0; i < FileAttachment.length; i++){
        /* eslint-disable no-useless-escape */
        const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
        if(match){
          setShowSuccess(true);
          setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
          setMessageType('danger');
          return true;
        }else{
          return false;
        }

      }
    }
    return false;
  }

  const addlistItem = async ():Promise<void> => {
    const ProjectName = document.getElementById("txtProjectName") as HTMLInputElement;
    const RequesterName = document.getElementById("txtRequesterName") as HTMLInputElement;
    const RequesterEmail = document.getElementById("txtEmail") as HTMLInputElement;
    const subject = document.getElementById("txtSubject") as HTMLInputElement;
    const PocNumber = document.getElementById("txtPocNumber") as HTMLInputElement;
    const Description = document.getElementById("txtDescription") as HTMLInputElement;
    const RootCause = document.getElementById("txtRootCause") as HTMLInputElement;
    const OrderAmount = document.getElementById("txtOrderAmount") as HTMLInputElement;
    const typeofchange =  document.querySelectorAll('input[name="typeofchange"]') as NodeListOf<HTMLInputElement>;
    const ExpectedYear = document.getElementById("txtYear") as HTMLInputElement;
    const ExpectedQuarter = document.getElementById("txtQuarter") as HTMLInputElement;
    const CCEmail = document.getElementById("txtCCEmail") as HTMLInputElement;
    const CCCommet = document.getElementById("txtCommets") as HTMLInputElement;
    const Attachment = document.getElementById("inputAttachment") as HTMLInputElement;
    const Attfiles = Attachment.files;

    if(filenameCharValidation(Attfiles)){ return; }

    setloadingButton("me-2"); 
    setbuttonText("Loading...");
    setdisableButton(true);

    let typeofchangeList:string | null = "";

    typeofchange.forEach(c => {
      if(c.checked === true){
        if(typeofchangeList === ""){
          typeofchangeList = c.value;
        }else{
          typeofchangeList =  typeofchangeList + ", " + c.value;
        }
      }
      
    });

    const sp = getSP();
    const itemBody = {
      ProjectName: ProjectName.value,
      RequesterName: RequesterName.value,
      RequesterEmail: RequesterEmail.value,
      Subject: subject.value,
      SunPowerPCONumber: PocNumber.value,
      DescriptionofChange: Description.value,
      CORootCause: RootCause.value,
      ChangeOrderAmount: OrderAmount.value,
      TypeofChange: typeofchangeList,
      ExpectedYear: ExpectedYear.value,
      ExpectedQuarter: ExpectedQuarter.value,
      TargetDate: DTFormat(completionDate),
      CCUsers: isCCGroup === true ? "Yes": "No",
      CCEmails: CCEmail.value,
      CCComment: CCCommet.value,
      Transaction: "CCO",
      Status: "Pending",
      Stage: "PM Review",
      flag: "1"
    };
    console.log("TO SUMIT:", itemBody );
    const theformtoreset = document.getElementById("spwr-form") as HTMLFormElement;
    await sp.web.lists.getByTitle(props.PanePropsCCOList).items.add(itemBody)
      .then( async (addResult) => {
        console.log("ADD Result:",addResult);
          if(Attfiles && Attfiles?.length > 0){
            const PromoseArray = [];
            setShowSuccess(true);
            setmessage("Please wait while we upload the file Attachment.");
            setMessageType('warning');
            for(let i =0; i < Attfiles.length; i++){
              const UploadArray = await addFilesPromise( addResult.ID ,Attfiles, i);
              PromoseArray.push(UploadArray);
            }
            Promise.all(PromoseArray).then( re => { 
              setShowSuccess(true);
              setmessage("Successfully Submitted Your Request.");
              setMessageType('success');
              setloadingButton("visually-hidden");
              setbuttonText("SUBMIT");
              setdisableButton(false);
              theformtoreset.reset();
              form.reset()
            })
            .catch(err => { 
              setShowSuccess(true);
              setmessage("Your Request is Submitted but there was a problem uploading the attachment");
              setMessageType('danger');
              setloadingButton("visually-hidden");
              setbuttonText("SUBMIT");
              setdisableButton(false);
              theformtoreset.reset();
              form.reset()
            });
          }else{
            setShowSuccess(true);
            setmessage("Successfully Submitted Your Request without Attachment.");
            setMessageType('warning');
            setloadingButton("visually-hidden");
            setbuttonText("SUBMIT");
            setdisableButton(false); 
            theformtoreset.reset();
            form.reset();
          }
          setModalShow(true);
          const WFresult = await WorkFlowSubmit(addResult.ID.toString(), ProjectName.value);
          console.log("WF Result:", WFresult);

      })
      .catch((error) => {
          console.log("Error: ", error);
          setShowSuccess(true);
          setmessage("Sorry! Your Request failed to Submit. Please try again.");
          setMessageType('danger');
          setloadingButton("visually-hidden"); 
          setbuttonText("SUBMIT");
          setdisableButton(false);
      });
      
    }

    

    const {register, handleSubmit, formState } = form;
    const { errors } = formState;
  
    return (
      <section className={`${styles.spFxHttpClientDemo} ${props.hasTeamsContext ? styles.teams : ''}`}>
        <form noValidate id="spwr-form" onSubmit={handleSubmit(addlistItem)}>
          <Container>
            <Row>
              <Col>
                <Form.Group className="mb-3">
                  <Form.Label className={styles.required}>Project Number and Name</Form.Label>
                  <Form.Select aria-label="Please Select Project" id="txtProjectName" {...register("ProjectName")} isInvalid={!!errors.ProjectName } >
                  <option value="">Please Select Project</option> 
                    {props.spProjectListItems && props.spProjectListItems.map((list) => {
                          return  ( 
                            <option key={list.id} value={list.ProjectName}>{list.ProjectName}</option> 
                          );
                    })}
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {errors.ProjectName?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col>
              <Form.Group className="mb-3" >
                <Form.Label className={styles.required}>Requester Name</Form.Label>
                <Form.Control type="text" id="txtRequesterName" {...register("RequesterName")} defaultValue={props.userDisplayName} isInvalid={!!errors.RequesterName }/>
                <Form.Control.Feedback type="invalid">
                  {errors.RequesterName?.message}
                </Form.Control.Feedback>
              </Form.Group>
                
              </Col>
              <Col>
                <Form.Group className="mb-3">
                  <Form.Label className={styles.required}>Requester Email</Form.Label>
                  <Form.Control type="email" id="txtEmail" {...register("Email")} isInvalid={!!errors.Email } defaultValue={props.userEmail}/>
                  <Form.Control.Feedback type="invalid">
                    {errors.Email?.message}
                </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col>
                <Form.Group className="mb-3" >
                  <Form.Label className={styles.required}>Subject</Form.Label>
                  <Form.Control type="text" id="txtSubject" {...register("Subject")} isInvalid={!!errors.Subject }/>
                  <Form.Control.Feedback type="invalid">
                    {errors.Subject?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            <Row className="mt-4">
              <Col>
                <Form.Group className="mb-3" >
                  <Form.Label className={styles.required}>SunPower&lsquo;s PCO #</Form.Label>
                  <Form.Control type="text" id="txtPocNumber" {...register("PONumber")} isInvalid={!!errors.PONumber }/>
                  <Form.Control.Feedback type="invalid">
                    {errors.PONumber?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col>
                <Form.Group className="mb-3" >
                  <Form.Label className={styles.required}>Description of Change</Form.Label>
                  <Form.Control as="textarea" rows={3} id="txtDescription" {...register("Description")} isInvalid={!!errors.Description }/>
                  <Form.Control.Feedback type="invalid">
                    {errors.Description?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col>
                <Form.Group className="mb-3">
                  <Form.Label className={styles.required}>CO Root Cause</Form.Label>
                  <Form.Select aria-label="Please Select a Root Caus" id="txtRootCause" {...register("RootCause")} isInvalid={!!errors.RootCause }>
                    <option value="">Please Select a Root Cause</option> 
                    {props.spRootCausetListItems && props.spRootCausetListItems.map((list) => {
                          return  ( 
                            <option key={list.id} value={list.Title}>{list.Title}</option> 
                          );
                    })}
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {errors.RootCause?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col>
                <Form.Group className="mb-3" >
                  <Form.Label className={styles.required}>Proposed Change Order Amount</Form.Label>
                  <Form.Control type="text" id="txtOrderAmount" {...register("OrderAmount")} isInvalid={!!errors.OrderAmount }/>
                  <Form.Control.Feedback type="invalid">
                    {errors.OrderAmount?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            <Row className="mb-5">
              <Col>
                <Card style={{ width: '100%' }}>
                  <Card.Header>Type of Change</Card.Header>
                  <Card.Body>
                    <Form.Group className="mb-3" >
                      <div key="checkbox" className="mb-3">
                        {props.spTypeChangetListItems && props.spTypeChangetListItems.map((list) => {
                              return  ( 
                                <Form.Check key={list.id}
                                  inline
                                  label={list.Title}
                                  type="checkbox"
                                  value={list.Title}
                                  id={(`inline-checkbox-${list.id}`)}
                                  {...register("typeofchange")}
                                  isInvalid={!!errors.typeofchange }
                                />
                              );
                        })}
                      </div>
                      <p className="link-danger">{errors.typeofchange?.message}</p>
                    </Form.Group>
                  </Card.Body>
                </Card>
              </Col>
            </Row>
            <Row>
              <Col>
                <div className="mb-3">
                    <h5 className="mb-1">Expected time agreement will be finalized</h5>
                </div>
              </Col>
            </Row>
            <Row>
              <Col>
              <Form.Group className="mb-4">
                  <Form.Label className={styles.required}>Year</Form.Label>
                  <Form.Select aria-label="Please Select Year" id="txtYear" {...register("ETAYear")} isInvalid={!!errors.ETAYear }>
                    <option value="">Please Select Year</option>
                    {props.spExpectedYearListItems && props.spExpectedYearListItems.map((list) => {
                          return  ( 
                            <option key={"year-"+list.id} value={list.Year}>{list.Year}</option> 
                          );
                    })}
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {errors.ETAYear?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
              <Col>
              <Form.Group className="mb-4">
                  <Form.Label className={styles.required}>Quarter</Form.Label>
                  <Form.Select aria-label="Please Select Quarter" id="txtQuarter" {...register("ETAQuarter")} isInvalid={!!errors.ETAQuarter }>
                    <option value="">Please Select Quarter</option>
                    <option key='q1' value="Q1">Q1</option>
                    <option key='q2' value="Q2">Q2</option>
                    <option key='q3' value="Q3">Q3</option>
                    <option key='q3' value="Q4">Q4</option>
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {errors.ETAQuarter?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col>
                <Form.Group className="mb-4" >
                  <Form.Label className={styles.required}>Target Completion Date</Form.Label>
                  <DatePicker 
                    className='form-control' 
                    allowClear={true}
                    format={"MMM DD, YYYY"}
                    {...register("TargetDate")}  
                    onChange={(e): void => {  if(e){ form.setValue("TargetDate", e.toString(),  { shouldValidate: true }); setcompletionDate(  e.toString()) } }} />

                  <Form.Control.Feedback type="invalid">
                    {errors.TargetDate?.message} 
                  </Form.Control.Feedback>
                  <p className="link-danger">{errors.TargetDate?.message}</p>
                </Form.Group>
              </Col>
            </Row>
            {/* <Row>
              <Col>
                <Form.Group className="mb-4" >
                  <Form.Label className={styles.required}>Target Completion Date</Form.Label>
                  <DatePicker 
                    className='form-control'
                    {...register("TargetDate")} 
                    selected={completionDate}
                    dateFormat="MMM dd, yyy"
                    isClearable
                    onChange={(date): void => { setcompletionDate(date ? date: new Date() ) }} 
                    ariaInvalid={"aria-invalid"}/>
                  <Form.Control.Feedback type="invalid">
                    {errors.TargetDate?.message} 
                  </Form.Control.Feedback>
                  <p className="link-danger">{errors.TargetDate?.message}</p>
                </Form.Group>
              </Col>
            </Row> */}
            <Row className="mb-5">
              <Col>
                <Card style={{ width: '100%' }}>
                  <Card.Header>CC Users</Card.Header>
                  <Card.Body>
                  <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                    <Form.Group className="mb-3" >
                            <Form.Check
                              inline
                              label="Yes"
                              value="true"
                              defaultChecked={isCCGroup}
                              {...register("ccUsers", { onChange : (e) => { setisCCGroup(e.currentTarget.checked === true ? true : false ) }})}
                              isInvalid={!!errors.ccUsers }
                            />

                        <p className="link-danger">{errors.ccUsers?.message}</p>
                    </Form.Group>
                    <Form.Group className="mb-3" hidden={!isCCGroup}>
                      <Form.Label className={styles.required}>Email Addresses</Form.Label>
                      <Form.Control type="text" id="txtCCEmail"  {...register("CCEmail")} isInvalid={!!errors.CCEmail }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.CCEmail?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                    <Form.Group className="mb-3" hidden={!isCCGroup}>
                      <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                      <Form.Control as="textarea" rows={3} id="txtCommets"/>
                    </Form.Group>
                  </Card.Body>
                </Card>
              </Col>
            </Row>
            <Row>
              <Col>
                <Form.Group className="mb-5">
                  <Form.Label >Executed PCO</Form.Label>
                  <Form.Control type="file" id="inputAttachment" multiple />
                </Form.Group>
              </Col>
            </Row>
            <Row className="mb-3">
              <Col>
                <div className="d-grid gap-2">
                  <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ disableButton }>
                  <Spinner
                    as="span"
                    animation="border"
                    size="sm"
                    role="status"
                    aria-hidden="true"
                    className={ loadingButton }
                  />
                  { buttonText }
                  </Button>
                </div>
              </Col>
            </Row>
            { ShowSuccess && (
                <Alert 
                  key={ MessageType } 
                  variant={ MessageType } 
                  dismissible 
                  onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                    { message }
                </Alert>
            )}
          </Container>
        </form>
        <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
          <Modal.Header>
            <Modal.Title>SharePoint</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Alert variant="primary">
              <Alert.Heading>{ message }</Alert.Heading>
              <p hidden={MessageType === "danger" ? true : false}>
                Thank you! You can now close this tab or window.
              </p>
            </Alert>
          </Modal.Body>
          <Modal.Footer hidden={MessageType === "danger" ? false : true}>
            <Button variant="secondary" onClick={handleClose}>
              Continue
            </Button>
          </Modal.Footer>
        </Modal> 
      </section>
    );

}