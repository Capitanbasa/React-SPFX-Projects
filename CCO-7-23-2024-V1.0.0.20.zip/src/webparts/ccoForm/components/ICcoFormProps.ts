import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface ICcoFormProps {
  spProjectListItems?: IProjectListItem[];
  spRootCausetListItems?: IRootCauseListItem[];
  spTypeChangetListItems?: ITypeChangeListItem[];
  spExpectedYearListItems?: IExpectedYearListItem[];
  spCCOItem: ICCOListItem[];
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  userEmail:string;
  description:string;
  spContext:WebPartContext;
  PanePropsProjectNumberName: string;
  PanePropsRootCause: string;
  PanePropsTypeChange:string;
  PanePropsExpectedYear:string;
  PanePropsCCOList:string;
}

export interface IProjectListItem{
  id: string;
  ProjectName: string;
}
export interface IRootCauseListItem{
  id: string;
  Title: string;
}
export interface ITypeChangeListItem{
  id: string;
  Title: string;
}
export interface IExpectedYearListItem{
  id: string;
  Year: string;
}
export interface ICCOListItem{
  ID: string;
  Stage: string;
  Status:string;
  ProjectName: string;
  RequesterName: string;
  RequesterEmail:string;
  Subject:string;
  SunPowerPCONumber:string;
  DescriptionofChange:string;
  CORootCause:string;
  ChangeOrderAmount:number;
  TypeofChange:string;
  ExpectedYear:string;
  ExpectedQuarter:string;
  TargetDate:string;
  CCUsers: string;
  CCEmails:string;
  CCComment:string;
  Attachments:boolean;
  CoordinatorComment:string;
  PMComment:string;
  DelegationEmail:string;
  IRComment:string;
  SizeChange:string;
  CurrentSize:string;
  NewSize:string;
  ProductChange:string;
  CurrentProduct:string;
  NewProduct:string;
  ScheduleChange:string;
  NegativeChangeOrder:string;
  TaskNumber:string;
  ChangeOrderNotes:string;
  CommentforPM: string;
  OracleDate:string;
  OracleTaskNumber:string;
  ExecutedCOLink:string;
  FinalCOAmount:number;
  AssignedToId: number;
  PMReviewer: string;
  PMReviewerId: number;
  PCEReviewer: string;
  PCEReviewerId: number;
  VoidComment: string;
}

export interface IWrorkFlow{
  Id?: number;
  itemID?: string;
  Transaction?: string;
  Stage?: string;
  Status?:string;
  flag?: string;
  ProjectName?:string;
}
