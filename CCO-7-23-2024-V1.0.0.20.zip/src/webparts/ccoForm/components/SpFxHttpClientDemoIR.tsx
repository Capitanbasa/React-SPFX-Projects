import * as React  from 'react';
import  styles from './SpFxHttpClientDemo.module.scss';
import type { ISpFxHttpClientDemoWebPartProps } from './ISpFxHttpClientDemoProps';
import { Container, Row, Col, Form, Button, Alert, Spinner, Card, Modal } from 'react-bootstrap';
import { getSP } from '../pnpjsConfig';
import "@pnp/sp/webs";
import "@pnp/sp/lists/web";
import "@pnp/sp/items";
import "@pnp/sp/attachments";

import { DatePicker } from "antd";
// import { format } from '@fluentui/react';
// import { DateFormatter } from '@microsoft/fast-foundation';

import { reviseSchema } from '../Validations/ReviseValidation';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import WorkFlowSubmit from '../utilities/WorkFlowSubmit';
interface TProjectList {
  ProjectLeadId: number;
}

export function SpFxHttpClientDemoIR(props:ISpFxHttpClientDemoWebPartProps):React.ReactElement {

  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [loadingButton, setloadingButton] = React.useState( "visually-hidden" );
  const [buttonText, setbuttonText] = React.useState( "SUBMIT" );
  const [disableButton, setdisableButton]= React.useState( false );
  const [isCCGroup, setisCCGroup]= React.useState( props.spCCOItem[0].CCUsers === "Yes" ? true : false );
  const [NextStep, setNextStep] = React.useState("");
  const [completionDate, setcompletionDate]= React.useState( "" );
  const [AssignedTo, setAssignedTo]= React.useState<number>( 0 );
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);
 

  const DTFormat = (d:string): string => {
    const newdate = new Date(d);
    return newdate.toLocaleDateString('default', { month: 'short', day: 'numeric', year: 'numeric'});
  }

  const form = useForm({
    resolver: yupResolver(reviseSchema)
  });

  const addFilesPromise = async (itemID: number, file: FileList, index:number ):Promise<string> =>{
    const sp = getSP();
    return await sp.web.lists.getByTitle(props.PanePropsCCOList).items.getById(itemID)
      .attachmentFiles.add(file[index].name, file[index])
      .then((res) =>{ return Promise.resolve("Done") } )
      .catch((error)=>{ return Promise.reject(error) });
  }
 
  const CCEmails:string = props.spCCOItem[0].CCEmails !== null ? props.spCCOItem[0].CCEmails : "";
  const CCComment:string = props.spCCOItem[0].CCComment !== null ? props.spCCOItem[0].CCComment : "";
  const PMCommets = props.spCCOItem[0].PMComment !== null ? props.spCCOItem[0].PMComment : "";
  const VoidComment = props.spCCOItem[0].VoidComment !== null ? props.spCCOItem[0].VoidComment : "";

  React.useEffect(() => {
    async function getProjectPM(ProjectName:string):Promise<void>{
      console.log(ProjectName);
      const sp = getSP(props.spContext);
      const pm:TProjectList[] = await sp.web.lists.getByTitle("Project Lists").items.select('ProjectLeadId').filter(`ProjectName eq '${ProjectName}'`)();
      console.log("PM:",pm);
      setAssignedTo(pm[0].ProjectLeadId);
      console.log(AssignedTo);
    }
    getProjectPM(props.spCCOItem[0].ProjectName).catch(console.error);
  },[]);

  const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
    if(FileAttachment && FileAttachment?.length > 0){
      for(let i =0; i < FileAttachment.length; i++){
        /* eslint-disable no-useless-escape */
        const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
        if(match){
          setShowSuccess(true);
          setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
          setMessageType('danger');
          return true;
        }else{
          return false;
        }
      }
    }
    return false;
  }

  const addlistItem = () :void => {
    //PM Review DATA
    const CCEmail = document.getElementById("txtCCEmail") as HTMLInputElement;
    const CCCommet = document.getElementById("txtCommets") as HTMLInputElement;
    const NextStep = document.getElementById("ddnextstep") as HTMLInputElement;
    const IRComment = document.getElementById('txtIRComment') as HTMLInputElement;
    const Description = document.getElementById("txtDescription") as HTMLInputElement;
    const RootCause = document.getElementById("txtRootCause") as HTMLInputElement;
    const OrderAmount = document.getElementById("txtOrderAmount") as HTMLInputElement;
    const typeofchange =  document.querySelectorAll('input[name="typeofchange"]') as NodeListOf<HTMLInputElement>;
    const ExpectedYear = document.getElementById("txtYear") as HTMLInputElement;
    const ExpectedQuarter = document.getElementById("txtQuarter") as HTMLInputElement;

    const Attachment = document.getElementById("inputAttachment") as HTMLInputElement;
    const Attfiles = Attachment.files;
    if(filenameCharValidation(Attfiles)){ return; }

    setloadingButton("me-2"); 
    setbuttonText("Loading...");
    setdisableButton(true);

    let typeofchangeList:string | null = "";

    typeofchange.forEach(c => {
      if(c.checked === true){
        if(typeofchangeList === ""){
          typeofchangeList = c.value;
        }else{
          typeofchangeList =  typeofchangeList + ", " + c.value;
        }
      }
      
    });

    let newStage:string = "Void";
    let newStatus:string = "Void";
    let itemBody = {};
    if(NextStep.value === 'No'){
       itemBody = {
        Status: 'Void',
        Stage: "Void",
        DescriptionofChange: Description.value,
        CORootCause: RootCause.value,
        ChangeOrderAmount: OrderAmount.value,
        TypeofChange: typeofchangeList,
        ExpectedYear: ExpectedYear.value,
        ExpectedQuarter: ExpectedQuarter.value,
        TargetDate: DTFormat(completionDate),
        CCUsers: isCCGroup === true ? "Yes": "No",
        CCEmails: CCEmail.value,
        CCComment: CCCommet.value,
        //IRComment : IRComment.value,
        VoidComment: IRComment.value
      };
      newStage = "Void";
      newStatus = "Void";
    }else{ 
      itemBody = {
        Status: 'Pending',
        Stage: "PM Review",
        flag: "2",
        AssignedToId: props.spCCOItem[0].PMReviewerId,
        DescriptionofChange: Description.value,
        CORootCause: RootCause.value,
        ChangeOrderAmount: OrderAmount.value,
        TypeofChange: typeofchangeList,
        ExpectedYear: ExpectedYear.value,
        ExpectedQuarter: ExpectedQuarter.value,
        TargetDate: DTFormat(completionDate),
        CCUsers: isCCGroup === true ? "Yes": "No",
        CCEmails: CCEmail.value,
        CCComment: CCCommet.value,
        IRComment : IRComment.value
      };
      newStage = "PM Review";
      newStatus = "Pending";
    }
    console.log("SUBMIT DATA:", itemBody);
    const sp = getSP(props.spContext);
    const theformtoreset = document.getElementById("spwr-form") as HTMLFormElement;
    const list = sp.web.lists.getByTitle(props.PanePropsCCOList);
    list.items.getById(parseInt(props.spCCOItem[0].ID)).update(itemBody)
      .then(async (addResult) => {
          if(Attfiles && Attfiles?.length > 0){
            setShowSuccess(true);
            setmessage("Please wait while we upload the file Attachment.");
            setMessageType('warning');
            const PromoseArray = [];
            for(let i =0; i < Attfiles.length; i++){
              const UploadArray = await addFilesPromise( parseInt(props.spCCOItem[0].ID) ,Attfiles, i);
              PromoseArray.push(UploadArray);
            }
            Promise.all(PromoseArray).then( re => { 
              setShowSuccess(true);
              setmessage("Successfully Submitted Your Request.");
              setMessageType('success');
              setloadingButton("visually-hidden");
              setbuttonText("SUBMIT");
              setdisableButton(false);
              theformtoreset.reset();
              form.reset()
            })
            .catch(err => { 
              setShowSuccess(true);
              setmessage("Your Request is Submitted but there was a problem uploading the attachment");
              setMessageType('danger');
              setloadingButton("visually-hidden");
              setbuttonText("SUBMIT");
              setdisableButton(false);
              theformtoreset.reset();
              form.reset()
            });
          }else{
            setShowSuccess(true);
            setmessage("Successfully Submitted the Next Step without Attachment.");
            setMessageType('warning');
            setloadingButton("visually-hidden");
            setbuttonText("SUBMIT");
            setdisableButton(false); 
            theformtoreset.reset();
            form.reset();
          }
          const WFresult = await WorkFlowSubmit(props.spCCOItem[0].ID.toString() , newStatus, newStage, "2");
          setModalShow(true);
          console.log("WF Result:", WFresult);
      })
      .catch((error) => {
          console.log("Error Submit: ", error);
          setShowSuccess(true);
          setmessage("Sorry! The Next Step failed to Submit. Please try again.");
          setMessageType('danger');
          setloadingButton("visually-hidden"); 
          setbuttonText("SUBMIT");
          setdisableButton(false);
      });
  
    }

    const {register, handleSubmit, formState } = form;
    const { errors } = formState;

   
    // Attachment getter
    // let attachments: IAttachmentInfo[] = [];
    // React.useEffect(() => {
    //   async function fecthData():Promise<void>{
    //     const sp = getSP();
    //     const item = sp.web.lists.getByTitle(props.PanePropsCCOList).items.getById(parseInt(props.spCCOItem[0].ID));
    //     attachments = await item.attachmentFiles().then(async res => {return await res});
    //     settheAttachmentFiles(attachments);
    //     console.log("await:",attachments);
    //   }
    //   fecthData().catch(console.error);
    // },[]);

    return (
      <section className={`${styles.spFxHttpClientDemo} ${props.hasTeamsContext ? styles.teams : ''}`}>
        <form noValidate id="spwr-form" onSubmit={handleSubmit(addlistItem)}>
          <Container>
            <Card>
              <Card.Header>Customer Change Order (CCO) - INITIATOR REVISION</Card.Header>
              <Card.Body>
                <Row>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Project Number and Name</Form.Label>
                      <Form.Control type="text" id="txtRequesterName" value={props.spCCOItem[0].ProjectName} disabled/>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Instance Number</Form.Label>
                      <Form.Control type="text" id="txtInstanceNumber" value={props.spCCOItem[0].ID} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                  <Form.Group className="mb-3" >
                    <Form.Label>Requester Name</Form.Label>
                    <Form.Control type="text" id="txtRequesterName"  value={props.spCCOItem[0].RequesterName} disabled/>
                  </Form.Group>
                    
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Requester Email</Form.Label>
                      <Form.Control type="email" id="txtEmail" value={props.spCCOItem[0].RequesterEmail} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>Subject</Form.Label>
                      <Form.Control type="text" id="txtSubject" value={props.spCCOItem[0].Subject} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mt-4">
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>SunPower&lsquo;s PCO #</Form.Label>
                      <Form.Control type="text" id="txtPocNumber" value={props.spCCOItem[0].SunPowerPCONumber} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label className={styles.required}>Description of Change</Form.Label>
                      <Form.Control as="textarea" rows={3} id="txtDescription" defaultValue={props.spCCOItem[0].DescriptionofChange} {...register("Description")} isInvalid={!!errors.Description }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.Description?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label className={styles.required}>CO Root Cause</Form.Label>
                      <Form.Select aria-label="Please Select a Root Caus" id="txtRootCause" defaultValue={props.spCCOItem[0].CORootCause} {...register("RootCause")} isInvalid={!!errors.RootCause }>
                        <option value="">Please Select a Root Cause</option> 
                        {props.spRootCausetListItems && props.spRootCausetListItems.map((list) => {
                              return  ( 
                                <option key={list.id} value={list.Title}>{list.Title}</option> 
                              );
                        })}
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.RootCause?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label className={styles.required}>Proposed Change Order Amount</Form.Label>
                      <Form.Control type="text" id="txtOrderAmount" defaultValue={props.spCCOItem[0].ChangeOrderAmount} {...register("OrderAmount")} isInvalid={!!errors.OrderAmount }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.OrderAmount?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>Type of Change</Card.Header>
                     
                      <Card.Body>
                        <Card.Title>Current Type of Change:</Card.Title>
                        <Card.Subtitle className="mb-2 text-muted">{ props.spCCOItem[0].TypeofChange }</Card.Subtitle>
                        <Form.Group className="mb-3" >
                          <div key="checkbox" className="mb-3">
                            {props.spTypeChangetListItems && props.spTypeChangetListItems.map((list) => {
                                  return  ( 
                                    <Form.Check key={list.id}
                                      inline
                                      label={list.Title}
                                      type="checkbox"
                                      value={list.Title}
                                      id={(`inline-checkbox-${list.id}`)}
                                      {...register("typeofchange")}
                                      isInvalid={!!errors.typeofchange }
                                    />
                                  );
                            })}
                          </div>
                          <p className="link-danger">{errors.typeofchange?.message}</p>
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <div className="mb-3">
                        <h5 className="mb-1">Expected time agreement will be finalized</h5>
                    </div>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-4">
                    <Form.Label className={styles.required}>Year</Form.Label>
                      <Form.Select aria-label="Please Select Year" id="txtYear" defaultValue={props.spCCOItem[0].ExpectedYear} {...register("ETAYear")} isInvalid={!!errors.ETAYear }>
                        <option value="">Please Select Year</option>
                        {props.spExpectedYearListItems && props.spExpectedYearListItems.map((list) => {
                              return  ( 
                                <option key={"year-"+list.id} value={list.Year}>{list.Year}</option> 
                              );
                        })}
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.ETAYear?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-4">
                      <Form.Label className={styles.required}>Quarter</Form.Label>
                      <Form.Select aria-label="Please Select Quarter" id="txtQuarter" defaultValue={props.spCCOItem[0].ExpectedQuarter} {...register("ETAQuarter")} isInvalid={!!errors.ETAQuarter }>
                        <option value="">Please Select Quarter</option>
                        <option key='q1' value="Q1">Q1</option>
                        <option key='q2' value="Q2">Q2</option>
                        <option key='q3' value="Q3">Q3</option>
                        <option key='q3' value="Q4">Q4</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.ETAQuarter?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Form.Group className="mb-2" >
                      <Form.Label className={styles.required}>Target Completion Date</Form.Label>
                      <Form.Control type="text" value={props.spCCOItem[0].TargetDate} disabled/>
                    </Form.Group>
                    <Form.Group className="mb-4" >
                      <DatePicker 
                        className='form-control' 
                        allowClear={true}
                        format={"MMM DD, YYYY"}
                        {...register("TargetDate")}  
                        onChange={(e): void => {  if(e){ form.setValue("TargetDate", e.toString(),  { shouldValidate: true }); setcompletionDate(  e.toString()) } }} />
                      <Form.Control.Feedback type="invalid">
                        {errors.TargetDate?.message} 
                      </Form.Control.Feedback>
                      <p className="link-danger">{errors.TargetDate?.message}</p>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>Project Manager Commets</Card.Header>
                      <Card.Body>
                        <Card.Text><p>{ PMCommets }</p></Card.Text>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label >Attachments</Form.Label>
                      <Form.Control type="file" id="inputAttachment" multiple />
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>CC Users</Card.Header>
                      <Card.Body>
                      <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                        <Form.Group className="mb-3" >
                              <Form.Check
                                inline
                                label="Yes"
                                value="true"
                                defaultChecked={isCCGroup}
                                {...register("ccUsers", { onChange : (e) => { setisCCGroup(e.currentTarget.checked === true ? true : false ) }})}
                                isInvalid={!!errors.ccUsers }
                              />

                          <p className="link-danger">{errors.ccUsers?.message}</p>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={!isCCGroup}>
                          <Form.Label className={styles.required}>Email Addresses</Form.Label>
                          <Form.Control type="text" id="txtCCEmail" defaultValue={ CCEmails } {...register("CCEmail")} isInvalid={!!errors.CCEmail }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CCEmail?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={!isCCGroup}>
                          <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                          <Form.Control as="textarea" rows={3} id="txtCommets" defaultValue={ CCComment }/>
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Do you still want to submit this CCO?*</Form.Label>
                      <Form.Select aria-label="Please Select Quarter" id="ddnextstep" {...register("ddnextstep")} isInvalid={!!errors.ddnextstep } onChange={ (e) => { setNextStep(e.currentTarget.value ) }}>
                        <option value="">Please Select Next Step</option>
                        <option key='ns1' value="Yes">Yes</option>
                        <option key='ns2' value="No">No</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.ddnextstep?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5" hidden={NextStep === "No" ? false: true}>
                      <Form.Label className={styles.required}>Comments</Form.Label>
                      <Form.Control as="textarea" rows={3} id="txtIRComment" defaultValue={VoidComment} {...register("IRComment")} isInvalid={!!errors.IRComment }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.IRComment?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-4">
                  <Col>
                    <div className="d-grid gap-2">
                      <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ disableButton } >
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden="true"
                        className={ loadingButton }
                      />
                      { buttonText }
                      </Button>
                    </div>
                  </Col>
                </Row>
                { ShowSuccess && (
                  <Alert 
                      key={ MessageType } 
                      variant={ MessageType } 
                      dismissible 
                      onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                        { message }
                    </Alert>
                )}
              </Card.Body>
            </Card>
          </Container>
        </form>
        <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
          <Modal.Header>
            <Modal.Title>SharePoint</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Alert variant="primary">
              <Alert.Heading>{ message }</Alert.Heading>
              <p hidden={MessageType === "danger" ? true : false}>
                Thank you! You can now close this tab or window.
              </p>
            </Alert>
          </Modal.Body>
          <Modal.Footer hidden={MessageType === "danger" ? false : true}>
            <Button variant="secondary" onClick={handleClose}>
              Continue
            </Button>
          </Modal.Footer>
        </Modal> 
      </section>
    );

}