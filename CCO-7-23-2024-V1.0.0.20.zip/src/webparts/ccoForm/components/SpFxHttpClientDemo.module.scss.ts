/* tslint:disable */
require("./SpFxHttpClientDemo.module.css");
const styles = {
  spFxHttpClientDemo: 'spFxHttpClientDemo_8ae35b96',
  teams: 'teams_8ae35b96',
  welcome: 'welcome_8ae35b96',
  welcomeImage: 'welcomeImage_8ae35b96',
  links: 'links_8ae35b96',
  buttons: 'buttons_8ae35b96',
  required: 'required_8ae35b96',
  divDropArea: 'divDropArea_8ae35b96'
};

export default styles;
/* tslint:enable */