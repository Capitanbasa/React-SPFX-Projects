import * as React  from 'react';
import  styles from './SpFxHttpClientDemo.module.scss';
import type { ISpFxHttpClientDemoWebPartProps } from './ISpFxHttpClientDemoProps';
import { Container, Row, Col, Form, Button, Alert, Spinner, Card, Modal } from 'react-bootstrap';
import { getSP } from '../pnpjsConfig';
import "@pnp/sp/webs";
import "@pnp/sp/lists/web";
import "@pnp/sp/items";
import "@pnp/sp/attachments";
import { IAttachmentInfo } from '@pnp/sp/attachments';
import { IoDocumentAttachOutline } from "react-icons/io5";

import { PMSchema } from '../Validations/PMValidation';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup'

import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import WorkFlowSubmit from '../utilities/WorkFlowSubmit';


export function SpFxHttpClientDemoPM(props:ISpFxHttpClientDemoWebPartProps):React.ReactElement {

  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [loadingButton, setloadingButton] = React.useState( "visually-hidden" );
  const [buttonText, setbuttonText] = React.useState( "SUBMIT" );
  const [disableButton, setdisableButton]= React.useState( false );
  const [isCCGroup, setisCCGroup]= React.useState( props.spCCOItem[0].CCUsers === "Yes" ? true : false );
  const [NextStep, setNextStep] = React.useState(props.spCCOItem[0].Status);
  const [theAttachmentFiles, settheAttachmentFiles] = React.useState<IAttachmentInfo[]>([]);

  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);

  const [SizeChange, setSizeChange] = React.useState(props.spCCOItem[0].SizeChange !==null ? props.spCCOItem[0].SizeChange : "No");
  const [ProductChange, setProductChange] = React.useState(props.spCCOItem[0].ProductChange !==null ? props.spCCOItem[0].ProductChange : "No");
  const [ScheduleChange, setScheduleChange] = React.useState(props.spCCOItem[0].ScheduleChange !==null ? props.spCCOItem[0].ScheduleChange : "No");
  const [NegativeChange, setNegativeChange] = React.useState(props.spCCOItem[0].NegativeChangeOrder !==null ? props.spCCOItem[0].NegativeChangeOrder : "No");
  const [TaskNumber, setTaskNumber] = React.useState(props.spCCOItem[0].TaskNumber);
  const [DelegationUser, setDelegationUser] = React.useState(props.spCCOItem[0].DelegationEmail !== null ? props.spCCOItem[0].DelegationEmail : "");

  const CCEmails:string = props.spCCOItem[0].CCEmails !== null ? props.spCCOItem[0].CCEmails : "";
  const CCComment:string = props.spCCOItem[0].CCComment !== null ? props.spCCOItem[0].CCComment : "";
  const CommentforPM = props.spCCOItem[0].CommentforPM !== null ? props.spCCOItem[0].CommentforPM : "";
  const PMComment = props.spCCOItem[0].PMComment !== null ? props.spCCOItem[0].PMComment : "";
  //const DelegationEmail = props.spCCOItem[0].DelegationEmail !== null ? props.spCCOItem[0].DelegationEmail : "";
  const ExecutedCOLink = props.spCCOItem[0].ExecutedCOLink !== null ? props.spCCOItem[0].ExecutedCOLink : "";

  const CurrentSize = props.spCCOItem[0].CurrentSize !== null ? props.spCCOItem[0].CurrentSize : "";
  const NewSize = props.spCCOItem[0].NewSize !== null ? props.spCCOItem[0].NewSize : "";
  const CurrentProduct = props.spCCOItem[0].CurrentProduct !== null ? props.spCCOItem[0].CurrentProduct : "";
  const NewProduct = props.spCCOItem[0].NewProduct !== null ? props.spCCOItem[0].NewProduct : "";
  const ChangeOrderNotes = props.spCCOItem[0].ChangeOrderNotes !== null ? props.spCCOItem[0].ChangeOrderNotes : "";

    
  const {register, setValue, handleSubmit, resetField, formState:{ errors } } = useForm({
    resolver: yupResolver(PMSchema)
  });

  const addFilesPromise = async (itemID: number, file: FileList, index:number ):Promise<string> =>{
    const sp = getSP();
    return await sp.web.lists.getByTitle(props.PanePropsCCOList).items.getById(itemID)
      .attachmentFiles.add(file[index].name, file[index])
      .then((res) =>{ return Promise.resolve("Done") } )
      .catch((error)=>{ return Promise.reject(error) });
  }

  /* eslint-disable  @typescript-eslint/no-explicit-any */
  const _getPeoplePickerItems = (items:any[]):void => {
    console.log("Peple:",items );
    items.map((item) => { 
      setDelegationUser(item.id);
      //setDelegationUserName(item.text);
      setValue("DelegationEmail", item.id);
    });
  }

  const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
    if(FileAttachment && FileAttachment?.length > 0){
      for(let i =0; i < FileAttachment.length; i++){
        /* eslint-disable no-useless-escape */
        const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
        if(match){
          setShowSuccess(true);
          setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
          setMessageType('danger');
          return true;
        }else{
          return false;
        }
      }
    }
    return false;
  }

  const addlistItem = () :void => {
    //PM Review DATA
    const CCEmail = document.getElementById("txtCCEmail") as HTMLInputElement;
    const CCCommet = document.getElementById("txtCommets") as HTMLInputElement;
    const Status = document.getElementById("ddnextstep") as HTMLInputElement;
    const CoordinatorComment = document.getElementById("txtCCCOmments") as HTMLInputElement;
    const PMComment = document.getElementById('txtPMComment') as HTMLInputElement;
    const ExecutedCOLink = document.getElementById("txtExecutedLink") as HTMLInputElement;


    const CurrentSize = document.getElementById("txtCurrentSize") as HTMLInputElement;
    const NewSize = document.getElementById("txtNewSize") as HTMLInputElement;
    const CurrentProduct = document.getElementById("txtCurrentProduct") as HTMLInputElement;
    const NewProduct = document.getElementById("txtNewProduct") as HTMLInputElement;
    const ChangeOrderNotes = document.getElementById("txtNegativeOrderNotes") as HTMLInputElement;

    const Attachment = document.getElementById("inputAttachment") as HTMLInputElement;
    const Attfiles = Attachment.files;

    if(filenameCharValidation(Attfiles)){ return; }

    setloadingButton("me-2"); 
    setbuttonText("Loading...");
    setdisableButton(true);

    //Approved Questions
    const ApprovedQuestions = 'Did the system size change?: ' + SizeChange + '\n' +
    'Did the product change?: ' + ProductChange + '\n' +
    'Did the schedule change?: ' + ScheduleChange + '\n' +
    'Is this a negative change order?: ' + NegativeChange + '\n';


    const sp = getSP();

    let newStage:string = "";
    let newStatus:string = "";
    switch(Status.value){
      case "Revise":  newStage = "Initiator Revision"; newStatus = "Revise"; break;
      case "Customer Approved": newStage = "PCE Review"; newStatus = "Pending"; break;
      case "Customer Rejected": newStage = "Void"; newStatus = "Void"; break;
      case "Delegate": newStage = "PM Review"; newStatus = "Delegate"; break;
      default: newStage = "PM Review"; newStatus = "Pending"; 
    }

    const itemBody = {
      Status: newStatus,
      Stage: newStage,
      CoordinatorComment: CoordinatorComment.value,
      PMComment: PMComment.value,
      ExecutedCOLink: ExecutedCOLink.value,
      DelegationEmail: DelegationUser,
      ApprovedQuestions : ApprovedQuestions,
      CCUsers: isCCGroup === true ? "Yes": "No",
      CCEmails: CCEmail.value,
      CCComment: CCCommet.value,
      SizeChange: SizeChange,
      CurrentSize: CurrentSize.value,
      NewSize: NewSize.value,
      ProductChange: ProductChange,
      CurrentProduct: CurrentProduct.value,
      NewProduct: NewProduct.value,
      ScheduleChange: ScheduleChange,
      NegativeChangeOrder: NegativeChange,
      TaskNumber: TaskNumber,
      ChangeOrderNotes: ChangeOrderNotes.value,
      VoidComment: newStage === "Void" ? PMComment.value : ""

    };
    console.log("SUBMIT BODY",itemBody);

    const theformtoreset = document.getElementById("spwr-form") as HTMLFormElement;
    console.log("Check:", Attfiles?.length);
    const list = sp.web.lists.getByTitle(props.PanePropsCCOList);
    list.items.getById(parseInt(props.spCCOItem[0].ID)).update(itemBody)
      .then(async (addResult) => {
        console.log("AddResult:", addResult);
          if(Attfiles && Attfiles?.length > 0){
            const PromoseArray = [];
            setShowSuccess(true);
            setmessage("Please wait while we upload the file Attachment.");
            setMessageType('warning');
            for(let i =0; i < Attfiles.length; i++){
              const UploadArray = await addFilesPromise( parseInt(props.spCCOItem[0].ID) ,Attfiles, i);
              PromoseArray.push(UploadArray);
            }
            Promise.all(PromoseArray)
            .then(re => { 
              setShowSuccess(true);
              setmessage("Successfully Submitted to the Next Step.");
              setMessageType('success');
              setloadingButton("visually-hidden");
              setbuttonText("SUBMIT");
              setdisableButton(false);
              theformtoreset.reset();
              resetField("DelegationEmail");
              })
            .catch(err => { 
              setShowSuccess(true);
              setmessage("Next Step is Submitted but there was a problem uploading the attachment");
              setMessageType('danger');
              setloadingButton("visually-hidden");
              setbuttonText("SUBMIT");
              setdisableButton(false);
              theformtoreset.reset();
              resetField("DelegationEmail");
              console.log( "Error Upload promise:", err); 
            });

          }else{
            setShowSuccess(true);
            setmessage("Successfully Submitted the Next Step without Attachment.");
            setMessageType('warning');
            setloadingButton("visually-hidden");
            setbuttonText("SUBMIT");
            setdisableButton(false); 
            theformtoreset.reset();
            resetField("DelegationEmail");
            //form.reset();
          }
          const WFresult = await WorkFlowSubmit(props.spCCOItem[0].ID.toString() , newStatus, newStage);
          setModalShow(true);
          console.log("WF Result:", WFresult);
          
      })
      .catch((error) => {
          console.log("Error Submit: ", error);
          setShowSuccess(true);
          setmessage("Sorry! The Next Step failed to Submit. Please try again.");
          setMessageType('danger');
          setloadingButton("visually-hidden"); 
          setbuttonText("SUBMIT");
          setdisableButton(false);
          resetField("DelegationEmail");
      });
  
    }
   
  
    let attachments: IAttachmentInfo[] = [];
    React.useEffect(() => {
      async function fecthData():Promise<void>{
        const sp = getSP();
        const item = sp.web.lists.getByTitle(props.PanePropsCCOList).items.getById(parseInt(props.spCCOItem[0].ID));
        attachments = await item.attachmentFiles().then(async res => {return await res});
        settheAttachmentFiles(attachments);
        console.log("await:",attachments);
      }
      fecthData().catch(console.error);
    },[]);

    const taskNumberLoop = ():JSX.Element[] => {
      let counter = 10;
      const optArray = [];
      while (counter <= 97) {
        const thevalue = "B."+counter;
        counter++;
        optArray.push( <option key={thevalue} value={thevalue}>{thevalue}</option> );
      }
      return optArray;
    }

    return (
      <section className={`${styles.spFxHttpClientDemo} ${props.hasTeamsContext ? styles.teams : ''}`}>
        <form noValidate id="spwr-form" onSubmit={handleSubmit(addlistItem)}>
          <Container>
            <Card>
              <Card.Header>Customer Change Order (CCO) - PM REVIEW</Card.Header>
              <Card.Body>
                <Row>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Project Number and Name</Form.Label>
                      <Form.Control type="text" id="txtRequesterName" value={props.spCCOItem[0].ProjectName} disabled/>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Instance Number</Form.Label>
                      <Form.Control type="text" id="txtInstanceNumber" value={props.spCCOItem[0].ID} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                  <Form.Group className="mb-3" >
                    <Form.Label>Requester Name</Form.Label>
                    <Form.Control type="text" id="txtRequesterName"  value={props.spCCOItem[0].RequesterName} disabled/>
                  </Form.Group>
                    
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Requester Email</Form.Label>
                      <Form.Control type="email" id="txtEmail" value={props.spCCOItem[0].RequesterEmail} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>Subject</Form.Label>
                      <Form.Control type="text" id="txtSubject" value={props.spCCOItem[0].Subject} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mt-4">
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>SunPower&lsquo;s PCO #</Form.Label>
                      <Form.Control type="text" id="txtPocNumber" value={props.spCCOItem[0].SunPowerPCONumber} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>Description of Change</Form.Label>
                      <Form.Control as="textarea" rows={3} id="txtDescription" value={props.spCCOItem[0].SunPowerPCONumber} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>CO Root Cause</Form.Label>
                      <Form.Control type="text" id="txtRootCause" value={props.spCCOItem[0].CORootCause} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>Proposed Change Order Amount</Form.Label>
                      <Form.Control type="text" id="txtOrderAmount" value={props.spCCOItem[0].ChangeOrderAmount} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>Type of Change</Card.Header>
                      <Card.Body>
                        <Form.Group className="mb-3" >
                          <Form.Control type="text" id="typeofchange" value={props.spCCOItem[0].TypeofChange} disabled/>
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <div className="mb-3">
                        <h5 className="mb-1">Expected time agreement will be finalized</h5>
                    </div>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-4">
                      <Form.Label>Year</Form.Label>
                      <Form.Control type="text" id="txtYear" value={props.spCCOItem[0].ExpectedYear} disabled/>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-4">
                      <Form.Label>Quarter</Form.Label>
                      <Form.Control type="text" id="txtQuarter" value={props.spCCOItem[0].ExpectedQuarter} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-4" >
                      <Form.Label>Target Completion Date</Form.Label>
                      <Form.Control type="text" id="TargetDate" value={props.spCCOItem[0].TargetDate } disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>Initiator Attachments</Card.Header>
                      <Card.Body>
                        <div className="d-grid gap-2">
                          {
                          theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                              return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                            })
                          }
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label >Comments from Controls Coordinator</Form.Label>
                      <Form.Control as="textarea" rows={3} id="txtCCCOmments" defaultValue={ CommentforPM } disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label >Attachments</Form.Label>
                      <Form.Control type="file" id="inputAttachment" multiple />
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>CC Users</Card.Header>
                      <Card.Body>
                      <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
        
                                <Form.Check
                                  inline
                                  label="Yes"
                                  value="true"
                                  defaultChecked={isCCGroup}
                                  onChange={ (e) => { setisCCGroup(e.currentTarget.checked === true ? true : false ) }}
                                />

       
                        <Form.Group className="mb-3" hidden={!isCCGroup}>
                          <Form.Label >Email Addresses</Form.Label>
                          <Form.Control type="text" id="txtCCEmail" defaultValue={ CCEmails }/>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={!isCCGroup}>
                          <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                          <Form.Control as="textarea" rows={3} id="txtCommets" defaultValue={ CCComment }/>
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Next step</Form.Label>
                      <Form.Select aria-label="Please Select Quarter" id="ddnextstep" defaultValue={NextStep} {...register("ddnextstep")} isInvalid={!!errors.ddnextstep } onChange={(e)=>{setNextStep(e.currentTarget.value )}} >
                        <option value="">Please Select Next Step</option>
                        <option key='ns1' value="Revise">Revise</option>
                        <option key='ns2' value="Customer Approved">Customer Approved</option>
                        <option key='ns3' value="Customer Rejected">Customer Rejected</option>
                        <option key='ns4' value="Delegate">Delegate</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.ddnextstep?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5" hidden={NextStep === "Revise" || NextStep === "Customer Rejected" ? false: true}>
                      <Form.Label className={styles.required}>Comments</Form.Label>
                      <Form.Control as="textarea" rows={3} id="txtPMComment" defaultValue={PMComment} {...register("PMComment")} isInvalid={!!errors.PMComment }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.PMComment?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                    <Form.Group className="mb-5" hidden={NextStep === "Delegate" ? false: true}>
                      <PeoplePicker
                        context={props.spContext}
                        {...register("DelegationEmail")}
                        titleText="Delegate to User"
                        personSelectionLimit={1}
                        showtooltip={true}
                        required={true}
                        onChange={ items => _getPeoplePickerItems(items) }
                        principalTypes={[PrincipalType.User]}
                        resolveDelay={1000} />
                      <p className="link-danger">{errors.DelegationEmail?.message}</p>
                    </Form.Group>
                  </Col>
                </Row>
                <Row  hidden={NextStep === "Customer Approved" ? false: true}>
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Did the system size change?</Form.Label>
                      <Form.Select aria-label="Did the system size change?" defaultValue={SizeChange} {...register("approveSizeChange")} id="approveSizeChange" onChange={(e)=>{setSizeChange(e.currentTarget.value)}} >
                        <option key="sc1" value="No">No</option>
                        <option key="sc2" value="Yes">Yes</option>
                      </Form.Select>
                    </Form.Group>
                    <Row>
                      <Col>
                        <Form.Group className="mb-5" hidden={SizeChange === "Yes" ? false: true}>
                          <Form.Label className={styles.required}>Current Size (kW)</Form.Label>
                          <Form.Control type="text" id="txtCurrentSize" defaultValue={CurrentSize} {...register("CurrentSize")} isInvalid={!!errors.CurrentSize }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CurrentSize?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        </Col>
                        <Col>
                        <Form.Group className="mb-5" hidden={SizeChange === "Yes" ? false: true}>
                          <Form.Label className={styles.required}>New Size (kW)</Form.Label>
                          <Form.Control type="text" id="txtNewSize" defaultValue={NewSize} {...register("NewSize")} isInvalid={!!errors.NewSize }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.NewSize?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Did the product change?</Form.Label>
                      <Form.Select aria-label="Did the product change?" defaultValue={ProductChange} {...register("approveProductChange")} id="approveProductChange" onChange={(e)=>{setProductChange(e.currentTarget.value)}}>
                        <option key="pc1" value="No">No</option>
                        <option key="pc2" value="Yes">Yes</option>
                      </Form.Select>
                    </Form.Group>
                    <Row>
                      <Col>
                        <Form.Group className="mb-5" hidden={ProductChange === "Yes" ? false: true}>
                          <Form.Label className={styles.required}>Current Product</Form.Label>
                          <Form.Control type="text" id="txtCurrentProduct" defaultValue={CurrentProduct} {...register("CurrentProduct")} isInvalid={!!errors.CurrentProduct }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CurrentProduct?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        </Col>
                        <Col>
                        <Form.Group className="mb-5" hidden={ProductChange === "Yes" ? false: true}>
                          <Form.Label className={styles.required}>New Product</Form.Label>
                          <Form.Control type="text" id="txtNewProduct" defaultValue={NewProduct} {...register("NewProduct")} isInvalid={!!errors.NewProduct } />
                          <Form.Control.Feedback type="invalid">
                            {errors.NewProduct?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Did the schedule change?</Form.Label>
                      <Form.Select aria-label="Did the schedule change?" id="approveScheduleChange" defaultValue={ScheduleChange} onChange={(e)=>{setScheduleChange(e.currentTarget.value)}}>
                        <option key="sch1" value="No">No</option>
                        <option key="sch2" value="Yes">Yes</option>
                      </Form.Select>
                    </Form.Group>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Is this a negative change order?</Form.Label>
                      <Form.Select aria-label="Is this a negative change order?" defaultValue={NegativeChange} {...register("approveNegativeChange")} id="approveNegativeChange" onChange={(e)=>{setNegativeChange(e.currentTarget.value)}}>
                        <option key="nc1" value="No">No</option>
                        <option key="nc2" value="Yes">Yes</option>
                      </Form.Select>
                    </Form.Group>
                    <Card style={{ width: '100%' }} hidden={NegativeChange === "Yes" ? false: true} className="mb-3">
                      <Card.Header>This will be used as reference to perform the offset of the negative amount against positive SOV line.</Card.Header>
                      <Card.Body>
                        <Row>
                          <Col>
                            <Form.Group className="mb-5">
                              <Form.Label className={styles.required}>Task Number</Form.Label>
                              <Form.Select aria-label="Please Select Quarter" defaultValue={TaskNumber} {...register("ddTaskNumber")} isInvalid={!!errors.ddTaskNumber } id="ddTaskNumber" onChange={(e)=>{setTaskNumber(e.currentTarget.value)} }>
                                <option value="">Please Select Task Number</option>
                                <option key='B.01' value="B.01">B.01</option>
                                <option key='B.02' value="B.02">B.02</option>
                                <option key='B.03' value="B.03">B.03</option>
                                <option key='B.04' value="B.04">B.04</option>
                                <option key='B.05' value="B.05">B.05</option>
                                <option key='B.06' value="B.06">B.06</option>
                                <option key='B.07' value="B.07">B.07</option>
                                <option key='B.08' value="B.08">B.08</option>
                                <option key='B.09' value="B.09">B.09</option>
                                {taskNumberLoop()}
                              </Form.Select>
                              <Form.Control.Feedback type="invalid">
                                {errors.ddTaskNumber?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                            </Col>
                            <Col>
                            <Form.Group className="mb-5" hidden={NegativeChange === "Yes" ? false: true}>
                              <Form.Label className={styles.required}>Notes</Form.Label>
                              <Form.Control type="text" id="txtNegativeOrderNotes" defaultValue={ChangeOrderNotes} {...register("NegativeOrderNotes")} isInvalid={!!errors.NegativeOrderNotes }/>
                              <Form.Text muted>Identify which milestone/work it is related to.</Form.Text>
                              <Form.Control.Feedback type="invalid">
                                {errors.NegativeOrderNotes?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                        </Row>
                      </Card.Body>
                    </Card>
                   
                    <Form.Group className="mb-3" >
                        <Form.Label className={styles.required} >Executed CO Link</Form.Label>
                        <Form.Control type="text" id="txtExecutedLink" defaultValue={ExecutedCOLink} {...register("ExecutedLink")} isInvalid={!!errors.ExecutedLink }/>
                        <Form.Control.Feedback type="invalid">
                          {errors.ExecutedLink?.message}
                        </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-3">
                  <Col>
                    <div className="d-grid gap-2">
                      <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ disableButton }>
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden="true"
                        className={ loadingButton }
                      />
                      { buttonText }
                      </Button>
                    </div>
                  </Col>
                </Row>
                { ShowSuccess && (
                    <Alert
                      key={ MessageType } 
                      variant={ MessageType } 
                      dismissible 
                      onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                        { message }
                    </Alert>
                )}
              </Card.Body>
            </Card>
          </Container>
        </form>
        <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
          <Modal.Header>
            <Modal.Title>SharePoint</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Alert variant="primary">
              <Alert.Heading>{ message }</Alert.Heading>
              <p hidden={MessageType === "danger" ? true : false}>
                Thank you! You can now close this tab or window.
              </p>
            </Alert>
          </Modal.Body>
          <Modal.Footer hidden={MessageType === "danger" ? false : true}>
            <Button variant="secondary" onClick={handleClose}>
              Continue
            </Button>
          </Modal.Footer>
        </Modal>  
      </section>
    );

}