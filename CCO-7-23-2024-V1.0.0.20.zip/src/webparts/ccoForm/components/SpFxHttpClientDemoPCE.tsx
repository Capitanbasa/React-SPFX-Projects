import * as React  from 'react';
import  styles from './SpFxHttpClientDemo.module.scss';
import type { ISpFxHttpClientDemoWebPartProps } from './ISpFxHttpClientDemoProps';
import { Container, Row, Col, Form, Button, Alert, Spinner, Card, Modal } from 'react-bootstrap';
import { getSP } from '../pnpjsConfig';
import "@pnp/sp/webs";
import "@pnp/sp/lists/web";
import "@pnp/sp/items";
import "@pnp/sp/attachments";
import { IAttachmentInfo } from '@pnp/sp/attachments';
import { IoDocumentAttachOutline } from "react-icons/io5";
import { DatePicker } from "antd";

import { PCESchema } from '../Validations/PCEValidation';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup'
import { PeoplePicker, PrincipalType } from '@pnp/spfx-controls-react/lib/PeoplePicker';
import WorkFlowSubmit from '../utilities/WorkFlowSubmit';
//import { DevTool } from '@hookform/devtools';

export function SpFxHttpClientDemoPCE(props:ISpFxHttpClientDemoWebPartProps):React.ReactElement {

  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [loadingButton, setloadingButton] = React.useState( "visually-hidden" );
  const [buttonText, setbuttonText] = React.useState( "SUBMIT" );
  const [disableButton, setdisableButton]= React.useState( false );
  const [isCCGroup, setisCCGroup]= React.useState( props.spCCOItem[0].CCUsers === "Yes" ? true : false );
  const [NextStep, setNextStep] = React.useState("");
  const [theAttachmentFiles, settheAttachmentFiles] = React.useState<IAttachmentInfo[]>([]);

  const [SizeChange, setSizeChange] = React.useState(props.spCCOItem[0].SizeChange);
  const [ProductChange, setProductChange] = React.useState(props.spCCOItem[0].ProductChange);
  const [ScheduleChange, setScheduleChange] = React.useState(props.spCCOItem[0].ScheduleChange);
  const [NegativeChange, setNegativeChange] = React.useState(props.spCCOItem[0].NegativeChangeOrder);
  const [DelegationUser, setDelegationUser] = React.useState(props.spCCOItem[0].DelegationEmail !== null ? props.spCCOItem[0].DelegationEmail : "");
  //const [TaskNumber, setTaskNumber] = React.useState("");
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);

  const [OracleDate, setOracleDate]= React.useState( "" );

  const DTFormat = (d:string): string => {
    const newdate = new Date(d);
    return newdate.toLocaleDateString('default', { month: 'short', day: 'numeric', year: 'numeric'});
  }

  const form = useForm({
    resolver: yupResolver(PCESchema)
  });
  const addFilesPromise = async (itemID: number, file: FileList, index:number ):Promise<string> =>{
    const sp = getSP();
    return await sp.web.lists.getByTitle(props.PanePropsCCOList).items.getById(itemID)
      .attachmentFiles.add(file[index].name, file[index])
      .then((res) =>{ return Promise.resolve("Done") } )
      .catch((error)=>{ return Promise.reject(error) });
  }


  //setisCCGroup( props.spCCOItem[0].CCUsers === "Yes" ? true:false );
  // const CCUsers:boolean = props.spCCOItem[0].CCUsers ==="Yes" ? true : false;
  const CCEmails:string = props.spCCOItem[0].CCEmails !== null ? props.spCCOItem[0].CCEmails : "";
  const CCComment:string = props.spCCOItem[0].CCComment !== null ? props.spCCOItem[0].CCComment : "";

  //const DelegationEmail = props.spCCOItem[0].DelegationEmail !== null ? props.spCCOItem[0].DelegationEmail : "";
  const CurrentTaskNumber = props.spCCOItem[0].TaskNumber !== null ? props.spCCOItem[0].TaskNumber : "";
  const currentChangeOrderNotes = props.spCCOItem[0].ChangeOrderNotes !== null ? props.spCCOItem[0].ChangeOrderNotes : "";
  const CurrentSize = props.spCCOItem[0].CurrentSize !== null ? props.spCCOItem[0].CurrentSize : "";
  const NewSize = props.spCCOItem[0].NewSize !== null ? props.spCCOItem[0].NewSize : "";
  const CurrentProduct = props.spCCOItem[0].CurrentProduct !== null ? props.spCCOItem[0].CurrentProduct : "";
  const NewProduct = props.spCCOItem[0].NewProduct !== null ? props.spCCOItem[0].NewProduct : "";
  const NegativeChangeOrder = props.spCCOItem[0].NegativeChangeOrder !== null ? props.spCCOItem[0].NegativeChangeOrder : "";
  const ExecutedCOLink = props.spCCOItem[0].ExecutedCOLink !== null ? props.spCCOItem[0].ExecutedCOLink : "";

  const {register, handleSubmit, setValue, resetField , formState } = form;
  const { errors } = formState;

  /* eslint-disable  @typescript-eslint/no-explicit-any */
  const _getPeoplePickerItems = (items:any[]):void => {
    console.log("Peple:",items );
    items.map((item) => { 
      setDelegationUser(item.id);
      //setDelegationUserName(item.text);
      setValue("DelegationEmail", item.id);
    });
  }

  const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
    if(FileAttachment && FileAttachment?.length > 0){
      for(let i =0; i < FileAttachment.length; i++){
        /* eslint-disable no-useless-escape */
        const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
        if(match){
          setShowSuccess(true);
          setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
          setMessageType('danger');
          return true;
        }else{
          return false;
        }
      }
    }
    return false;
  }

  const addlistItem = () :void => {
    //PM Review DATA
    const CCEmail = document.getElementById("txtCCEmail") as HTMLInputElement;
    const CCCommet = document.getElementById("txtCommets") as HTMLInputElement;
    const Status = document.getElementById("ddnextstep") as HTMLInputElement;
    //const DelegationEmail = document.getElementById("txtdelagationEmail") as HTMLInputElement;
    const OracleTaskNumber = document.getElementById("txtOracleTaskNumber") as HTMLInputElement;
    const CommentForPM = document.getElementById("txtCommentForPM") as HTMLInputElement;
    const FinalCOAmount = document.getElementById("txtFinalCOAmount") as HTMLInputElement;
    const Attachment = document.getElementById("inputAttachment") as HTMLInputElement;
    const Attfiles = Attachment.files;
    if(filenameCharValidation(Attfiles)){ return; }

    setloadingButton("me-2"); 
    setbuttonText("Loading...");
    setdisableButton(true);

    let itemBody = {};
    let newStage:string = "Void";
    let newStatus:string = "Void";
    if(Status.value === "Return to PM"){
      newStage = "PM Review";
      newStatus = "Pending";
      itemBody = {
        Status: "Pending",
        Stage: "PM Review",
        flag: "1",
        CCUsers: isCCGroup === true ? "Yes": "No",
        CCEmails: CCEmail.value,
        CCComment: CCCommet.value,
        CommentforPM: CommentForPM.value
      };
    }else if(Status.value ==="Oracle Updated"){
      newStage = "PCE Review";
      newStatus = "Oracle Updated";
      itemBody = {
        Stage: newStage,
        Status: newStatus,
        CCUsers: isCCGroup === true ? "Yes": "No",
        CCEmails: CCEmail.value,
        CCComment: CCCommet.value,
        OracleDate:OracleDate,
        OracleTaskNumber: OracleTaskNumber.value,
        FinalCOAmount: FinalCOAmount.value
      };
      
    }else{
      newStage = "PCE Review";
      newStatus = "Delegate";
      itemBody = {
        Stage: newStage,
        Status: newStatus,
        DelegationEmail: DelegationUser,
        CCUsers: isCCGroup === true ? "Yes": "No",
        CCEmails: CCEmail.value,
        CCComment: CCCommet.value,
      };
      
    }
    console.log("SUBMIT Data:",itemBody);

    const sp = getSP();
    const theformtoreset = document.getElementById("spwr-form") as HTMLFormElement;
    console.log("Check:", Attfiles?.length);    const list = sp.web.lists.getByTitle(props.PanePropsCCOList);
    list.items.getById(parseInt(props.spCCOItem[0].ID)).update(itemBody)
      .then(async (addResult) => {
         console.log("SUBMIT Update:", addResult);
          if(Attfiles && Attfiles?.length > 0){
            const PromoseArray = [];
            setShowSuccess(true);
            setmessage("Please wait while we upload the file Attachment.");
            setMessageType('warning');
            for(let i =0; i < Attfiles.length; i++){
              const UploadArray = await addFilesPromise( parseInt(props.spCCOItem[0].ID) ,Attfiles, i);
              PromoseArray.push(UploadArray);
            }
            Promise.all(PromoseArray)
            .then(re => { 
              setShowSuccess(true);
              setmessage("Successfully Submitted to the Next Step.");
              setMessageType('success');
              setloadingButton("visually-hidden");
              setbuttonText("SUBMIT");
              setdisableButton(false);
              theformtoreset.reset();
              form.reset();
              resetField("DelegationEmail");
              })
            .catch(err => { 
              setShowSuccess(true);
              setmessage("Next Step is Submitted but there was a problem uploading the attachment");
              setMessageType('danger');
              setloadingButton("visually-hidden");
              setbuttonText("SUBMIT");
              setdisableButton(false);
              theformtoreset.reset();
              form.reset()
              resetField("DelegationEmail");
              console.log( "Error:", err); 
            });
          }else{
            setShowSuccess(true);
            setmessage("Successfully Submitted the Next Step without Attachment.");
            setMessageType('warning');
            setloadingButton("visually-hidden");
            setbuttonText("SUBMIT");
            setdisableButton(false); 
            theformtoreset.reset();
            form.reset();
            resetField("DelegationEmail");
          }
          const WFresult = await WorkFlowSubmit(props.spCCOItem[0].ID.toString() , newStatus, newStage, "2");
          setModalShow(true);
          console.log("WF Result:", WFresult);
          
      })
      .catch((error) => {
          console.log("Error: ", error);
          setShowSuccess(true);
          setmessage("Sorry! The Next Step failed to Submit. Please try again.");
          setMessageType('danger');
          setloadingButton("visually-hidden"); 
          setbuttonText("SUBMIT");
          setdisableButton(false);
          resetField("DelegationEmail");
      });
  
    }

    

   
    // 
    let attachments: IAttachmentInfo[] = [];
    React.useEffect(() => {
      async function fecthData():Promise<void>{
        const sp = getSP();
        const item = sp.web.lists.getByTitle(props.PanePropsCCOList).items.getById(parseInt(props.spCCOItem[0].ID));
        attachments = await item.attachmentFiles().then(async res => {return await res});
        settheAttachmentFiles(attachments);
        console.log("await:",attachments);
      }
      fecthData().catch(console.error);
    },[]);

    const taskNumberLoop = ():JSX.Element[] => {
      let counter = 10;
      const optArray = [];
      while (counter <= 97) {
        const thevalue = "B."+counter;
        counter++;
        optArray.push( <option key={thevalue} value={thevalue}>{thevalue}</option> );
        
      }
      return optArray;
    }

    return (
      <section className={`${styles.spFxHttpClientDemo} ${props.hasTeamsContext ? styles.teams : ''}`}>
        <form noValidate id="spwr-form" onSubmit={handleSubmit(addlistItem)}>
          <Container>
            <Card>
              <Card.Header>Customer Change Order (CCO) - PCE REVIEW</Card.Header>
              <Card.Body>
                <Row>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Project Number and Name</Form.Label>
                      <Form.Control type="text" id="txtRequesterName" value={props.spCCOItem[0].ProjectName} disabled/>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Instance Number</Form.Label>
                      <Form.Control type="text" id="txtInstanceNumber" value={props.spCCOItem[0].ID} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                  <Form.Group className="mb-3" >
                    <Form.Label>Requester Name</Form.Label>
                    <Form.Control type="text" id="txtRequesterName"  value={props.spCCOItem[0].RequesterName} disabled/>
                  </Form.Group>
                    
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Requester Email</Form.Label>
                      <Form.Control type="email" id="txtEmail" value={props.spCCOItem[0].RequesterEmail} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>Subject</Form.Label>
                      <Form.Control type="text" id="txtSubject" value={props.spCCOItem[0].Subject} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mt-4">
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>SunPower&lsquo;s PCO #</Form.Label>
                      <Form.Control type="text" id="txtPocNumber" value={props.spCCOItem[0].SunPowerPCONumber} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>Description of Change</Form.Label>
                      <Form.Control as="textarea" rows={3} id="txtDescription" value={props.spCCOItem[0].SunPowerPCONumber} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>CO Root Cause</Form.Label>
                      <Form.Control type="text" id="txtRootCause" value={props.spCCOItem[0].CORootCause} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>Proposed Change Order Amount</Form.Label>
                      <Form.Control type="text" id="txtOrderAmount" value={props.spCCOItem[0].ChangeOrderAmount} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>Type of Change</Card.Header>
                      <Card.Body>
                        <Form.Group className="mb-3" >
                          <Form.Control type="text" id="typeofchange" value={props.spCCOItem[0].TypeofChange} disabled/>
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <div className="mb-3">
                        <h5 className="mb-1">Expected time agreement will be finalized</h5>
                    </div>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-4">
                      <Form.Label>Year</Form.Label>
                      <Form.Control type="text" id="txtYear" value={props.spCCOItem[0].ExpectedYear} disabled/>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-4">
                      <Form.Label>Quarter</Form.Label>
                      <Form.Control type="text" id="txtQuarter" value={props.spCCOItem[0].ExpectedQuarter} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-4" >
                      <Form.Label>Target Completion Date</Form.Label>
                      <Form.Control type="text" id="TargetDate" value={props.spCCOItem[0].TargetDate} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>Initiator Attachments</Card.Header>
                      <Card.Body>
                        <div className="d-grid gap-2">
                          {
                          theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                              return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                            })
                          }
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                        <Form.Label >Executed CO Link</Form.Label>
                        <Button variant="link" href={ExecutedCOLink}>{ExecutedCOLink}</Button>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label >Attachments</Form.Label>
                      <Form.Control type="file" id="inputAttachment" multiple />
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>CO Approved</Card.Header>
                      <Card.Body>
                        <Form.Group className="mb-3" >
                          <Form.Check
                                  inline
                                  label="Yes"
                                  value="true"
                                  defaultChecked={true}
                                />
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>CC Users</Card.Header>
                      <Card.Body>
                      <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                        <Form.Check
                          inline
                          label="Yes"
                          value="true"
                          defaultChecked={isCCGroup}
                          {...register("ccUsers", { onChange : (e) => { setisCCGroup(e.currentTarget.checked === true ? true : false ) }})}
                          isInvalid={!!errors.ccUsers }
                        />
                        <p className="link-danger">{errors.ccUsers?.message}</p>
                        <Form.Group className="mb-3" hidden={!isCCGroup}>
                          <Form.Label >Email Addresses</Form.Label>
                          <Form.Control type="text" id="txtCCEmail" defaultValue={ CCEmails } {...register("CCEmail")} isInvalid={!!errors.CCEmail }/>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={!isCCGroup}>
                          <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                          <Form.Control as="textarea" rows={3} id="txtCommets" defaultValue={ CCComment }/>
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                
                <Row >
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Did the system size change?</Form.Label>
                      <Form.Select aria-label="Did the system size change?" id="approveSizeChange" onChange={(e)=>{setSizeChange(e.currentTarget.value)}} disabled>
                        <option key="sc1" value="No">No</option>
                        <option key="sc2" value="Yes">Yes</option>
                      </Form.Select>
                    </Form.Group>
                    <Row>
                      <Col>
                        <Form.Group className="mb-5" hidden={SizeChange === "Yes" ? false: true}>
                          <Form.Label className={styles.required}>Current Size (kW)</Form.Label>
                          <Form.Control type="text" id="txtCurrentSize" defaultValue={CurrentSize} disabled/>
                        </Form.Group>
                        </Col>
                        <Col>
                        <Form.Group className="mb-5" hidden={SizeChange === "Yes" ? false: true}>
                          <Form.Label className={styles.required}>New Size (kW)</Form.Label>
                          <Form.Control type="text" id="txtNewSize" defaultValue={NewSize} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Did the product change?</Form.Label>
                      <Form.Select aria-label="Did the product change?" id="approveProductChange" defaultValue={ProductChange} onChange={(e)=>{setProductChange(e.currentTarget.value)}} disabled>
                        <option key="pc1" value="No">No</option>
                        <option key="pc2" value="Yes">Yes</option>
                      </Form.Select>
                    </Form.Group>
                    <Row>
                      <Col>
                        <Form.Group className="mb-5" hidden={ProductChange === "Yes" ? false: true}>
                          <Form.Label className={styles.required}>Current Product</Form.Label>
                          <Form.Control type="text" id="txtCurrentProduct" defaultValue={CurrentProduct} disabled/>
                        </Form.Group>
                        </Col>
                        <Col>
                        <Form.Group className="mb-5" hidden={ProductChange === "Yes" ? false: true}>
                          <Form.Label className={styles.required}>New Product</Form.Label>
                          <Form.Control type="text" id="txtNewProduct" defaultValue={NewProduct} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Did the schedule change?</Form.Label>
                      <Form.Select aria-label="Did the schedule change?" id="approveScheduleChange" defaultValue={ScheduleChange} onChange={(e)=>{setScheduleChange(e.currentTarget.value)}} disabled>
                        <option key="sch1" value="No">No</option>
                        <option key="sch2" value="Yes">Yes</option>
                      </Form.Select>
                    </Form.Group>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Is this a negative change order?</Form.Label>
                      <Form.Select aria-label="Is this a negative change order?" id="approveNegativeChange" defaultValue={NegativeChangeOrder} onChange={(e)=>{setNegativeChange(e.currentTarget.value)}} disabled>
                        <option key="nc1" value="No">No</option>
                        <option key="nc2" value="Yes">Yes</option>
                      </Form.Select>
                    </Form.Group>
                    <Card style={{ width: '100%' }} hidden={NegativeChange === "Yes" ? false: true} className="mb-3">
                      <Card.Header>This will be used as reference to perform the offset of the negative amount against positive SOV line.</Card.Header>
                      <Card.Body>
                        <Row>
                          <Col>
                            <Form.Group className="mb-5">
                              <Form.Label className={styles.required}>Task Number</Form.Label>
                              <Form.Select aria-label="Please Select Quarter" id="ddTaskNumber" defaultValue={CurrentTaskNumber} disabled>
                                <option value="">Please Select Task Number</option>
                                <option key='B.01' value="B.01">B.01</option>
                                <option key='B.02' value="B.02">B.02</option>
                                <option key='B.03' value="B.03">B.03</option>
                                <option key='B.04' value="B.04">B.04</option>
                                <option key='B.05' value="B.05">B.05</option>
                                <option key='B.06' value="B.06">B.06</option>
                                <option key='B.07' value="B.07">B.07</option>
                                <option key='B.08' value="B.08">B.08</option>
                                <option key='B.09' value="B.09">B.09</option>
                                {taskNumberLoop()}
                              </Form.Select>
                            </Form.Group>
                            </Col>
                            <Col>
                            <Form.Group className="mb-5" hidden={NegativeChange === "Yes" ? false: true}>
                              <Form.Label className={styles.required}>Notes</Form.Label>
                              <Form.Control type="text" id="txtNegativeOrderNotes" defaultValue={currentChangeOrderNotes} disabled/>
                              <Form.Text muted>Identify which milestone/work it is related to.</Form.Text>
                            </Form.Group>
                          </Col>
                        </Row>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Next step</Form.Label>
                      <Form.Select aria-label="Please Select Quarter" id="ddnextstep" {...register("ddnextstep")} isInvalid={!!errors.ddnextstep } onChange={ (e) => { setNextStep(e.currentTarget.value ) }}>
                        <option value="">Please Select Next Step</option>
                        <option key='ns1' value="Return to PM">Return to PM</option>
                        <option key='ns2' value="Oracle Updated">Oracle Updated</option>
                        <option key='ns3' value="Delegate">Delegate</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.ddnextstep?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5" hidden={NextStep === "Return to PM" ? false: true}>
                      <Form.Label className={styles.required}>Comment for PM</Form.Label>
                      <Form.Control as="textarea" rows={3} id="txtCommentForPM" {...register("CommentforPM")} isInvalid={!!errors.CommentforPM }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.CommentforPM?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                    <Form.Group className="mb-5" hidden={NextStep === "Delegate" ? false: true}>
                      <PeoplePicker
                        context={props.spContext}
                        {...register("DelegationEmail")}
                        titleText="Delegate to User"
                        personSelectionLimit={1}
                        showtooltip={true}
                        required={true}
                        onChange={ items => _getPeoplePickerItems(items) }
                        principalTypes={[PrincipalType.User]}
                        resolveDelay={1000} />
                      <p className="link-danger">{errors.DelegationEmail?.message}</p>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Card style={{ width: '100%' }} hidden={NextStep === "Oracle Updated" ? false: true} className="mb-3">
                      <Card.Body>
                        <Row>
                          <Col>
                            <Form.Group className="mb-5">
                              <Form.Label className={styles.required}>Date Oracle Updated</Form.Label>
                              <DatePicker 
                                className='form-control' 
                                {...register("OracleDate")} 
                                onChange={(e): void => {  if(e){ form.setValue("OracleDate", e.toString(),  { shouldValidate: true }); setOracleDate(  DTFormat(e.format("YYYY-MM-DD")) ); } }}/>
                              <Form.Control.Feedback type="invalid">
                                {errors.OracleDate?.message} 
                              </Form.Control.Feedback>
                              <p className="link-danger">{errors.OracleDate?.message}</p>
                            </Form.Group>
                            </Col>
                            <Col>
                            <Form.Group className="mb-5" >
                              <Form.Label className={styles.required}>Task Number</Form.Label>
                              <Form.Control type="text" id="txtOracleTaskNumber" {...register("OracleTaskNumber")} isInvalid={!!errors.OracleTaskNumber } />
                              <Form.Control.Feedback type="invalid">
                                {errors.OracleTaskNumber?.message} 
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                        </Row>
                        <Form.Group className="mb-5">
                          <Form.Label className={styles.required}>Final CO Amount</Form.Label>
                          <Form.Control type="text" id="txtFinalCOAmount"  {...register("FinalCOAmount")} isInvalid={!!errors.FinalCOAmount } />
                          <Form.Control.Feedback type="invalid">
                            {errors.FinalCOAmount?.message} 
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row className="mb-3">
                  <Col>
                    <div className="d-grid gap-2">
                      <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ disableButton }>
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden="true"
                        className={ loadingButton }
                      />
                      { buttonText }
                      </Button>
                    </div>
                  </Col>
                </Row>
                { ShowSuccess && (
                    <Alert
                      key={ MessageType } 
                      variant={ MessageType } 
                      dismissible 
                      onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                        { message }
                    </Alert>
                )}
              </Card.Body>
            </Card>
          </Container>
        </form>
        <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
          <Modal.Header>
            <Modal.Title>SharePoint</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Alert variant="primary">
              <Alert.Heading>{ message }</Alert.Heading>
              <p hidden={MessageType === "danger" ? true : false}>
                Thank you! You can now close this tab or window.
              </p>
            </Alert>
          </Modal.Body>
          <Modal.Footer hidden={MessageType === "danger" ? false : true}>
            <Button variant="secondary" onClick={handleClose}>
              Continue
            </Button>
          </Modal.Footer>
        </Modal>  
      </section>
    );

}