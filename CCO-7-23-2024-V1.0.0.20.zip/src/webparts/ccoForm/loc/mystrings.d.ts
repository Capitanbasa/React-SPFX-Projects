declare interface ICcoFormWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  PanePropsCCOList: string;
  AppLocalEnvironmentSharePoint: string;
  AppLocalEnvironmentTeams: string;
  AppLocalEnvironmentOffice: string;
  AppLocalEnvironmentOutlook: string;
  AppSharePointEnvironment: string;
  AppTeamsTabEnvironment: string;
  AppOfficeEnvironment: string;
  AppOutlookEnvironment: string;
  UnknownEnvironment: string;
  PanePropsProjectNumberName: string;
  PanePropsRootCause:string;
  PanePropsTypeChange:string;
  PanePropsExpectedYear:string;
}

declare module 'CcoFormWebPartStrings' {
  const strings: ICcoFormWebPartStrings;
  export = strings;
}
