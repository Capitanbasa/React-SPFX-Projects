import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  type IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';

import * as strings from 'CcoFormWebPartStrings';

import { ICCOListItem, ICcoFormProps, IExpectedYearListItem, IProjectListItem, IRootCauseListItem, ITypeChangeListItem } from './components/ICcoFormProps';
import { SPHttpClient } from '@microsoft/sp-http';
import { escape, isEmpty } from '@microsoft/sp-lodash-subset';
import { getSP } from './pnpjsConfig';

import { CcoForm } from './components/CcoForm';
import { SpFxHttpClientDemoPM } from './components/SpFxHttpClientDemoPM';
import { SpFxHttpClientDemoIR } from './components/SpFxHttpClientDemoIR';
import { SpFxHttpClientDemoPCE } from './components/SpFxHttpClientDemoPCE';


import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/site-users/web";
import 'bootstrap/dist/css/bootstrap.min.css';
import { NoAccess } from './components/NoAccess';


export default class CcoFormWebPart extends BaseClientSideWebPart<ICcoFormProps> {

  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = '';
  private _projects:  IProjectListItem[];
  private _rootcauses:  IRootCauseListItem[];
  private _typechange:  ITypeChangeListItem[];
  private _expectedyear: IExpectedYearListItem[];
  private _CCOItem: ICCOListItem[];
  private _currentUserVerified: boolean = false;
  public render(): void {
    //console.log("RENdER");
    let ccoStageComponent = CcoForm;
 

      if(this._CCOItem && this._CCOItem.length > 0){
        if(this._currentUserVerified){
          switch (this._CCOItem[0].Stage) {
            case 'PM Review':
              ccoStageComponent = SpFxHttpClientDemoPM; break;
            case 'Initiator Revision':
              ccoStageComponent = SpFxHttpClientDemoIR; break;
            case 'PCE Review':
              ccoStageComponent = SpFxHttpClientDemoPCE; break;
            default:
              ccoStageComponent = CcoForm;
          }
        }else{
          ccoStageComponent = NoAccess;
        }
      }else{
        ccoStageComponent = CcoForm;
      }


      const element: React.ReactElement<ICcoFormProps> = React.createElement(
        ccoStageComponent, {
          description: this.properties.description,
          PanePropsCCOList: this.properties.PanePropsCCOList,
          PanePropsProjectNumberName: this.properties.PanePropsProjectNumberName,
          PanePropsRootCause: this.properties.PanePropsRootCause,
          PanePropsTypeChange: this.properties.PanePropsTypeChange,
          PanePropsExpectedYear: this.properties.PanePropsExpectedYear,
          isDarkTheme: this._isDarkTheme,
          environmentMessage: this._environmentMessage,
          hasTeamsContext: !this.context.sdks.microsoftTeams,
          userDisplayName: this.context.pageContext.user.displayName,
          userEmail: this.context.pageContext.user.email,
          spProjectListItems: this._projects,
          spRootCausetListItems: this._rootcauses,
          spTypeChangetListItems: this._typechange,
          spExpectedYearListItems: this._expectedyear,
          spCCOItem: this._CCOItem,
          spContext:  this.context
        }
      );
      ReactDom.render(element, this.domElement);

  }

  private _onGetProjectListItems = async (): Promise<void> => {
    const response: IProjectListItem[] = await this._getProjectListItems();
    const resRoot: IRootCauseListItem[] = await this._getRootCause();
    const resType: IRootCauseListItem[] = await this._getTypeChange();
    const resYear: IExpectedYearListItem[] = await this._getExpectedYear();
    const ccoItem: ICCOListItem[] = await this._getCurrentCCOItem();
    //console.log("CCO ITEM:", ccoItem);
    const CurrentUserVerify:boolean = await this._verfiyuser(ccoItem.length > 0 ? ccoItem[0].AssignedToId: 0);
    
    this._projects = response;
    this._rootcauses = resRoot;
    this._typechange = resType;
    this._expectedyear = resYear;
    this._CCOItem = ccoItem;
    this._currentUserVerified = CurrentUserVerify;
  }
  private async _verfiyuser(assignedtoId:number): Promise<boolean> {
    const sp = getSP(this.context);

    if(assignedtoId !== 0 && assignedtoId){
      const user = await sp.web.currentUser();
      console.log("current User:", user);
      const assignedtoUserID = await sp.web.getUserById(assignedtoId)();
      console.log("Assigned User:", assignedtoUserID);
      if(user.UserId.NameId === assignedtoUserID.UserId.NameId){
        return true;
      }else{
        return false;
      }
    }else{
      return false;
    }
  }
  
  private async _getCurrentCCOItem(): Promise<ICCOListItem[]> {
    const params = new URLSearchParams(window.location.search);
    const CCO_ID:string = params.get('ReqID') as string ;
    //console.log(CCO_ID);
    //console.log(!isEmpty(CCO_ID));

    if(!isEmpty(CCO_ID)){
      const response = await this.context.spHttpClient.get(
        this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${escape(this.properties.PanePropsCCOList)}')/items?$filter= ID eq ${escape(CCO_ID)}`,
        SPHttpClient.configurations.v1);
      if (!response.ok) {
        const responseText = await response.text();
        throw new Error(responseText);
      }
      
      const responseJson = await response.json();
      console.log(responseJson);
      return responseJson.value as ICCOListItem[];
    }else{
      const responseJson: ICCOListItem[]= [];
      return  responseJson;
    }
  
    
  }
  private async _getProjectListItems(): Promise<IProjectListItem[]> {

    // const response = await this.context.spHttpClient.get(
    //   this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${escape(this.properties.PanePropsProjectNumberName)}')/items?$select=Id,ProjectName&$filter=Transaction eq 'CCO' and ProjectType eq 'Prod'`,
    //   SPHttpClient.configurations.v1);
    // if (!response.ok) {
    //   const responseText = await response.text();
    //   throw new Error(responseText);
    // }
    
    // const responseJson = await response.json();
  
    // return responseJson.value as IProjectListItem[];

    const sp = getSP(this.context);
    const countLastIDList = await sp.web.lists.getByTitle(this.properties.PanePropsProjectNumberName).items.select("ID").orderBy("ID", false).top(1)();
    const TopLastID = countLastIDList.length > 0 ? countLastIDList[0].ID : 0;
    const vendorsretult = await sp.web.lists.getByTitle(this.properties.PanePropsProjectNumberName).items.select("ProjectName", "Id", "ProjectType").top(TopLastID).filter("Transaction eq 'CCO' and ProjectType eq 'Prod'")();
    console.log(vendorsretult);
    return vendorsretult;
  }

  private async _getRootCause(): Promise<IRootCauseListItem[]> {

    const response = await this.context.spHttpClient.get(
      this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${escape(this.properties.PanePropsTypeChange)}')/items?$select=Id,Title`,
      SPHttpClient.configurations.v1);
    if (!response.ok) {
      const responseText = await response.text();
      throw new Error(responseText);
    }
    
    const responseJson = await response.json();
  
    return responseJson.value as IRootCauseListItem[];
  }

  private async _getTypeChange(): Promise<ITypeChangeListItem[]> {

    const response = await this.context.spHttpClient.get(
      this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${escape(this.properties.PanePropsRootCause)}')/items?$select=Id,Title`,
      SPHttpClient.configurations.v1);
    if (!response.ok) {
      const responseText = await response.text();
      throw new Error(responseText);
    }
    
    const responseJson = await response.json();
  
    return responseJson.value as ITypeChangeListItem[];
  }

  private async _getExpectedYear(): Promise<IExpectedYearListItem[]> {

    const response = await this.context.spHttpClient.get(
      this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${escape(this.properties.PanePropsExpectedYear)}')/items?$select=Id,Year`,
      SPHttpClient.configurations.v1);
    if (!response.ok) {
      const responseText = await response.text();
      throw new Error(responseText);
    }
    
    const responseJson = await response.json();
  
    return responseJson.value as IExpectedYearListItem[];
  }

  protected async onInit(): Promise<void> {
    await this._onGetProjectListItems();
    return this._getEnvironmentMessage().then(message => {
      this._environmentMessage = message;
    });
  }



  private _getEnvironmentMessage(): Promise<string> {
    if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
      return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
        .then(context => {
          let environmentMessage: string = '';
          switch (context.app.host.name) {
            case 'Office': // running in Office
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOffice : strings.AppOfficeEnvironment;
              break;
            case 'Outlook': // running in Outlook
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOutlook : strings.AppOutlookEnvironment;
              break;
            case 'Teams': // running in Teams
            case 'TeamsModern':
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentTeams : strings.AppTeamsTabEnvironment;
              break;
            default:
              environmentMessage = strings.UnknownEnvironment;
          }

          return environmentMessage;
        });
    }

    return Promise.resolve(this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentSharePoint : strings.AppSharePointEnvironment);
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }

    this._isDarkTheme = !!currentTheme.isInverted;
    const {
      semanticColors
    } = currentTheme;

    if (semanticColors) {
      this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
      this.domElement.style.setProperty('--link', semanticColors.link || null);
      this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
    }

  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('PanePropsCCOList', {
                  label: strings.PanePropsCCOList,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
                PropertyPaneTextField('PanePropsProjectNumberName', {
                  label: strings.PanePropsProjectNumberName,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
                PropertyPaneTextField('PanePropsRootCause', {
                  label: strings.PanePropsRootCause,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
                PropertyPaneTextField('PanePropsTypeChange', {
                  label: strings.PanePropsTypeChange,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
                PropertyPaneTextField('PanePropsExpectedYear', {
                  label: strings.PanePropsExpectedYear,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                })
              ]
            }
          ]
        }
      ]
    };
  }

  protected get disableReactivePropertyChanges(): boolean {
    return true;
  }

  private async validatePaneProps(value: string): Promise<string> {
    if (value === null || value.length === 0) {
      return "Provide the list name";
    }
    try{
      const response = await this.context.spHttpClient.get(
      this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${escape(value)}')/items?$select=Id`,
      SPHttpClient.configurations.v1);
      if (response.ok) {
        return "";
      } else if (response.status === 404) {
        return `List '${escape(value)}' doesn't exist in the current site`;
      }else{
        return `Error: ${response.statusText}. Please try again`;
      }
    }catch(error){
      return error.message;
    }
  }
}
