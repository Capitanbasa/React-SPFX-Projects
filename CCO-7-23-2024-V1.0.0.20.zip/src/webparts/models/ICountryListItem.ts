export interface ICountryListItem {
    RequesterEmail: string;
    RequesterName: string;
    Id: string;
    Title: string;
    ProjectName: string;
  }