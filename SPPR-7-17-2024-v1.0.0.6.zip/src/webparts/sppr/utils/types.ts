import * as yup from 'yup';

export const spprFormSchema = yup.object().shape({
    ProjectType: yup.string().required("Project Type is Required"),
    Stage: yup.string().default("Procurement Plannning").notRequired(),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),
    ProjectName: yup.string().required("Project Number - Project Name is required"),
    RequesterName: yup.string().required("Requester Name is required"),
    RequesterEmail: yup.string().required().email("Requester Email is required"),
    Subject: yup.string().required("Subject is required"),

    RequiredbyDate: yup.string().required("Required by Date is required"),
    ProposedVendor: yup.string().required("Vendor Range is required"),
    Vendor: yup.string().required("Vendor is required"),
    PPRType: yup.string().required("PPR Type is required"),
    SubcontractorName: yup.string().required("PPR Type is required"),
    SubcontractorEmail: yup.string().required("PPR Type is required"),
    ContractorPerformingWork: yup.string().required("PPR Type is required"),
    DescriptionOfWork: yup.string().required("This is required"),
    Notesforprocurement: yup.string().notRequired(),
    TypeOfDocuments: yup.string().required("Type Of Documents is required"),
    TypeOfDocumentsOthers: yup.string().when('TypeOfDocuments', {is: (tod: string) => tod === "Others", then: () => yup.string().required("Others is required"), otherwise: () => yup.string().notRequired()}),
    fileAllAttachment: yup.mixed().test("fileAllAttachment", "File Attachment is required", (file:FileList) => { if(file?.length > 0) { return true;}else{ return false;} }),
    ContactNeedCopy: yup.string().notRequired(),
    ContactReplacement: yup.string().notRequired(),
    Contacttoberemoved: yup.string().when('ContactReplacement', {is: (cr: string) => cr==="Yes", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),

    NumberofLineItems: yup.string().required("Number of Line Item is required"),
    RetainagePercentage: yup.string().required("Retainage Percentage is required"),
    
    TaskCodeItem1: yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "1" || itemcount === "2" || itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem1: yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "1" || itemcount === "2" || itemcount === "3", then: () => yup.number().default(0).required("Amount is required"), otherwise: () => yup.number().default(0).notRequired()}),
    DescriptionItem1:yup.string().notRequired(),

    TaskCodeItem2: yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "2" || itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem2: yup.number().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "2" || itemcount === "3", then: () => yup.number().default(0).required("Amount is required"), otherwise: () => yup.number().default(0).notRequired()}),
    DescriptionItem2:yup.string().notRequired(),

    TaskCodeItem3:yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem3: yup.number().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "3", then: () => yup.number().default(0).required("Amount is required"), otherwise: () => yup.number().default(0).notRequired()}),
    DescriptionItem3:yup.string().notRequired(),

    TotalAmount: yup.string().notRequired(),
    fileLineItem: yup.mixed().when('NumberofLineItems', {is: (itemcount:string) => itemcount === "more", then: () => yup.mixed().test("fileLineItem", "You need to provide a Attach Line Items Template file", (file:FileList) => { if(file?.length > 0) { return true;}else{ return false;} }), otherwise: () => yup.mixed().notRequired() }),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    IAmProjectManager: yup.string().required("This is required"),
});
export type TspprFormSchema = yup.InferType<typeof spprFormSchema>

export const spprPMFormSchema = yup.object().shape({
   
    Stage: yup.string().required("Outcome is required"),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),

    NumberofLineItems: yup.string().required("Number of Line Item is required"),
    RetainagePercentage: yup.string().required("Retainage Percentage is required"),
    
    TaskCodeItem1: yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "1" || itemcount === "2" || itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem1: yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "1" || itemcount === "2" || itemcount === "3", then: () => yup.number().default(0).required("Amount is required"), otherwise: () => yup.number().default(0).notRequired()}),
    DescriptionItem1:yup.string().notRequired(),

    TaskCodeItem2: yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "2" || itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem2: yup.number().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "2" || itemcount === "3", then: () => yup.number().default(0).required("Amount is required"), otherwise: () => yup.number().default(0).notRequired()}),
    DescriptionItem2:yup.string().notRequired(),

    TaskCodeItem3:yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem3: yup.number().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "3", then: () => yup.number().default(0).required("Amount is required"), otherwise: () => yup.number().default(0).notRequired()}),
    DescriptionItem3:yup.string().notRequired(),

    TotalAmount: yup.number().default(0).notRequired(),
    fileLineItem: yup.mixed().when('NumberofLineItems', {is: (itemcount:string) => itemcount === "more", then: () => yup.mixed().test("fileLineItem", "You need to provide a Attach Line Items Template file", (file:FileList) => { if(file?.length > 0) { return true;}else{ return false;} }), otherwise: () => yup.mixed().notRequired() }),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    DelegatedTo: yup.string().when('Stage', {is: (stage:string) => stage === "Delegate", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    ReviseComment: yup.string().when('Stage', {is: (stage:string) => stage === "Revise", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
});
export type TspprPMFormSchema = yup.InferType<typeof spprPMFormSchema>

export const spprIRFormSchema = yup.object().shape({

    Stage: yup.string().required("Outcome is required"),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),

    RequiredbyDate: yup.string().required("Required by Date is required"),
    PPRType: yup.string().required("PPR Type is required"),
    SubcontractorName: yup.string().required("PPR Type is required"),
    SubcontractorEmail: yup.string().required("PPR Type is required"),
    ContractorPerformingWork: yup.string().required("PPR Type is required"),
    DescriptionOfWork: yup.string().required("This is required"),
    Notesforprocurement: yup.string().notRequired(),
    TypeOfDocuments: yup.string().required("Type Of Documents is required"),
    TypeOfDocumentsOthers: yup.string().when('TypeOfDocuments', {is: (tod: string) => tod === "Others", then: () => yup.string().required("Others is required"), otherwise: () => yup.string().notRequired()}),
    ContactNeedCopy: yup.string().notRequired(),
    ContactReplacement: yup.string().notRequired(),
    Contacttoberemoved: yup.string().when('ContactReplacement', {is: (cr: string) => cr==="Yes", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),

    NumberofLineItems: yup.string().required("Number of Line Item is required"),
    RetainagePercentage: yup.string().required("Retainage Percentage is required"),
    
    TaskCodeItem1: yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "1" || itemcount === "2" || itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem1: yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "1" || itemcount === "2" || itemcount === "3", then: () => yup.number().default(0).required("Amount is required"), otherwise: () => yup.number().default(0).notRequired()}),
    DescriptionItem1:yup.string().notRequired(),

    TaskCodeItem2: yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "2" || itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem2: yup.number().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "2" || itemcount === "3", then: () => yup.number().default(0).required("Amount is required"), otherwise: () => yup.number().default(0).notRequired()}),
    DescriptionItem2:yup.string().notRequired(),

    TaskCodeItem3:yup.string().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "3", then: () => yup.string().required("Task Code is required"), otherwise: () => yup.string().notRequired()}),
    InitialAmountItem3: yup.number().when('NumberofLineItems', {is: (itemcount: string) => itemcount === "3", then: () => yup.number().default(0).required("Amount is required"), otherwise: () => yup.number().default(0).notRequired()}),
    DescriptionItem3:yup.string().notRequired(),

    TotalAmount: yup.string().notRequired(),
    fileLineItem: yup.mixed().when('NumberofLineItems', {is: (itemcount:string) => itemcount === "more", then: () => yup.mixed().test("fileLineItem", "You need to provide a Attach Line Items Template file", (file:FileList) => { if(file?.length > 0) { return true;}else{ return false;} }), otherwise: () => yup.mixed().notRequired() }),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
});
export type TspprIRFormSchema = yup.InferType<typeof spprIRFormSchema>

export const spprPRFormSchema = yup.object().shape({
   
    Stage: yup.string().required("Outcome is required"),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),
    RequiredbyDate: yup.string().required("Required by Date is required"),

    NeedtoRevisetaskcode: yup.string().required("This is required"),
    ReasonTCRevision:yup.string().when('NeedtoRevisetaskcode', {is: (ntrtc: string) => ntrtc==="Yes", then: () =>  yup.string().required("This is required"), otherwise: () => yup.string().notRequired() }),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    DelegatedTo: yup.string().when('Stage', {is: (stage:string) => stage === "Delegate", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    VoidComments: yup.string().when('Stage', {is: (stage:string) => stage === "Void", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    ProcurementComment: yup.string().when('Stage', {is: (stage:string) => stage === "Revise", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
});
export type TspprPRFormSchema = yup.InferType<typeof spprPRFormSchema>

export const spprPRCFormSchema = yup.object().shape({
   
    Stage: yup.string().required("Outcome is required"),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    RejectionComments: yup.string().when('Stage', {is: (stage:string) => stage === "Rejected", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    ReviseComment: yup.string().when('Stage', {is: (stage:string) => stage === "Revise", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    PRPromisedDate: yup.string().when('Stage', {is: (stage:string) => stage === "Accepted", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    PREnteredDate: yup.string().when('Stage', {is: (stage:string) => stage === "Accepted", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    PRNumber: yup.string().when('Stage', {is: (stage:string) => stage === "Accepted", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    PRApprovedDate: yup.string().when('Stage', {is: (stage:string) => stage === "Accepted", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()})
});
export type TspprPRCFormSchema = yup.InferType<typeof spprPRCFormSchema>

export const spprPOFormSchema = yup.object().shape({
   
    Stage: yup.string().required("Outcome is required"),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    RejectionComments: yup.string().when('Stage', {is: (stage:string) => stage === "Rejected", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    
    POEnteredDate: yup.string().when('Stage', {is: (stage:string) => stage === "Accepted", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    PONumber: yup.string().when('Stage', {is: (stage:string) => stage === "Accepted", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    POApprovedDate: yup.string().when('Stage', {is: (stage:string) => stage === "Accepted", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    ApprovedPOAmount: yup.string().when('Stage', {is: (stage:string) => stage === "Accepted", then: () => yup.string().required(), otherwise: () => yup.string().notRequired()}),
    NewRequiredByDate: yup.string().notRequired(),
    NewRequiredByDateComment: yup.string().notRequired(),
    NewPromiseDate: yup.string().notRequired(),
    NewPromiseDateComment: yup.string().notRequired(),
   
});
export type TspprPOFormSchema = yup.InferType<typeof spprPOFormSchema>

export const spprCOFormSchema = yup.object().shape({
   
    Stage: yup.string().notRequired(),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired(),
    fileAllAttachment: yup.mixed().test("fileAllAttachment", "File Attachment is required", (file:FileList) => { if(file?.length > 0) { return true;}else{ return false;} }),
   
});
export type TspprCOFormSchema = yup.InferType<typeof spprCOFormSchema>

export interface IWrorkFlow{
    Id?: number;
    itemID?: string;
    Transaction?: string;
    Stage: string;
    Status:string;
    flag?: string;
}

export interface IDelegateItem{
    id: string;
    imageInitials: string;
    imageUrl: string;
    loginName:string;
    optionalText:string;
    secondaryText:string;
    tertiaryText:string;
    text:string;
}