import { getSP } from "./pnpjsConfig";
import { IWrorkFlow } from "./types";

const WorkFlowSubmit = async (ID:string, isAddItem:boolean =  false, Status: string, Stage: string, flag: string = "2", ProjectName :string = ""):Promise<string> => {
    
    let WFData:IWrorkFlow = {
        Stage: Stage,
        Status: Status
    };

    if(flag !== ""){
       WFData = { ...WFData, ...{ flag: flag }};
    }

    console.log("WF DATA:", WFData);
    const sp = getSP();
    if(isAddItem){
        WFData = { ...WFData, ...{ itemID: ID, Transaction: 'SPPR',  ProjectName: ProjectName}}; //change 'SPPR' string to a specific List Name as Transaction Type
        return await sp.web.lists.getByTitle("Workflow List").items.add(WFData)
        .then(()=>{ return Promise.resolve("WF Successfully Added: itemID = "+ID)}).catch((error)=>{ return Promise.reject("WF Error adding: "+error.message)});
    }else{
        const items: IWrorkFlow[] = await sp.web.lists.getByTitle("Workflow List").items.top(1).filter("itemID eq '"+ID+"' and Transaction eq 'SPPR'")();
        console.log("WF QUERY:", items);
        if (items.length > 0 && items[0].Id) {
            return await sp.web.lists.getByTitle("Workflow List").items.getById(items[0].Id).update(WFData)
            .then((res)=>{ return Promise.resolve("WF Update Success")}).catch((error)=>{ return Promise.reject("WF Error: "+error.message)});
        }else{
            return Promise.reject("WF Error: No WorkFlow Item Found");
        }
    }
    
}
export default WorkFlowSubmit;