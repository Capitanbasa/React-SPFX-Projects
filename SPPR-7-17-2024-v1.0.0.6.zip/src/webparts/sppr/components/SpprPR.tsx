import * as React from 'react';
import styles from './Sppr.module.scss';
import type { ISpprProps } from './ISpprProps';
import { Alert, Button, Card, Col, Container, Form, InputGroup, Modal, Row, Spinner } from 'react-bootstrap';
import { TspprPRFormSchema, spprPRFormSchema } from '../utils/types';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup"
import { getSP } from '../utils/pnpjsConfig';
// import { addFilesPromiseRename } from '../utils/addFilesPromise';
import WorkFlowSubmit from '../utils/WorkFlowSubmit';
import { IAttachmentInfo } from '@pnp/sp/attachments';
import { IoDocumentAttachOutline } from "react-icons/io5";
import { IPeoplePickerContext, PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { DatePicker } from 'antd';
import * as dayjs from 'dayjs';

export default function SpprPR(Props:ISpprProps):React.ReactElement{
  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [CCGroup, setCCGroup ] = React.useState(false);
  const [nextStage , setnextStage] = React.useState("");
  const [theAttachmentFiles, settheAttachmentFiles] = React.useState<IAttachmentInfo[]>([]);
  const [ReviseTaskCode, setReviseTaskCode] = React.useState(Props.spSpprItem[0].NeedtoRevisetaskcode);
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);

  const peoplePickerContext: IPeoplePickerContext = {
    absoluteUrl: Props.spContext.pageContext.web.absoluteUrl,
    msGraphClientFactory: Props.spContext.msGraphClientFactory,
    spHttpClient: Props.spContext.spHttpClient
  };

  const { 
    register, 
    handleSubmit,
    formState: {errors, isSubmitting},
    reset, setValue
  } = useForm<TspprPRFormSchema>({
    resolver: yupResolver(spprPRFormSchema),
  });

  /* eslint-disable  @typescript-eslint/no-explicit-any */
  const _getPeoplePickerDelegate = (items:any[]):void => {
    console.log("Delegated User:",items );
    items.map((item) => { 
      setValue("DelegatedTo", item.loginName);
    });
  }

  let attachments: IAttachmentInfo[] = [];
  React.useEffect(() => {
    async function fecthData():Promise<void>{
      const sp = getSP();
      const item = sp.web.lists.getByTitle(Props.PanePropsSpprList).items.getById(parseInt(Props.spSpprItem[0].Id));
      attachments = await item.attachmentFiles().then(async res => {return res});
      settheAttachmentFiles(attachments);
      console.log("await:",attachments);
    }
    setValue("RequiredbyDate", Props.spSpprItem[0].RequiredbyDate );
    fecthData().catch(console.error);
  },[]);

  const onSubmit = async (data: TspprPRFormSchema):Promise<void> => {
    const sp = getSP(Props.spContext);
    data.CCUser = CCGroup === true ? "Yes": "No";
    data.flag = "2";

    let newStatus:string = "Pending";
    let newStage:string = "PM Review";
    switch(data.Stage){
      case "Revise": newStatus = "Pending"; newStage = "Initiator Revision";break;
      case "PR Creation": newStatus = "Pending"; newStage = "PR Creation"; break;
      case "Delegate": newStatus = "Delegate"; newStage = "Procurement Review"; break;
      case "Void": newStatus = "Void"; newStage = "Void"; break;
      default: newStatus = "Pending"; newStage = "Procurement Review";
    }
    data.Status = newStatus;
    data.Stage = newStage;

    console.log("Schema Data:", data);

    await sp.web.lists.getByTitle(Props.PanePropsSpprList).items.getById(parseInt(Props.spSpprItem[0].Id)).update(data)
    .then(async (addResult) => {
      console.log("add result:",addResult);
      setShowSuccess(true);
      setmessage("Successfully Submitted Your Request.");
      setMessageType('success');
      const WFresult = await WorkFlowSubmit(Props.spSpprItem[0].Id.toString(), false, newStatus, newStage, "2");
      console.log("WF Result:", WFresult);
      reset();
      setModalShow(true);
      return Promise.resolve;
    })
    .catch( (error) => {
        console.log("Error Submit:", error);
        setShowSuccess(true);
        setmessage("Sorry! Your Request failed to Submit. Please try again.");
        setMessageType('danger');
        return Promise.reject;
    });
    
  };

  return(
    <section className={`${styles.sppr} ${Props.hasTeamsContext ? styles.teams : ''}`}>
      <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
        <fieldset disabled={Props.spView}>
          <Container>
            <Card>
              <Card.Header className="h5">Service Procurement Project Request (SPPR) - PROCUREMENT REVIEW</Card.Header>
              <Card.Body>
                <Card className='mb-4' style={{ width: '100%' }}>
                  <Card.Header className="h5">Initiator Details </Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Project Number and Name</Form.Label>
                          <Form.Control type="text" value={Props.spSpprItem[0].ProjectName} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Instance Number</Form.Label>
                          <Form.Control type="text" value={Props.spSpprItem[0].Id} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Requester Name</Form.Label>
                          <Form.Control type="text" value={Props.spSpprItem[0].RequesterName} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Requester Email</Form.Label>
                          <Form.Control type="text" value={Props.spSpprItem[0].RequesterEmail} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Subject</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].Subject} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Vendor</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].Vendor} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                      <Form.Group className="mb-4" >
                          <Form.Label className={styles.required}>Required by Date</Form.Label>
                          <DatePicker 
                            className='form-control' 
                            allowClear={true}
                            format={"MMM DD, YYYY"}
                            minDate={dayjs()}
                            {...register("RequiredbyDate")} 
                            defaultValue={dayjs(Props.spSpprItem[0].RequiredbyDate, "MMM DD, YYYY")}
                            onChange={(e): void => {  if(e){ setValue("RequiredbyDate", e.format("MMM DD, YYYY").toString(),  { shouldValidate: true }) } }} />
                          <Form.Control.Feedback type="invalid">
                            {errors.RequiredbyDate?.message} 
                          </Form.Control.Feedback>
                          <p className="link-danger">{errors.RequiredbyDate?.message}</p>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>

                <Card className="mb-3">
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Description of work to be performed</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].DescriptionOfWork} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Notes or special directions for procurement</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].Notesforprocurement} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>PPR Type</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].PPRType} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Is contractor performing work on site?</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].ContractorPerformingWork} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Subcontractor Name</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].SubcontractorName} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Subcontractor Name</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].SubcontractorEmail} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Type of Documents</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].TypeOfDocuments} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Others</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].TypeOfDocumentsOthers} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                
                <Card className="mb-3">
                  <Card.Header className="h5">Line Items</Card.Header>
                  <Card.Body>
                    <Card.Subtitle>Please dont forget to fillout the line items below</Card.Subtitle>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Number of Line Items</Form.Label>
                          <Form.Select aria-label="Please Select"  
                            defaultValue={Props.spSpprItem[0].NumberofLineItems} disabled>
                            <option value="">Please Select</option>
                            <option key="nol-null" value="1">1</option>
                            <option key="nol-1" value="2">2</option>
                            <option key="nol-2" value="3">3</option>
                            <option key="nol-3" value="more">more than 3 items</option>
                          </Form.Select>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Retainage Percentage</Form.Label>
                          <Form.Select aria-label="Please Select" 
                            defaultValue={Props.spSpprItem[0].RetainagePercentage} disabled>
                            <option value="">Please Select</option>
                            <option key="rp-0" value="0">0</option>
                            <option key="rp-5" value="5">5</option>
                            <option key="rp-10" value="10">10</option>
                          </Form.Select>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row className='mb-3'>
                      <Col>
                        <Card>
                          <Card.Header className="h5">Initiator Attachments</Card.Header>
                          <Card.Body>
                            <div className="d-grid gap-2">
                            {
                            theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                              //if(aFile.FileName.substring(0,10) === "[LineItem]"){
                                return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                              //}
                              })
                            }
                            </div>
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
                    
                    <Row>
                      <Col>
                        <Card className='mb-3'>
                          <Card.Header>Line Item 1</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select" 
                                    defaultValue={Props.spSpprItem[0].TaskCodeItem1} disabled>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Amount</Form.Label>
                                  <InputGroup>
                                    <InputGroup.Text>$</InputGroup.Text>
                                    <Form.Control type="text"  
                                      defaultValue={Props.spSpprItem[0].InitialAmountItem1}
                                      disabled/>
                                  </InputGroup>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text"  
                                    defaultValue={Props.spSpprItem[0].DescriptionItem1}
                                    disabled/>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-3'>
                          <Card.Header>Line Item 2</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select" 
                                    defaultValue={Props.spSpprItem[0].TaskCodeItem2}
                                    disabled>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Amount</Form.Label>
                                  <InputGroup>
                                    <InputGroup.Text>$</InputGroup.Text>
                                    <Form.Control type="text"  
                                      defaultValue={Props.spSpprItem[0].InitialAmountItem2}
                                      disabled/>
                                  </InputGroup>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text"  
                                    defaultValue={Props.spSpprItem[0].DescriptionItem2}
                                    disabled/>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-3'>
                          <Card.Header>Line Item 3</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select"
                                    defaultValue={Props.spSpprItem[0].TaskCodeItem3}
                                    disabled>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                <Form.Label className={styles.required}>Amount</Form.Label>
                                  <InputGroup>
                                    <InputGroup.Text>$</InputGroup.Text>
                                    <Form.Control type="text"  
                                      defaultValue={Props.spSpprItem[0].InitialAmountItem3}
                                      disabled/>
                                  </InputGroup>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text"  
                                    defaultValue={Props.spSpprItem[0].DescriptionItem3}
                                    disabled/>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-3'>
                          <Card.Header>Total Amount</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Control type="text" value={Props.spSpprItem[0].TotalAmount} disabled/>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Row>
                          <Col>
                            <Form.Group className="mb-5">
                              <Form.Label className={styles.required}>Need to Revise task code?</Form.Label>
                              <Form.Select aria-label="Please Select" 
                              {...register("NeedtoRevisetaskcode")} 
                              isInvalid={!!errors.NeedtoRevisetaskcode }
                              defaultValue={Props.spSpprItem[0].NeedtoRevisetaskcode}
                              onChange={(e)=>{setReviseTaskCode(e.currentTarget.value )}} >
                                <option value="">Please Select</option>
                                <option key='revtaskcode1' value="Yes">Yes</option>
                                <option key='revtaskcode2' value="No">No</option>
                              </Form.Select>
                              <Form.Control.Feedback type="invalid">
                                {errors.NeedtoRevisetaskcode?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                          <Col>
                            <Form.Group className="mb-3" hidden={ReviseTaskCode === "No" ? true : false }>
                              <Form.Label className={styles.required}>Reason for task code revision</Form.Label>
                              <Form.Control as="textarea" rows={3} 
                              {...register("ReasonTCRevision")} 
                              isInvalid={!!errors.ReasonTCRevision }
                              defaultValue={Props.spSpprItem[0].ReasonTCRevision} />
                              <Form.Text muted>Please be specific with the reason and what changed as Initiator will be notified.</Form.Text>
                              <Form.Control.Feedback type="invalid">
                                {errors.ReasonTCRevision?.message}
                              </Form.Control.Feedback>
                            </Form.Group>
                          </Col>
                        </Row>


                        <Card className='mb-2' hidden={ Props.spSpprItem[0].NumberofLineItems === "more" ? false : true }>
                          <Card.Header>Line Item</Card.Header>
                          <Card.Body>
                            <Card.Subtitle className="mb-2 text-muted">For more than 3 line items, please don&apos;t forget to fill-out the line items below.</Card.Subtitle>
                            <Card.Text>Instructions: Follow the link to navigate to the Box. Download the file named &lsquo;Project/Dev Proj SPPR Line Items template&lsquo;. Fill it in, save it in your computer and then attach it to the section below.</Card.Text>
                            <p hidden={Props.spSpprItem[0].ProjectType === "Prod" ? false : true }><a href='https://sunpowercorp.app.box.com/file/654423387489' rel="opener">Download template here</a> to fill in the Line Items</p>
                            <p hidden={Props.spSpprItem[0].ProjectType === "DEV" ? false : true }><a href='https://sunpowercorp.app.box.com/file/654446093966' rel="opener">Download template here</a> to fill in the Line Items</p>
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header className="h5">CC Users</Card.Header>
                      <Card.Body>
                      <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                        <Form.Group className="mb-3" >
                          <Form.Check
                            inline
                            label="Yes"
                            value="true"
                            {...register("CCUser")} 
                            onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                          />
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label className={styles.required}>Email Addresses</Form.Label>
                          <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CCEmails?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("CCComment")} />
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Card className='mb-4'>
                  <Card.Header className="h5">Next Step</Card.Header>
                  <Card.Body>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Outcome</Form.Label>
                      <Form.Select aria-label="Please Select Next Step" {...register("Stage")} isInvalid={!!errors.Stage } onChange={(e)=>{setnextStage(e.currentTarget.value )}} >
                        <option value="">Please Select Next Step</option>
                        <option key='ns4' value="Revise">Initiator Revision</option>
                        <option key='ns2' value="PR Creation">Ready for PR Creation</option>
                        <option key='ns3' value="Delegate">Delegate</option>
                        <option key='ns3' value="Void">Void</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.Stage?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                    <Row>
                      <Col>
                        <Form.Group className="mb-5" hidden={nextStage === "Delegate" ? false: true}>
                          <PeoplePicker
                            context={peoplePickerContext}
                            {...register("DelegatedTo")}
                            titleText="Choose user to delegate"
                            personSelectionLimit={1}
                            showtooltip={true}
                            required={true}
                            ensureUser={true}
                            onChange={ items => _getPeoplePickerDelegate(items) }
                            principalTypes={[PrincipalType.User]}
                            resolveDelay={1000} />
                          <p className="link-danger">{errors.DelegatedTo?.message}</p>
                        </Form.Group>
                        <Form.Group className="mb-5" hidden={nextStage === "Revise" ? false: true}>
                          <Form.Label>Procurement Comments for Revision</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("ProcurementComment")} isInvalid={ !!errors.ProcurementComment }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.ProcurementComment?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-5" hidden={nextStage === "Void" ? false: true}>
                          <Form.Label>Void Comments</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("VoidComments")} isInvalid={ !!errors.VoidComments }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.VoidComments?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Row className="mb-4">
                  <Col>
                    <div className="d-grid gap-2">
                      <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting }>
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden={ !!isSubmitting }
                        className={ "visually-hidden" } />
                      { isSubmitting ? "...Submitting" : "SUBMIT" }
                      </Button>
                    </div>
                  </Col>
                </Row>
                { ShowSuccess && (
                    <Alert 
                      key={ MessageType } 
                      variant={ MessageType } 
                      dismissible 
                      onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                        { message }
                    </Alert>
                )}
              </Card.Body>
            </Card>
          </Container>
        </fieldset>
      </form>
      <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
        <Modal.Header>
          <Modal.Title>SharePoint</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Alert variant="primary">
            <Alert.Heading>{ message }</Alert.Heading>
            <p hidden={MessageType === "danger" ? true : false}>
              Thank you! You can now close this tab or window.
            </p>
          </Alert>
        </Modal.Body>
        <Modal.Footer hidden={MessageType === "danger" ? false : true}>
          <Button variant="secondary" onClick={handleClose}>
            Continue
          </Button>
        </Modal.Footer>
      </Modal>
    </section>
  );
}
