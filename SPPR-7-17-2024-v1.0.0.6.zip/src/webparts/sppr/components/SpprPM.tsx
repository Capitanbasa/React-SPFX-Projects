import * as React from 'react';
import styles from './Sppr.module.scss';
import type { ISpprProps } from './ISpprProps';
import { Alert, Button, Card, Col, Container, Form, InputGroup, Modal, Row, Spinner } from 'react-bootstrap';
import { TspprPMFormSchema, spprPMFormSchema } from '../utils/types';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup"
import { getSP } from '../utils/pnpjsConfig';
import { addFilesPromiseRename } from '../utils/addFilesPromise';
import WorkFlowSubmit from '../utils/WorkFlowSubmit';
import { IAttachmentInfo } from '@pnp/sp/attachments';
import { IoDocumentAttachOutline } from "react-icons/io5";
import { IPeoplePickerContext, PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
//import { DatePicker } from 'antd';
//import * as dayjs from 'dayjs';


export default function SpprPM(Props:ISpprProps):React.ReactElement{
  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [CCGroup, setCCGroup ] = React.useState(false);
  const [nextStage , setnextStage] = React.useState("");
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);

  const [NIS, setNIS ] = React.useState(Props.spSpprItem[0].NumberofLineItems);
  const [TotalAmount , setTotalAmount] = React.useState<number>(parseFloat(Props.spSpprItem[0].TotalAmount));
  const [ItemAmount1 , setItemAmount1] = React.useState<number>(parseFloat(Props.spSpprItem[0].InitialAmountItem1));
  const [ItemAmount2 , setItemAmount2] = React.useState<number>(parseFloat(Props.spSpprItem[0].InitialAmountItem2));
  const [ItemAmount3 , setItemAmount3] = React.useState<number>(parseFloat(Props.spSpprItem[0].InitialAmountItem3));
  const [theAttachmentFiles, settheAttachmentFiles] = React.useState<IAttachmentInfo[]>([]);

  const peoplePickerContext: IPeoplePickerContext = {
    absoluteUrl: Props.spContext.pageContext.web.absoluteUrl,
    msGraphClientFactory: Props.spContext.msGraphClientFactory,
    spHttpClient: Props.spContext.spHttpClient
  };

  let attachments: IAttachmentInfo[] = [];
    React.useEffect(() => {
      async function fecthData():Promise<void>{
        const sp = getSP();
        const item = sp.web.lists.getByTitle(Props.PanePropsSpprList).items.getById(parseInt(Props.spSpprItem[0].Id));
        attachments = await item.attachmentFiles().then(async res => {return res});
        settheAttachmentFiles(attachments);
        console.log("await:",attachments);
      }
      fecthData().catch(console.error);
    },[]);


  const { 
    register, 
    handleSubmit,
    formState: {errors, isSubmitting},
    reset, setValue
  } = useForm<TspprPMFormSchema>({
    resolver: yupResolver(spprPMFormSchema),
  });

  /* eslint-disable  @typescript-eslint/no-explicit-any */
  const _getPeoplePickerDelegate = (items:any[]):void => {
    console.log("Delegated User:",items );
    items.map((item) => { 
      setValue("DelegatedTo", item.loginName);
    });
  }

  const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
    if(FileAttachment && FileAttachment?.length > 0){
      for(let i =0; i < FileAttachment.length; i++){
        /* eslint-disable no-useless-escape */
        const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
        if(match){
          setShowSuccess(true);
          setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
          setMessageType('danger');
          return true;
        }else{
          return false;
        }
      }
    }
    return false;
  }

  const onSubmit = async (data: TspprPMFormSchema):Promise<void> => {
    const sp = getSP(Props.spContext);
    const fileLineItem = document.getElementById("fileLineItem") as HTMLInputElement;
    const AttfileLineItem = fileLineItem.files;
    if(filenameCharValidation(AttfileLineItem)){ return; }


    data.CCUser = CCGroup === true ? "Yes": "No";
    data.flag = "2";
    data.TotalAmount = TotalAmount;
    delete data.fileLineItem;

    let newStatus:string = "Pending";
    let newStage:string = "PM Review";
    switch(data.Stage){
      case "Revise": newStatus = "Pending"; newStage = "Initiator Revision";break;
      case "Procurement Review": newStatus = "Pending"; newStage = "Procurement Review"; break;
      case "Delegate": newStatus = "Delegate"; newStage = "PM Review"; break;
      default: newStatus = "Pending"; newStage = "PM Review";
    }
    data.Status = newStatus;
    data.Stage = newStage;

    console.log("Schema Data:", data);

    await sp.web.lists.getByTitle(Props.PanePropsSpprList).items.getById(parseInt(Props.spSpprItem[0].Id)).update(data)
    .then(async (addResult) => {
      console.log("add result:",addResult);
      if( AttfileLineItem && AttfileLineItem?.length > 0){
        const PromoseArray = [];
        for(let i =0; i < AttfileLineItem.length; i++){
          const UploadArrayBid = await addFilesPromiseRename( Props.PanePropsSpprList, parseInt(Props.spSpprItem[0].Id) , AttfileLineItem, i, "[LineItem]");
          PromoseArray.push(UploadArrayBid);
        }
        Promise.all(PromoseArray).then( res => { 
          console.log("Promise Upload resolve:", res);
          setShowSuccess(true);
          setmessage("Successfully Submitted Your Request.");
          setMessageType('success');
          reset();
        })
        .catch(err => { 
          console.log("Promise Upload reject:", err);
          setShowSuccess(true);
          setmessage("Your Request is Submitted but there was a problem uploading the attachment");
          setMessageType('danger');
          reset();
        });
      }else{
        setShowSuccess(true);
        setmessage("Successfully Submitted Your Request without Attachment.");
        setMessageType('primary');

      }
     
      const WFresult = await WorkFlowSubmit(Props.spSpprItem[0].Id.toString(), false, newStatus, newStage, "2");
      console.log("WF Result:", WFresult);
      reset();
      setModalShow(true);
      return Promise.resolve;
    }).catch( (error) => {
        console.log("Error Submit:", error);
        setShowSuccess(true);
        setmessage("Sorry! Your Request failed to Submit. Please try again.");
        setMessageType('danger');
        return Promise.reject;
    });
    
  };

  React.useEffect(() => { 
    function updateTotal():void{ setTotalAmount(ItemAmount1 + ItemAmount2 + ItemAmount3) }
    updateTotal();
  },[ItemAmount1, ItemAmount2, ItemAmount3]);

  return(
    <section className={`${styles.sppr} ${Props.hasTeamsContext ? styles.teams : ''}`}>
      <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
        <fieldset disabled={Props.spView}>
          <Container>
            <Card>
              <Card.Header className="h5">Service Procurement Project Request (SPPR) - PM Review</Card.Header>
              <Card.Body>
                <Card className='mb-4' style={{ width: '100%' }}>
                  <Card.Header className="h5">Initiator Details </Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Project Number and Name</Form.Label>
                          <Form.Control type="text" value={Props.spSpprItem[0].ProjectName} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Instance Number</Form.Label>
                          <Form.Control type="text" value={Props.spSpprItem[0].Id} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Requester Name</Form.Label>
                          <Form.Control type="text" value={Props.spSpprItem[0].RequesterName} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Requester Email</Form.Label>
                          <Form.Control type="text" value={Props.spSpprItem[0].RequesterEmail} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Subject</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].Subject} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Vendor</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].Vendor} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Required by Date</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].RequiredbyDate} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>

                <Card className="mb-3">
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Description of work to be performed</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].DescriptionOfWork} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label>Notes or special directions for procurement</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].Notesforprocurement} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>PPR Type</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].PPRType} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Is contractor performing work on site?</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].ContractorPerformingWork} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Subcontractor Name</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].SubcontractorName} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Subcontractor Name</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].SubcontractorEmail} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Type of Documents</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].TypeOfDocuments} disabled/>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Others</Form.Label>
                          <Form.Control type="text"  value={Props.spSpprItem[0].TypeOfDocumentsOthers} disabled/>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                
                <Card className="mb-3">
                  <Card.Header className="h5">Line Items</Card.Header>
                  <Card.Body>
                    <Card.Subtitle>Please dont forget to fillout the line items below</Card.Subtitle>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Number of Line Items</Form.Label>
                          <Form.Select aria-label="Please Select"  
                            {...register("NumberofLineItems")} 
                            onChange={(e) => {setNIS(e.currentTarget.value)}} 
                            isInvalid={ !!errors.NumberofLineItems }
                            defaultValue={Props.spSpprItem[0].NumberofLineItems}>
                            <option value="">Please Select</option>
                            <option key="nol-null" value="1">1</option>
                            <option key="nol-1" value="2">2</option>
                            <option key="nol-2" value="3">3</option>
                            <option key="nol-3" value="more">more than 3 items</option>
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.NumberofLineItems?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Retainage Percentage</Form.Label>
                          <Form.Select aria-label="Please Select" 
                            {...register("RetainagePercentage")} 
                            isInvalid={ !!errors.RetainagePercentage }
                            defaultValue={Props.spSpprItem[0].RetainagePercentage}>
                            <option value="">Please Select</option>
                            <option key="rp-0" value="0">0</option>
                            <option key="rp-5" value="5">5</option>
                            <option key="rp-10" value="10">10</option>
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.RetainagePercentage?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row className='mb-3'>
                      <Col>
                        <Card>
                          <Card.Header className="h5">Initiator Attachments</Card.Header>
                          <Card.Body>
                            <div className="d-grid gap-2">
                            {
                            theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                              //if(aFile.FileName.substring(0,10) === "[LineItem]"){
                                return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                              //}
                              })
                            }
                            </div>
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
                    
                    <Row>
                      <Col>
                        <Card className='mb-3'>
                          <Card.Header>Line Item 1</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select" 
                                    {...register("TaskCodeItem1")}
                                    isInvalid={ !!errors.TaskCodeItem1 }
                                    defaultValue={Props.spSpprItem[0].TaskCodeItem1}
                                    disabled={NIS === "1" || NIS === "2" || NIS === "3" ? false : true }>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.TaskCodeItem1?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Amount</Form.Label>
                                  <InputGroup>
                                    <InputGroup.Text>$</InputGroup.Text>
                                    <Form.Control type="text"  
                                      {...register("InitialAmountItem1")} 
                                      isInvalid={ !!errors.InitialAmountItem1 } 
                                      defaultValue={Props.spSpprItem[0].InitialAmountItem1}
                                      onChange={(e)=> { setItemAmount1(parseFloat(e.currentTarget.value)) } } 
                                      disabled={NIS === "1" || NIS === "2" || NIS === "3" ? false : true }/>
                                  </InputGroup>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem1?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text"  
                                    {...register("DescriptionItem1")}
                                    defaultValue={Props.spSpprItem[0].DescriptionItem1}
                                    isInvalid={ !!errors.DescriptionItem1 } 
                                    disabled={NIS === "1" || NIS === "2" || NIS === "3" ? false : true }/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem1?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-3'>
                          <Card.Header>Line Item 2</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select" 
                                    {...register("TaskCodeItem2")}
                                    defaultValue={Props.spSpprItem[0].TaskCodeItem2}
                                    isInvalid={ !!errors.TaskCodeItem2 }
                                    disabled={NIS === "2" || NIS === "3" ? false : true }>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.TaskCodeItem2?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Amount</Form.Label>
                                  <InputGroup>
                                    <InputGroup.Text>$</InputGroup.Text>
                                    <Form.Control type="text"  
                                      {...register("InitialAmountItem2")}
                                      defaultValue={Props.spSpprItem[0].InitialAmountItem2}
                                      isInvalid={ !!errors.InitialAmountItem2 } 
                                      onChange={(e)=> { setItemAmount2(parseFloat(e.currentTarget.value)) } } 
                                      disabled={NIS === "2" || NIS === "3" ? false : true }/>
                                  </InputGroup>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem2?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text"  
                                    {...register("DescriptionItem2")}
                                    defaultValue={Props.spSpprItem[0].DescriptionItem2}
                                    isInvalid={ !!errors.DescriptionItem2 }
                                    disabled={NIS === "2" || NIS === "3" ? false : true }/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem2?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-3'>
                          <Card.Header>Line Item 3</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select"
                                    {...register("TaskCodeItem3")}
                                    defaultValue={Props.spSpprItem[0].TaskCodeItem3}
                                    isInvalid={ !!errors.TaskCodeItem3 }
                                    disabled={ NIS === "3" ? false : true }>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.TaskCodeItem3?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                <Form.Label className={styles.required}>Amount</Form.Label>
                                  <InputGroup>
                                    <InputGroup.Text>$</InputGroup.Text>
                                    <Form.Control type="text"  
                                      {...register("InitialAmountItem3")}
                                      defaultValue={Props.spSpprItem[0].InitialAmountItem3}
                                      isInvalid={ !!errors.InitialAmountItem3 }
                                      onChange={(e)=> { setItemAmount3(parseFloat(e.currentTarget.value)) } }
                                      disabled={ NIS === "3" ? false : true } />
                                  </InputGroup>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem3?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text"  
                                    {...register("DescriptionItem3")}
                                    defaultValue={Props.spSpprItem[0].DescriptionItem3}
                                    isInvalid={ !!errors.DescriptionItem3 }
                                    disabled={ NIS === "3" ? false : true }/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem3?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-3'>
                          <Card.Header>Total Amount</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Control type="text"  {...register("TotalAmount")} value={TotalAmount} disabled/>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-2' hidden={ NIS === "more" ? false : true }>
                          <Card.Header>Line Item</Card.Header>
                          
                          <Card.Body>
                            <Card.Subtitle className="mb-2 text-muted">For more than 3 line items, please don&apos;t forget to fill-out the line items below.</Card.Subtitle>
                            <Card.Text>Instructions: Follow the link to navigate to the Box. Download the file named &lsquo;Project/Dev Proj SPPR Line Items template&lsquo;. Fill it in, save it in your computer and then attach it to the section below.</Card.Text>
                            <p hidden={Props.spSpprItem[0].ProjectType === "Prod" ? false : true }><a href='https://sunpowercorp.app.box.com/file/654423387489' rel="opener">Download template here</a> to fill in the Line Items</p>
                            <p hidden={Props.spSpprItem[0].ProjectType === "DEV" ? false : true }><a href='https://sunpowercorp.app.box.com/file/654446093966' rel="opener">Download template here</a> to fill in the Line Items</p>
                            <Row>
                              <Col>
                              <Form.Group className="mb-5">
                                <Form.Label className={styles.required}>Attach Line Items</Form.Label>
                                <Form.Control type="file" id="fileLineItem" {...register("fileLineItem")} multiple />
                                <Form.Text id="passwordHelpBlock" muted>Please attach only Excel files, other files will be discarded.</Form.Text>
                                <p className="link-danger">{errors.fileLineItem?.message}</p>
                              </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header className="h5">CC Users</Card.Header>
                      <Card.Body>
                      <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                        <Form.Group className="mb-3" >
                          <Form.Check
                            inline
                            label="Yes"
                            value="true"
                            {...register("CCUser")} 
                            onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                          />
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label className={styles.required}>Email Addresses</Form.Label>
                          <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CCEmails?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("CCComment")} />
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Card className='mb-4'>
                  <Card.Header className="h5">Next Step</Card.Header>
                  <Card.Body>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Outcome</Form.Label>
                      <Form.Select aria-label="Please Select Next Step" {...register("Stage")} isInvalid={!!errors.Stage } onChange={(e)=>{setnextStage(e.currentTarget.value )}} >
                        <option value="">Please Select Next Step</option>
                        <option key='ns4' value="Revise">Initiator Revision</option>
                        <option key='ns2' value="Procurement Review">Approved</option>
                        <option key='ns3' value="Delegate">Delegate</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.Stage?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                    <Row>
                      <Col>
                        <Form.Group className="mb-5" hidden={nextStage === "Delegate" ? false: true}>
                          <PeoplePicker
                            context={peoplePickerContext}
                            {...register("DelegatedTo")}
                            titleText="Choose user to delegate"
                            personSelectionLimit={1}
                            showtooltip={true}
                            required={true}
                            ensureUser={true}
                            onChange={ items => _getPeoplePickerDelegate(items) }
                            principalTypes={[PrincipalType.User]}
                            resolveDelay={1000} />
                          <p className="link-danger">{errors.DelegatedTo?.message}</p>
                        </Form.Group>
                        <Form.Group className="mb-5" hidden={nextStage === "Revise" ? false: true}>
                          <Form.Label>Comments - Revise</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("ReviseComment")} isInvalid={ !!errors.ReviseComment }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.ReviseComment?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Row className="mb-4">
                  <Col>
                    <div className="d-grid gap-2">
                      <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting }>
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden={ !!isSubmitting }
                        className={ "visually-hidden" } />
                      { isSubmitting ? "...Submitting" : "SUBMIT" }
                      </Button>
                    </div>
                  </Col>
                </Row>
                { ShowSuccess && (
                    <Alert 
                      key={ MessageType } 
                      variant={ MessageType } 
                      dismissible 
                      onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                        { message }
                    </Alert>
                )}
              </Card.Body>
            </Card>
          </Container>
        </fieldset>
      </form>
        <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
          <Modal.Header>
            <Modal.Title>SharePoint</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Alert variant="primary">
              <Alert.Heading>{ message }</Alert.Heading>
              <p hidden={MessageType === "danger" ? true : false}>
                Thank you! You can now close this tab or window.
              </p>
            </Alert>
          </Modal.Body>
          <Modal.Footer hidden={MessageType === "danger" ? false : true}>
            <Button variant="secondary" onClick={handleClose}>
              Continue
            </Button>
          </Modal.Footer>
        </Modal>
      </section>
  );
}
