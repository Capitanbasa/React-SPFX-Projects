import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface ISpprProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  spContext: WebPartContext;
  spProjectListItems?: IProjectListItem[];
  PanePropsProjectNumberName: string;
  PanePropsSpprList:string;
  PanePropsPropsedVendor:string;
  userEmail?:string;
  spSpprItem:ISpprListItems[];
  spTaskCodeListItems: ITaskCodes[];
  spView: boolean;
}

export interface IProjectListItem{
  id: string;
  ProjectName: string;
  ProjectType: string;
}
export interface IProposeVendor{
  id: string;
  VendorName: string;
  Range: string;
}

export interface ITaskCodes {
  id:string;
  TaskCode: string;
}

export interface ISpprListItems{
  AssignedTo:string;
  AssignedToId:number;
  ProjectType:string;
  Id: string;
  Stage: string;
  Status: string;
  ProjectName:string;
  RequesterName: string;
  RequesterEmail: string;
  Subject: string;
  CCUser: string;
  CCEmails?: string;
  CCComment?:string;
  flag:string;
  RequiredbyDate: string;
  ProposedVendor: string;
  Vendor: string;
  PPRType: string;
  SubcontractorName: string;
  SubcontractorEmail: string;
  ContractorPerformingWork: string;
  DescriptionOfWork:string;
  Notesforprocurement: string;
  TypeOfDocuments:string;
  TypeOfDocumentsOthers:string;
  ContactNeedCopy:string;
  ContactReplacement:string;
  Contacttoberemoved:string;
  NumberofLineItems:string;
  RetainagePercentage:string;
  TaskCodeItem1:string;
  InitialAmountItem1:string;
  DescriptionItem1:string;
  TaskCodeItem2:string;
  InitialAmountItem2:string;
  DescriptionItem2:string;
  TaskCodeItem3:string;
  InitialAmountItem3:string;
  DescriptionItem3:string;
  TotalAmount:string;
  IAmProjectManager:string;
  ReviseComment:string;
  ProcurementComment:string;
  VoidComments:string;
  NeedtoRevisetaskcode: string;
  ReasonTCRevision: string;
  RejectionComments: string;
  PRPromisedDate:string;
  PREnteredDate:string;
  PRNumber: string;
  PRApprovedDate:string;
  POEnteredDate: string;
  PONumber: string;
  POApprovedDate: string;
  ApprovedPOAmount: string;
  NewRequiredByDate: string;
  NewRequiredByDateComment: string;
  NewPromiseDate: string;
  NewPromiseDateComment:string;
}
