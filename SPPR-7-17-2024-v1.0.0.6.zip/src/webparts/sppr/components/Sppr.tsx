import * as React from 'react';
import styles from './Sppr.module.scss';
import type { ISpprProps, IProposeVendor } from './ISpprProps';
import { Alert, Button, Card, Col, Container, Form, InputGroup, Modal, Row, Spinner } from 'react-bootstrap';
import { TspprFormSchema, spprFormSchema } from '../utils/types';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup"
import { getSP } from '../utils/pnpjsConfig';
import { addFilesPromiseRename } from '../utils/addFilesPromise';
import WorkFlowSubmit from '../utils/WorkFlowSubmit';
import { DatePicker } from 'antd';
import * as dayjs from 'dayjs';


export default function Sppr(Props:ISpprProps):React.ReactElement{
  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [CCGroup, setCCGroup ] = React.useState(false);

  const [Vendor, setVendor] = React.useState<IProposeVendor[]>([]);
  const [TypeOfDocs, setTypeOfDocs] = React.useState("");
  const [NIS, setNIS ] = React.useState("");
  const [ProjectType, setProjectType] = React.useState("");
  const [ContactReplacement, setContactReplacement] = React.useState("No");
  const [TotalAmount , setTotalAmount] = React.useState<number>(0);
  const [ItemAmount1 , setItemAmount1] = React.useState<number>(0);
  const [ItemAmount2 , setItemAmount2] = React.useState<number>(0);
  const [ItemAmount3 , setItemAmount3] = React.useState<number>(0);
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);
  const [VendorRange, setVendorRange]  = React.useState("");


  const { 
    register, 
    handleSubmit,
    formState: {errors, isSubmitting},
    reset, setValue
  } = useForm<TspprFormSchema>({
    resolver: yupResolver(spprFormSchema),
  });

  const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
    if(FileAttachment && FileAttachment?.length > 0){
      for(let i =0; i < FileAttachment.length; i++){
        /* eslint-disable no-useless-escape */
        const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
        if(match){
          setShowSuccess(true);
          setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
          setMessageType('danger');
          return true;
        }else{
          return false;
        }
      }
    }
    return false;
  }

  const onSubmit = async (data: TspprFormSchema):Promise<void> => {
    const sp = getSP(Props.spContext);
 
    const fileAllAttachment = document.getElementById("fileAllAttachment") as HTMLInputElement;
    const fileLineItem = document.getElementById("fileLineItem") as HTMLInputElement;
    const AttfileAllAttachment= fileAllAttachment.files;
    const AttfileLineItem = fileLineItem.files;
    if(filenameCharValidation(AttfileAllAttachment)){ return; }
    if(filenameCharValidation(AttfileLineItem)){ return; }


    data.CCUser = CCGroup === true ? "Yes": "No";
    data.flag = "1";
    data.TotalAmount = TotalAmount.toString();
    delete data.fileLineItem;
    delete data.fileAllAttachment;

    let newStatus:string = "";
    let newStage:string = "";

    switch(data.IAmProjectManager){
      case "Yes": newStatus = "Pending"; newStage = "Procurement Review";break;
      case "No": newStatus = "Pending"; newStage = "PM Review"; break;
      default: newStatus = "Pending"; newStage = "PM Review";
    }
    data.Status = newStatus;
    data.Stage = newStage;

    console.log("Schema Data:", data);

    await sp.web.lists.getByTitle(Props.PanePropsSpprList).items.add(data)
    .then(async (addResult) => {
      console.log("add result:",addResult);
      

      if( ( AttfileAllAttachment && AttfileAllAttachment?.length > 0 ) || ( AttfileLineItem && AttfileLineItem?.length > 0 ) ){
        const PromoseArray = [];
        setShowSuccess(true);
        setmessage("Please wait while we upload the file Attachment.");
        setMessageType('warning');

        if( AttfileAllAttachment && AttfileAllAttachment?.length > 0){
          for(let i =0; i < AttfileAllAttachment.length; i++){
            const UploadArrayBid = await addFilesPromiseRename( Props.PanePropsSpprList, addResult.ID , AttfileAllAttachment, i, "[Required-Attachments]");
            PromoseArray.push(UploadArrayBid);
          }
        }

        if( AttfileLineItem && AttfileLineItem?.length > 0){
          for(let i =0; i < AttfileLineItem.length; i++){
            const UploadArrayBid = await addFilesPromiseRename( Props.PanePropsSpprList, addResult.ID , AttfileLineItem, i, "[LineItem]");
            PromoseArray.push(UploadArrayBid);
          }
        }

        Promise.all(PromoseArray).then( res => { 
          console.log("Promise Upload resolve:", res);
          setShowSuccess(true);
          setmessage("Successfully Submitted Your Request.");
          setMessageType('success');
          reset();
        })
        .catch(err => { 
          console.log("Promise Upload reject:", err);
          setShowSuccess(true);
          setmessage("Your Request is Submitted but there was a problem uploading the attachment");
          setMessageType('danger');
          reset();
        });
      }else{
        setShowSuccess(true);
        setmessage("Successfully Submitted Your Request without Attachment.");
        setMessageType('warning');
        reset();
      }
      const WFresult = await WorkFlowSubmit(addResult.ID.toString(), true, newStatus, newStage, "1", data.ProjectName );
      console.log("WF Result:", WFresult);
      setModalShow(true);
      reset();
      return Promise.resolve;
    })
    .catch( (error) => {
        console.log("Error Submit:", error);
        setShowSuccess(true);
        setmessage("Sorry! Your Request failed to Submit. Please try again.");
         setMessageType('danger');
        return Promise.reject;
    });
    
  };

    React.useEffect(() => { 
      function updateTotal():void{ setTotalAmount(ItemAmount1 + ItemAmount2 + ItemAmount3) }
      updateTotal();
    },[ItemAmount1, ItemAmount2, ItemAmount3]);

  // const getFIlteredVendor = async (range:string):Promise<void> => {
  //   const sp = getSP(Props.spContext);
  //   const vendorsretult:IProposeVendor[] = await sp.web.lists.getByTitle(Props.PanePropsPropsedVendor).items.select("VendorName", "Id").filter("Range eq '"+range.toString()+"'")();
  //   setVendor(vendorsretult);
  // }

  React.useEffect(() => {
    async function getAllVendor():Promise<void>{
      const sp = getSP(Props.spContext);
      const countLastIDList = await sp.web.lists.getByTitle(Props.PanePropsPropsedVendor).items.select("ID").orderBy("ID", false).top(1)();
      const TopLastID = countLastIDList.length > 0 ? countLastIDList[0].ID : 0;
      const vendorsretult:IProposeVendor[] = await sp.web.lists.getByTitle(Props.PanePropsPropsedVendor).items.select("VendorName", "Id", "Range").top(TopLastID)();
      setVendor(vendorsretult);
      console.log("Vendor", vendorsretult);
    }
    getAllVendor().catch(console.error);
  },[]);

  return(
    <section className={`${styles.sppr} ${Props.hasTeamsContext ? styles.teams : ''}`}>
       <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
       <Container>
            <Card>
              <Card.Header className="h5">Service Procurement Project Request (SPPR)</Card.Header>
              <Card.Body>
                <Card className='mb-3'>
                  <Card.Header className="h5">Initiator Details</Card.Header>
                  <Card.Body>
                    <Row>
                      <Col>
                      <Form.Group className="mb-3">
                        <Form.Label className={styles.required}>Project Type</Form.Label>
                        <Form.Select aria-label="Please Select" 
                          {...register("ProjectType")} 
                          isInvalid={ !!errors.ProjectType } 
                          onChange={ (e) => { setProjectType(e.currentTarget.value)} }>
                          <option value="">Please Select</option> 
                          <option key="pt-1" value="Prod">Project</option>
                          <option key="pt-2" value="DEV">DEV Project</option>
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">
                          {errors.ProjectType?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" hidden={ ProjectType === "" ? true : false }>
                          <Form.Label className={styles.required}>Project Number and Name</Form.Label>
                          <Form.Select aria-label="Please Select Project" {...register("ProjectName")} isInvalid={ !!errors.ProjectName }>
                            <option value="">Please Select</option> 
                              {Props.spProjectListItems && Props.spProjectListItems.map((list) => {
                                if(list.ProjectType === ProjectType ){
                                    return  ( 
                                      <option key={list.id} value={list.ProjectName}>{list.ProjectName}</option> 
                                    );
                                  }
                              })}
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.ProjectName?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label className={styles.required}>Requester Name</Form.Label>
                          <Form.Control type="text" {...register("RequesterName")} defaultValue={Props.userDisplayName} isInvalid={ !!errors.RequesterName }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.RequesterName?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Requester Email</Form.Label>
                          <Form.Control type="email" {...register("RequesterEmail")} isInvalid={ !!errors.RequesterEmail } defaultValue={Props.userEmail}/>
                          <Form.Control.Feedback type="invalid">
                            {errors.RequesterEmail?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label className={styles.required}>Subject</Form.Label>
                          <Form.Control type="text"  {...register("Subject")} isInvalid={ !!errors.Subject }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.Subject?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Card className="mb-3">
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-4" >
                          <Form.Label className={styles.required}>Required by Date</Form.Label>
                          <DatePicker 
                            className='form-control' 
                            allowClear={true}
                            format={"MMM DD, YYYY"}
                            minDate={dayjs()}
                            {...register("RequiredbyDate")}  
                            onChange={(e): void => {  if(e){ setValue("RequiredbyDate", e.format("MMM DD, YYYY").toString(),  { shouldValidate: true }) } }} />
                          <Form.Text muted>Need by Date is when the Agreement, PO and Insurance are executed, approved and in compliance.  Allow 10 WORKING DAYS turn around for NEW full engagement requests and 5 WORKING DAYS for PO-Only.</Form.Text>
                          <Form.Control.Feedback type="invalid">
                            {errors.RequiredbyDate?.message} 
                          </Form.Control.Feedback>
                          <p className="link-danger">{errors.RequiredbyDate?.message}</p>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Vendor first initial range</Form.Label>
                          <Form.Select aria-label="Please Select Range" 
                            {...register("ProposedVendor")} 
                            isInvalid={ !!errors.ProposedVendor } 
                            onChange={(e) => { setVendorRange(e.currentTarget.value) }}>
                            <option value="">Please Select</option>
                            <option key="range-ad" value="A-D">A-D</option>
                            <option key="range-em" value="E-M">E-M</option>
                            <option key="range-nr" value="N-R">N-R</option>
                            <option key="range-sz" value="S-Z">S-Z</option> 
                          </Form.Select>
                          <Form.Text id="passwordHelpBlock" muted>Please select the range that contains the first initial of the vendors name</Form.Text>
                          <Form.Control.Feedback type="invalid">
                            {errors.ProposedVendor?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Vendor</Form.Label>
                          <Form.Select aria-label="Please Select Vendor" {...register("Vendor")} isInvalid={ !!errors.Vendor }>
                            <option value="">Please Select</option>
                            {Vendor && Vendor.map((list) => {
                                if(list.Range === VendorRange ){
                                    return  ( 
                                      <option key={list.id} value={list.VendorName}>{list.VendorName}</option>
                                    );
                                  }
                            })}
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.Vendor?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                      <Form.Group className="mb-3">
                        <Form.Label className={styles.required}>PPR Type</Form.Label>
                        <Form.Select aria-label="Please Select Category" {...register("PPRType")} isInvalid={ !!errors.PPRType }>
                          <option value="">Please Select</option>
                          <option key="cat-1" value="Amendment (indicate PO number associated with this change)">Amendment (indicate PO number associated with this change)</option>
                          <option key="cat-2" value="LNTP">LNTP</option>
                          <option key="cat-3" value="SOW Release (MSA)">SOW Release (MSA)</option>
                          <option key="cat-4" value="Work Authorization">Work Authorization</option>
                          <option key="cat-4" value="Site Services Work Order: (Site Work under $25K; Onetime only; NO Change Orders allow to Subs)">Site Services Work Order: (Site Work under $25K; Onetime only; NO Change Orders allow to Subs)</option>
                          <option key="cat-4" value="Site Services Subcontractor Agreement: (Site Work over 25K)">Site Services Subcontractor Agreement: (Site Work over 25K)</option>
                          <option key="cat-4" value="PO Only (Use for unique cases - i.e. Permitting; Licensing)">PO Only (Use for unique cases - i.e. Permitting; Licensing)</option>
                          <option key="cat-4" value="Engineering and Consulting Agreement (Firms with no MSA)">Engineering and Consulting Agreement (Firms with no MSA)</option>
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">
                          {errors.PPRType?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" >
                          <Form.Label className={styles.required}>Subcontractor Contact Name</Form.Label>
                          <Form.Control type="text" {...register("SubcontractorName")} isInvalid={ !!errors.SubcontractorName }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.SubcontractorName?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Subcontractor Email</Form.Label>
                          <Form.Control type="email" {...register("SubcontractorEmail")} isInvalid={ !!errors.SubcontractorEmail }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.SubcontractorEmail?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                      <Form.Group className="mb-3">
                        <Form.Label className={styles.required}>Is Contractor performing work on site?</Form.Label>
                        <Form.Select aria-label="Please Select" {...register("ContractorPerformingWork")} isInvalid={ !!errors.ContractorPerformingWork }>
                          <option value="">Please Select</option>
                          <option key="cpw-1" value="Yes">Yes</option>
                          <option key="cpw-2" value="No">No</option>
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">
                          {errors.ContractorPerformingWork?.message}
                        </Form.Control.Feedback>
                      </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Description of work to be performed</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("DescriptionOfWork")} isInvalid={ !!errors.DescriptionOfWork }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.DescriptionOfWork?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Notes and Special Directions for Procurement</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("Notesforprocurement")}/>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Type of Documents</Form.Label>
                          <Form.Select aria-label="Please Select" 
                            {...register("TypeOfDocuments")} 
                            isInvalid={ !!errors.TypeOfDocuments } 
                            onChange={(e) => {setTypeOfDocs(e.currentTarget.value)} }>
                            <option key="tod-null" value="">Please Select</option>
                            <option key="tod-1" value="SPWR Scope of Work (Always Require)">SPWR Scope of Work (Always Require)</option>
                            <option key="tod-2" value="Vendor Quote / Proposal">Vendor Quote / Proposal</option>
                            <option key="tod-3" value="Others">Other (Bid Form; Schedule;  Drawings; Specs)</option>
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.TypeOfDocuments?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={TypeOfDocs === "Others" ? false : true }>
                          <Form.Label className={styles.required}>Others</Form.Label>
                          <Form.Control type="text" {...register("TypeOfDocumentsOthers")} isInvalid={ !!errors.TypeOfDocumentsOthers }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.TypeOfDocumentsOthers?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                      <Form.Group className="mb-5">
                        <Form.Label className={styles.required}>All required attachments (other than line items)</Form.Label>
                        <Form.Control type="file" id="fileAllAttachment"  {...register("fileAllAttachment")} multiple />
                        <Form.Control.Feedback type="invalid">
                          {errors.fileAllAttachment?.message} 
                        </Form.Control.Feedback>
                        <p className="link-danger">{errors.fileAllAttachment?.message}</p>
                      </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Does the contact need a copy of the PO?</Form.Label>
                          <Form.Select aria-label="Please Select Option" {...register("ContactNeedCopy")} isInvalid={ !!errors.ContactNeedCopy } defaultValue="No">
                            <option key="cnc-null" value="">Please Select Option</option>
                            <option key="cnc-yes" value="Yes">Yes</option>
                            <option key="cnc-no" value="No">No</option>
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.ContactNeedCopy?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label>Is this contact a replacement of the previous PO receiver?</Form.Label>
                          <Form.Select aria-label="Please Select Option" 
                            {...register("ContactReplacement")} 
                            isInvalid={ !!errors.ContactReplacement } 
                            defaultValue="No" 
                            onChange={ (e) => { setContactReplacement(e.currentTarget.value)}}>
                            <option key="cnc-null" value="">Please Select Option</option>
                            <option key="cnc-yes" value="Yes">Yes</option>
                            <option key="cnc-no" value="No">No</option>
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.ContactReplacement?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3" hidden={ContactReplacement === "No" ? true : false }>
                          <Form.Label className={styles.required}>If Contact Replacement, please specify the contact to be removed</Form.Label>
                          <Form.Control type="text"  {...register("Contacttoberemoved")} isInvalid={ !!errors.Contacttoberemoved }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.Contacttoberemoved?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                
                <Card className="mb-3">
                  <Card.Header className="h5">Line Items</Card.Header>
                  <Card.Body>
                    <Card.Subtitle>Please dont forget to fillout the line items below</Card.Subtitle>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Number of Line Items</Form.Label>
                          <Form.Select aria-label="Please Select"  {...register("NumberofLineItems")} onChange={(e) => {setNIS(e.currentTarget.value)}} isInvalid={ !!errors.NumberofLineItems }>
                            <option value="">Please Select</option>
                            <option key="nol-null" value="1">1</option>
                            <option key="nol-1" value="2">2</option>
                            <option key="nol-2" value="3">3</option>
                            <option key="nol-3" value="more">more than 3 items</option>
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.NumberofLineItems?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>Retainage Percentage</Form.Label>
                          <Form.Select aria-label="Please Select" {...register("RetainagePercentage")} isInvalid={ !!errors.RetainagePercentage }>
                            <option value="">Please Select</option>
                            <option key="rp-0" value="0">0</option>
                            <option key="rp-5" value="5">5</option>
                            <option key="rp-10" value="10">10</option>
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.RetainagePercentage?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                    
                    <Row>
                      <Col>
                        <Card className='mb-3' hidden={NIS === "1" || NIS === "2" || NIS === "3" ? false : true }>
                          <Card.Header>Line Item 1</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select" {...register("TaskCodeItem1")} isInvalid={ !!errors.TaskCodeItem1 }>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.TaskCodeItem1?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Amount</Form.Label>
                                  <InputGroup>
                                    <InputGroup.Text>$</InputGroup.Text>
                                    <Form.Control type="text"  defaultValue={0} {...register("InitialAmountItem1")} isInvalid={ !!errors.InitialAmountItem1 } onChange={(e)=> { setItemAmount1(parseFloat(e.currentTarget.value)) } } />
                                  </InputGroup>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem1?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text" {...register("DescriptionItem1")} isInvalid={ !!errors.DescriptionItem1 }/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem1?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-3' hidden={NIS === "2" || NIS === "3" ? false : true }>
                          <Card.Header>Line Item 2</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select" {...register("TaskCodeItem2")} isInvalid={ !!errors.TaskCodeItem2 }>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.TaskCodeItem2?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Amount</Form.Label>
                                  <InputGroup>
                                    <InputGroup.Text>$</InputGroup.Text>
                                    <Form.Control type="text" defaultValue={0} {...register("InitialAmountItem2")} isInvalid={ !!errors.InitialAmountItem2 } onChange={(e)=> { setItemAmount2(parseFloat(e.currentTarget.value)) } } />
                                  </InputGroup>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem2?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text"  {...register("DescriptionItem2")} isInvalid={ !!errors.DescriptionItem2 }/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem2?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-3' hidden={ NIS === "3" ? false : true }>
                          <Card.Header>Line Item 3</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3">
                                  <Form.Label className={styles.required}>Task Code</Form.Label>
                                  <Form.Select aria-label="Please Select" {...register("TaskCodeItem3")} isInvalid={ !!errors.TaskCodeItem3 }>
                                    <option value="">Please Select</option>
                                    {Props.spTaskCodeListItems && Props.spTaskCodeListItems.map((list) => {
                                          return  ( 
                                            <option key={list.id} value={list.TaskCode}>{list.TaskCode}</option> 
                                          );
                                    })}
                                  </Form.Select>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.TaskCodeItem3?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                              <Col>
                                <Form.Group className="mb-3" >
                                <Form.Label className={styles.required}>Amount</Form.Label>
                                  <InputGroup>
                                    <InputGroup.Text>$</InputGroup.Text>
                                    <Form.Control type="text" defaultValue={0} {...register("InitialAmountItem3")} isInvalid={ !!errors.InitialAmountItem3 } onChange={(e)=> { setItemAmount3(parseFloat(e.currentTarget.value)) } } />
                                  </InputGroup>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.InitialAmountItem3?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Label className={styles.required}>Description</Form.Label>
                                  <Form.Control type="text"  {...register("DescriptionItem3")} isInvalid={ !!errors.DescriptionItem3 }/>
                                  <Form.Control.Feedback type="invalid">
                                    {errors.DescriptionItem3?.message}
                                  </Form.Control.Feedback>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-3' hidden={ NIS === "1" || NIS === "2" || NIS === "3" ? false : true }>
                          <Card.Header>Total Amount</Card.Header>
                          <Card.Body>
                            <Row>
                              <Col>
                                <Form.Group className="mb-3" >
                                  <Form.Control type="text"  {...register("TotalAmount")} value={TotalAmount}/>
                                </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                        <Card className='mb-2' hidden={ NIS === "more" ? false : true }>
                          <Card.Header>Line Item</Card.Header>
                          
                          <Card.Body>
                            <Card.Subtitle className="mb-2 text-muted">For more than 3 line items, please don&apos;t forget to fill-out the line items below.</Card.Subtitle>
                            <Card.Text>Instructions: Follow the link to navigate to the Box. Download the file named &lsquo;Project/Dev Proj SPPR Line Items template&lsquo;. Fill it in, save it in your computer and then attach it to the section below.</Card.Text>
                            <p hidden={ProjectType === "Prod" ? false : true }><a href='https://sunpowercorp.sharepoint.com/:x:/s/NewHomesTEST/EU2G1YndbpdLgkClSZwhkboBYcgY7HOQMm7cBOPzdFWZWQ?e=GcdF6R&download=1' rel="opener">Download template here</a> to fill in the Line Items</p>
                            <p hidden={ProjectType === "DEV" ? false : true }><a href='https://sunpowercorp.sharepoint.com/:x:/s/NewHomesTEST/EcGdP0iKTftBiI6BWmOJfqEBxG4igq0zI5Fb4IehkpjfNA?e=QpRE7V&download=1' rel="opener">Download template here</a> to fill in the Line Items</p>
                            <Row>
                              <Col>
                              <Form.Group className="mb-5">
                                <Form.Label className={styles.required}>Attach Line Items</Form.Label>
                                <Form.Control type="file" id="fileLineItem" {...register("fileLineItem")} multiple />
                                <Form.Text id="passwordHelpBlock" muted>Please attach only Excel files, other files will be discarded.</Form.Text>
                                <p className="link-danger">{errors.fileLineItem?.message}</p>
                              </Form.Group>
                              </Col>
                            </Row>
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header className="h5">CC Users</Card.Header>
                      <Card.Body>
                      <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                        <Form.Group className="mb-3" >
                          <Form.Check
                            inline
                            label="Yes"
                            value="true"
                            {...register("CCUser")} 
                            onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                          />
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label className={styles.required}>Email Addresses</Form.Label>
                          <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CCEmails?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("CCComment")} />
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Card style={{ width: '100%' }} className='mb-3'>
                  <Card.Body>
                    <Row>
                      <Col>
                        <Form.Group className="mb-3">
                          <Form.Label className={styles.required}>I am the Project Manager (Developer) for this project</Form.Label>
                          <Form.Select aria-label="Please Select" {...register("IAmProjectManager")} isInvalid={ !!errors.IAmProjectManager }>
                            <option value="">Please Select</option>
                            <option key="iapm-yes" value="Yes">Yes</option>
                            <option key="iapm-no" value="No">No</option>
                          </Form.Select>
                          <Form.Control.Feedback type="invalid">
                            {errors.IAmProjectManager?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
                <Row className="mb-4">
                  <Col>
                    <div className="d-grid gap-2">
                      <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting }>
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden={ !!isSubmitting }
                        className={ "visually-hidden" } />
                      { isSubmitting ? "...Submitting" : "SUBMIT" }
                      </Button>
                    </div>
                  </Col>
                </Row>
                { ShowSuccess && (
                    <Alert 
                      key={ MessageType } 
                      variant={ MessageType } 
                      dismissible 
                      onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                        { message }
                    </Alert>
                )}
              </Card.Body>
            </Card>
          </Container>
        </form>
        <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
          <Modal.Header>
            <Modal.Title>SharePoint</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Alert variant="primary">
              <Alert.Heading>{ message }</Alert.Heading>
              <p hidden={MessageType === "danger" ? true : false}>
                Thank you! You can now close this tab or window.
              </p>
            </Alert>
          </Modal.Body>
          <Modal.Footer hidden={MessageType === "danger" ? false : true}>
            <Button variant="secondary" onClick={handleClose}>
              Continue
            </Button>
          </Modal.Footer>
        </Modal>
      </section>
  );
}
