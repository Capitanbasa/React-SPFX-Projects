/* tslint:disable */
require("./Sppr.module.css");
const styles = {
  sppr: 'sppr_32011076',
  teams: 'teams_32011076',
  welcome: 'welcome_32011076',
  welcomeImage: 'welcomeImage_32011076',
  links: 'links_32011076',
  required: 'required_32011076',
  divDropArea: 'divDropArea_32011076'
};

export default styles;
/* tslint:enable */