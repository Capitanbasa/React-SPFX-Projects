declare interface ISpprWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  AppLocalEnvironmentSharePoint: string;
  AppLocalEnvironmentTeams: string;
  AppLocalEnvironmentOffice: string;
  AppLocalEnvironmentOutlook: string;
  AppSharePointEnvironment: string;
  AppTeamsTabEnvironment: string;
  AppOfficeEnvironment: string;
  AppOutlookEnvironment: string;
  UnknownEnvironment: string;
  PanePropsSpprList:string;
  PanePropsProjectNumberName:string;
  PanePropsPropsedVendor:string;
  PanePropsTaskCodeList:string;
}

declare module 'SpprWebPartStrings' {
  const strings: ISpprWebPartStrings;
  export = strings;
}
