import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  type IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
import { SPHttpClient } from '@microsoft/sp-http';

import * as strings from 'SpprWebPartStrings';
import Sppr from './components/Sppr';
import { IProjectListItem, ISpprListItems, ISpprProps, ITaskCodes } from './components/ISpprProps';
import NoAccess from './components/NoAccess';
import { getSP } from './utils/pnpjsConfig';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/site-users/web";
import 'bootstrap/dist/css/bootstrap.min.css';
import { isEmpty } from '@microsoft/sp-lodash-subset';
import SpprPM from './components/SpprPM';
import SpprIR from './components/SpprIR';
import SpprPR from './components/SpprPR';
import SpprPRC from './components/SpprPRC';
import SpprPO from './components/SpprPO';
import SpprCO from './components/SpprCO';


export interface ISpprWebPartProps {
  PanePropsPropsedVendor: string;
  PanePropsProjectNumberName: string;
  PanePropsTaskCodeList: string;
  PanePropsSpprList: string;
  description: string;
}

export default class SpprWebPart extends BaseClientSideWebPart<ISpprWebPartProps> {

  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = '';
  private _projectsList:  IProjectListItem[];
  private _spprItem: ISpprListItems[];
  private _currentUserVerified: boolean = false;
  private _taskcodes: ITaskCodes[];
  private _view: boolean = false;

  public render(): void {
    let StageComponentForm = Sppr;

    if(this._spprItem && this._spprItem.length > 0){
      if(this._currentUserVerified){
        switch (this._spprItem[0].Stage) {
          case 'PM Review':
            StageComponentForm = SpprPM; break;
          case 'Initiator Revision':
            StageComponentForm = SpprIR; break;
          case 'PR Creation':
            StageComponentForm = SpprPRC; break;
          case 'PO Creation':
            StageComponentForm = SpprPO; break;
          case 'Procurement Review':
            StageComponentForm = SpprPR; break;
          case 'CO Attachment':
            StageComponentForm = SpprCO; break;
          default:
            StageComponentForm = Sppr;
        }
      }else{
        StageComponentForm = NoAccess;
      }
    }else{
      StageComponentForm = Sppr;
    }

     // Additional Feature to view the current workflow for non actors/assignedTo
     const params = new URLSearchParams(window.location.search);
     const view:string = params.get('view') as string;
     if( view === 'true'){
       this._view = true;
       if(this._spprItem && this._spprItem.length > 0){
        switch (this._spprItem[0].Stage) {
          case 'PM Review':
            StageComponentForm = SpprPM; break;
          case 'Initiator Revision':
            StageComponentForm = SpprIR; break;
          case 'PR Creation':
            StageComponentForm = SpprPRC; break;
          case 'PO Creation':
            StageComponentForm = SpprPO; break;
          case 'Procurement Review':
            StageComponentForm = SpprPR; break;
          case 'CO Attachment':
            StageComponentForm = SpprCO; break;
          default:
            StageComponentForm = Sppr;
        }
       }else{
        StageComponentForm = Sppr;
       }
     }

    const element: React.ReactElement<ISpprProps> = React.createElement(
      StageComponentForm,
      {
        description: this.properties.description,
        isDarkTheme: this._isDarkTheme,
        environmentMessage: this._environmentMessage,
        hasTeamsContext: !!this.context.sdks.microsoftTeams,
        userDisplayName: this.context.pageContext.user.displayName,
        userEmail: this.context.pageContext.user.email,
        spContext: this.context,
        spProjectListItems: this._projectsList,
        spTaskCodeListItems: this._taskcodes,
        PanePropsProjectNumberName: this.properties.PanePropsProjectNumberName,
        PanePropsPropsedVendor: this.properties.PanePropsPropsedVendor,
        PanePropsSpprList : this.properties.PanePropsSpprList,
        spSpprItem: this._spprItem,
        spView: this._view
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected async onInit(): Promise<void> {
    await this._onGetProjectListItems();
    return this._getEnvironmentMessage().then(message => {
      this._environmentMessage = message;
    });
  }

  private _onGetProjectListItems = async (): Promise<void> => {
    const projectlist: IProjectListItem[] = await this._getProjectListItems();
    const SPPRItem: ISpprListItems[] = await this._getCurrentSPPRItem();
    const CurrentUserVerify:boolean = await this._verfiyuser(SPPRItem.length > 0 ? SPPRItem[0].AssignedToId : 0);
    const taskcodes: ITaskCodes[] = await this._getTaskCodes();
    this._projectsList = projectlist;
    this._taskcodes = taskcodes;
    this._spprItem = SPPRItem;
    this._currentUserVerified = CurrentUserVerify;
  }

  private async _getProjectListItems(): Promise<IProjectListItem[]> {

    // const response = await this.context.spHttpClient.get(
    //   this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${this.properties.PanePropsProjectNumberName}')/items?$select=Id,ProjectName,ProjectType&$filter=Transaction eq 'SPPR'`,
    //   SPHttpClient.configurations.v1)
    // if (!response.ok) {
    //   const responseText = await response.text();
    //   throw new Error(responseText);
    // }
    
    // const responseJson = await response.json();
  
    // return responseJson.value as IProjectListItem[];

    const sp = getSP(this.context);
    const countLastIDList = await sp.web.lists.getByTitle(this.properties.PanePropsProjectNumberName).items.select("ID").orderBy("ID", false).top(1)();
    const TopLastID = countLastIDList.length > 0 ? countLastIDList[0].ID : 0;
    const vendorsretult = await sp.web.lists.getByTitle(this.properties.PanePropsProjectNumberName).items.select("ProjectName", "Id", "ProjectType").top(TopLastID).filter("Transaction eq 'SPPR'")();
    console.log(vendorsretult);
    return vendorsretult;
  }

  private async _getTaskCodes(): Promise<ITaskCodes[]> {

    const response = await this.context.spHttpClient.get(
      this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${this.properties.PanePropsTaskCodeList}')/items?$select=Id,TaskCode`,
      SPHttpClient.configurations.v1)
    if (!response.ok) {
      const responseText = await response.text();
      throw new Error(responseText);
    }
    
    const responseJson = await response.json();
  
    return responseJson.value as ITaskCodes[];
  }

  private async _verfiyuser(assignedtoId:number): Promise<boolean> {
    const sp = getSP(this.context);

    if(assignedtoId !== 0 && assignedtoId){
      const user = await sp.web.currentUser();
      console.log("current User:", user);
      const assignedtoUserID = await sp.web.getUserById(assignedtoId)();
      console.log("Assigned User:", assignedtoUserID);
      if(user.UserId.NameId === assignedtoUserID.UserId.NameId){
        return true;
      }else{
        return false;
      }
    }else{
      return false;
    }
  }

  private async _getCurrentSPPRItem(): Promise<ISpprListItems[]> {
    const params = new URLSearchParams(window.location.search);
    const SPPR_ID:string = params.get('ReqID') as string ;
    if(!isEmpty(SPPR_ID)){
      const response = await this.context.spHttpClient.get(
        this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${this.properties.PanePropsSpprList}')/items?$filter= ID eq ${SPPR_ID}`,
        SPHttpClient.configurations.v1);
      if (!response.ok) {
        const responseText = await response.text();
        throw new Error(responseText);
      }
      
      const responseJson = await response.json();
      console.log(responseJson);
      return responseJson.value as ISpprListItems[];
    }else{
      const responseJson: ISpprListItems[]= [];
      return  responseJson;
    }
  
    
  }



  private _getEnvironmentMessage(): Promise<string> {
    if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
      return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
        .then(context => {
          let environmentMessage: string = '';
          switch (context.app.host.name) {
            case 'Office': // running in Office
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOffice : strings.AppOfficeEnvironment;
              break;
            case 'Outlook': // running in Outlook
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOutlook : strings.AppOutlookEnvironment;
              break;
            case 'Teams': // running in Teams
            case 'TeamsModern':
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentTeams : strings.AppTeamsTabEnvironment;
              break;
            default:
              environmentMessage = strings.UnknownEnvironment;
          }

          return environmentMessage;
        });
    }

    return Promise.resolve(this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentSharePoint : strings.AppSharePointEnvironment);
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }

    this._isDarkTheme = !!currentTheme.isInverted;
    const {
      semanticColors
    } = currentTheme;

    if (semanticColors) {
      this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
      this.domElement.style.setProperty('--link', semanticColors.link || null);
      this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
    }

  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('PanePropsSpprList', {
                  label: strings.PanePropsSpprList,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
                PropertyPaneTextField('PanePropsProjectNumberName', {
                  label: strings.PanePropsProjectNumberName,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
                PropertyPaneTextField('PanePropsPropsedVendor', {
                  label:strings.PanePropsPropsedVendor,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime:500
                }),
                PropertyPaneTextField('PanePropsTaskCodeList', {
                  label:strings.PanePropsTaskCodeList,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime:500
                }),
              ]
            }
          ]
        }
      ]
    };
  }

  private async validatePaneProps(value: string): Promise<string> {
    if (value === null || value.length === 0) {
      return "Provide the list name";
    }
    try{
      const response = await this.context.spHttpClient.get(
      this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${value}')/items?$select=Id`,
      SPHttpClient.configurations.v1);
      if (response.ok) {
        return "";
      } else if (response.status === 404) {
        return `List '${escape(value)}' doesn't exist in the current site`;
      }else{
        return `Error: ${response.statusText}. Please try again`;
      }
    }catch(error){
      return error.message;
    }
  }
}
