import * as yup from 'yup';

export const submittalsFormSchema = yup.object().shape({
    Stage: yup.string().default("PMO Review").notRequired(),
    Status: yup.string().default("Pending").notRequired(),
    flag: yup.string().notRequired(),
    ProjectName: yup.string().required("Project Number - Project Name is required"),
    RequesterName: yup.string().required("Requester Name is required"),
    RequesterEmail: yup.string().required().email("Requester Email is required"),
    Subject: yup.string().required("Subject is required"),
    SubmittalCategory: yup.string().required("SubmittalCategory is required"),
    Priority: yup.string().required("Priority is required"),
    Description: yup.string().required("Description is required"),
    Category:  yup.string().required("Category is required"),
    Responsible: yup.string().required("Responsible is required"),

    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TsubmittalsFormSchema = yup.InferType<typeof submittalsFormSchema>

export const submittalsFormPMOSchema = yup.object().shape({
    Stage: yup.string().required("Next step is required"),
    Status: yup.string().notRequired(),
    CommentsforInitiator: yup.string().when('Stage', {is: (stage:string) => stage==="Initiator Revise", then: () => yup.string().required("Comments for Initiator is required"), otherwise: () => yup.string().notRequired() }),
    EOR: yup.string().when('Stage', {is: (stage:string) => stage==="EOR Review", then: () => yup.string().required("EOR User is required"), otherwise: () => yup.string().notRequired() }),
    CommentsforEOR: yup.string().when('Stage', {is: (stage:string) => stage==="EOR Review", then: () => yup.string().required("Comments for EOR is required"), otherwise: () => yup.string().notRequired() }),
    ApproveComment: yup.string().default("").notRequired(),
    RejectComments: yup.string().default("").notRequired(),
    ConditionalApprovalComment: yup.string().when('Stage', {is: (stage:string) => stage==="Conditional Approval", then: () => yup.string().required("Comments is required"), otherwise: () => yup.string().notRequired() }),
    DelegatedTo: yup.string().when('Stage', {is: (stage:string) => stage==="Delegate", then: () => yup.string().required("Please select a User"), otherwise: () => yup.number().notRequired() }),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TsubmittalsFormPMOSchema = yup.InferType<typeof submittalsFormPMOSchema>

export const submittalsFormIRSchema = yup.object().shape({
    Stage: yup.string().required("Next step is required"),
    Status: yup.string().notRequired(),
    flag: yup.string().notRequired(),
    Priority: yup.string().required("Priority is required"),
    Description: yup.string().required("Description is required"),
    Category:  yup.string().required("Category is required"),
    Responsible: yup.string().required("Responsible is required"),
    ReviseInitiatorComments: yup.string().notRequired(),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TsubmittalsFormIRSchema = yup.InferType<typeof submittalsFormIRSchema>

export const submittalsFormEORSchema = yup.object().shape({
    Stage: yup.string().required("Next step is required"),
    Status: yup.string().notRequired(),
    flag: yup.string().notRequired(),
    EORComment: yup.string().when('Stage', {is: (stage:string) => stage==="PMO Review", then: () => yup.string().required("Response Comments is required"), otherwise: () => yup.string().notRequired() }),
    EOR: yup.string().when('Stage', {is: (stage:string) => stage==="Delegate", then: () => yup.string().required("Please select a EOR User"), otherwise: () => yup.number().notRequired() }),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TsubmittalsFormEORSchema = yup.InferType<typeof submittalsFormEORSchema>

export const submittalsFormConditionchema = yup.object().shape({
    Stage: yup.string().required("Next step is required"),
    Status: yup.string().notRequired(),
    Priority: yup.string().required("Priority is required"),
    Description: yup.string().required("Description is required"),
    Category:  yup.string().required("Category is required"),
    Responsible: yup.string().required("Responsible is required"),
    ConditionalComments: yup.string().when('Stage', {is: (stage:string) => stage==="PMO Review", then: () => yup.string().required("Comments is required"), otherwise: () => yup.string().notRequired() }),
    CCUser: yup.string().default("false").notRequired(),
    CCEmails: yup.string().when('CCUser', {is: (cc: string) => cc==="true", then: () =>  yup.string().required(), otherwise: () => yup.string().notRequired() }),
    CCComment: yup.string().notRequired()
});
export type TsubmittalsFormConditionchema = yup.InferType<typeof submittalsFormConditionchema>

export interface IWrorkFlow{
    Id?: number;
    itemID?: string;
    Transaction?: string;
    Stage: string;
    Status:string;
    flag?: string;
}

export interface IDelegateItem{
    id: string;
    imageInitials: string;
    imageUrl: string;
    loginName:string;
    optionalText:string;
    secondaryText:string;
    tertiaryText:string;
    text:string;
}