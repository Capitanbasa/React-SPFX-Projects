declare interface ISubmittalsFormSpFxWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  AppLocalEnvironmentSharePoint: string;
  AppLocalEnvironmentTeams: string;
  AppLocalEnvironmentOffice: string;
  AppLocalEnvironmentOutlook: string;
  AppSharePointEnvironment: string;
  AppTeamsTabEnvironment: string;
  AppOfficeEnvironment: string;
  AppOutlookEnvironment: string;
  UnknownEnvironment: string;
  PanePropsProjectNumberName: string;
  PanePropsSubmittalsList: string;
}

declare module 'SubmittalsFormSpFxWebPartStrings' {
  const strings: ISubmittalsFormSpFxWebPartStrings;
  export = strings;
}
