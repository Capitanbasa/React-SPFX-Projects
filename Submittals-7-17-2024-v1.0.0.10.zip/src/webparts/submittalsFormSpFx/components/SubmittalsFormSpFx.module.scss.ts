/* tslint:disable */
require("./SubmittalsFormSpFx.module.css");
const styles = {
  submittalsFormSpFx: 'submittalsFormSpFx_08ac17d9',
  teams: 'teams_08ac17d9',
  welcome: 'welcome_08ac17d9',
  welcomeImage: 'welcomeImage_08ac17d9',
  links: 'links_08ac17d9',
  required: 'required_08ac17d9',
  divDropArea: 'divDropArea_08ac17d9'
};

export default styles;
/* tslint:enable */