import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface ISubmittalsFormSpFxProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  spProjectListItems?: IProjectListItem[];
  PanePropsProjectNumberName: string;
  PanePropsSubmittalsList:string;
  spContext: WebPartContext;
  userEmail?:string;
  spSubmittalItem:ISubmittalsListItems[];
}

export interface ISubmittalsFormSpFxWebPartProps {
  description: string;
  PanePropsProjectNumberName: string;
  PanePropsSubmittalsList:string;
}

export interface IProjectListItem{
  id: string;
  ProjectName: string;
}

export interface ISubmittalsListItems{
  AssignedTo:string;
  AssignedToId:number;
  Id: string;
  Stage: string;
  Status: string;
  ProjectName:string;
  RequesterName: string;
  RequesterEmail: string;
  Subject: string;
  SubmittalCategory: string;
  Priority: string;
  Description: string;
  Category:  string;
  Responsible: string;
  CCUser: string;
  CCEmails?: string;
  CCComment?:string;
  EORComment:string;
  EOR:string;
  CommentsforEOR:string;
  ApproveComment:string;
  RejectComments:string;
  ConditionalApprovalComment:string;
  DelegatedToId:string;
  ReviseInitiatorComments:string;
  CommentsforInitiator:string;
  ConditionalComments:string;
  flag:string;
}
