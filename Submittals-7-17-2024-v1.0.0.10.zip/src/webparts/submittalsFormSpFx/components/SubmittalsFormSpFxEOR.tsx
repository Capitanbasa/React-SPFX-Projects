import * as React from 'react';
import styles from './SubmittalsFormSpFx.module.scss';
import type { ISubmittalsFormSpFxProps } from './ISubmittalsFormSpFxProps';
import { Alert, Button, Card, Col, Container, Form, Modal, Row, Spinner } from 'react-bootstrap';
import { TsubmittalsFormEORSchema, submittalsFormEORSchema } from '../utils/types';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup"
import { getSP } from '../utils/pnpjsConfig';
import addFilesPromise from '../utils/addFilesPromise';
import WorkFlowSubmit from '../utils/WorkFlowSubmit';
import { IAttachmentInfo } from '@pnp/sp/attachments';
import { IoDocumentAttachOutline } from "react-icons/io5";
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
//import { escape } from '@microsoft/sp-lodash-subset';

export default function SubmittalsFormSpFxEOR(Props:ISubmittalsFormSpFxProps):React.ReactElement{
  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [CCGroup, setCCGroup]= React.useState( Props.spSubmittalItem[0].CCUser === "Yes" ? true : false );
  const [theAttachmentFiles, settheAttachmentFiles] = React.useState<IAttachmentInfo[]>([]);
  const [nextStage , setnextStage] = React.useState("");
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);

  const { 
    register, 
    handleSubmit,
    formState: {errors, isSubmitting},
    reset, setValue
  } = useForm<TsubmittalsFormEORSchema>({
    resolver: yupResolver(submittalsFormEORSchema),
  });

   /* eslint-disable  @typescript-eslint/no-explicit-any */
  const _getPeoplePickerDelegate = (items:any[]):void => {
    console.log("Delegated EOR User:",items );
    items.map((item) => { 
      setValue("EOR", item.loginName)
    });

  }

  const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
    if(FileAttachment && FileAttachment?.length > 0){
      for(let i =0; i < FileAttachment.length; i++){
        /* eslint-disable no-useless-escape */
        const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
        if(match){
          setShowSuccess(true);
          setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
          setMessageType('danger');
          return true;
        }else{
          return false;
        }

      }
    }
    return false;
  }

  const onSubmit = async (data: TsubmittalsFormEORSchema):Promise<void> => {
    const sp = getSP(Props.spContext);
    const Attachment = document.getElementById("FileAttachment") as HTMLInputElement;
    const Attfiles = Attachment.files;
    if(filenameCharValidation(Attfiles)){ return; }
    
    data.CCUser = CCGroup === true ? "Yes": "No";
    console.log("Schema Data:", data);
 
    let newStatus:string = "";
    switch(data.Stage){
      case "PMO Review":   newStatus = "Pending";  break;
      case "Delegate":  data.Stage = "EOR Review"; newStatus = "Delegate"; break;
      default: newStatus = "Pending";  data.flag = "2";
    }
    data.Status = newStatus;

    await sp.web.lists.getByTitle(Props.PanePropsSubmittalsList).items.getById(parseInt(Props.spSubmittalItem[0].Id)).update(data)
    .then(async (addResult) => {
      console.log("add result:",addResult);

      if(Attfiles && Attfiles?.length > 0){
        const PromoseArray = [];
        setShowSuccess(true);
        setmessage("Please wait while we upload the file Attachment.");
        setMessageType('warning');
        for(let i =0; i < Attfiles.length; i++){
          const UploadArray = await addFilesPromise( Props.PanePropsSubmittalsList, parseInt(Props.spSubmittalItem[0].Id) ,Attfiles, i);
          PromoseArray.push(UploadArray);
        }
        Promise.all(PromoseArray).then( res => { 
          console.log("Promise Upload resolve:", res);
          setShowSuccess(true);
          setmessage("Successfully Submitted Your Request.");
          setMessageType('success');
          reset();
        })
        .catch(err => { 
          console.log("Promise Upload reject:", err);
          setShowSuccess(true);
          setmessage("Your Request is Submitted but there was a problem uploading the attachment");
          setMessageType('danger');
          reset();
        });
      }else{
        setShowSuccess(true);
        setmessage("Successfully Submitted Your Request without Attachment.");
        setMessageType('warning');
        reset();
      }
      const WFresult = await WorkFlowSubmit(Props.spSubmittalItem[0].Id.toString(), false, newStatus, data.Stage);
      console.log("WF Result:", WFresult);
      reset();
      setModalShow(true);
      return Promise.resolve;
    })
    .catch( (error) => {
        console.log("Error Submit:", error);
        setShowSuccess(true);
        setmessage("Sorry! Your Request failed to Submit. Please try again.");
         setMessageType('danger');
        return Promise.reject;
    });
    
  };
  let attachments: IAttachmentInfo[] = [];
  React.useEffect(() => {
    async function fecthData():Promise<void>{
      const sp = getSP();
      const item = sp.web.lists.getByTitle(Props.PanePropsSubmittalsList).items.getById(parseInt(Props.spSubmittalItem[0].Id));
      attachments = await item.attachmentFiles().then(async res => {return await res});
      settheAttachmentFiles(attachments);
      console.log("await:",attachments);
    }
    fecthData().catch(console.error);
  },[]);

  return(
    <section className={`${styles.submittalsFormSpFx} ${Props.hasTeamsContext ? styles.teams : ''}`}>
       <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
       <Container>
            <Card>
              <Card.Header className="h5">Submittal Item - EOR Review</Card.Header>
              <Card.Body>
                <Row>
                  <Col>
                  <Form.Group className="mb-3">
                      <Form.Label>Project Number and Name</Form.Label>
                      <Form.Control type="text" value={Props.spSubmittalItem[0].ProjectName} disabled/>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Instance Number</Form.Label>
                      <Form.Control type="text" value={Props.spSubmittalItem[0].Id} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                  <Form.Group className="mb-3" >
                    <Form.Label>Requester Name</Form.Label>
                    <Form.Control type="text"  value={Props.spSubmittalItem[0].RequesterName} disabled/>
                  </Form.Group>
                    
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Requester Email</Form.Label>
                      <Form.Control type="email"  value={Props.spSubmittalItem[0].RequesterEmail} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>Subject</Form.Label>
                      <Form.Control type="text" value={Props.spSubmittalItem[0].Subject} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>Submittal Category</Form.Label>
                      <Form.Control type="text"  value={Props.spSubmittalItem[0].SubmittalCategory} disabled/>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>Priority</Form.Label>
                      <Form.Control type="text"  value={Props.spSubmittalItem[0].Priority} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>Description</Form.Label>
                      <Form.Control as="textarea"  value={Props.spSubmittalItem[0].Description} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>Category</Form.Label>
                      <Form.Control type="text"  value={Props.spSubmittalItem[0].Category} disabled/>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label>Responsible Sub/Manufacturer</Form.Label>
                      <Form.Control type="text"  value={Props.spSubmittalItem[0].Responsible} disabled/>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>Initiator Attachments</Card.Header>
                      <Card.Body>
                        <div className="d-grid gap-2">
                          {
                          theAttachmentFiles && theAttachmentFiles.map((aFile) => {
                              return(<Button key={aFile.FileName} href={ aFile.ServerRelativePath.DecodedUrl } variant="info" className='mb-2'><IoDocumentAttachOutline />{aFile.FileName}</Button>);
                            })
                          }
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                  <Card style={{ width: '100%' }}>
                      <Card.Header>APM/PM Comments</Card.Header>
                      <Card.Body>
                          <p>{Props.spSubmittalItem[0].CommentsforEOR}</p>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>CC Users</Card.Header>
                      <Card.Body>
                      <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                        <Form.Group className="mb-3" >
                          <Form.Check
                            inline
                            label="Yes"
                            value="true"
                            {...register("CCUser")} 
                            onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                          />
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label className={styles.required}>Email Addresses</Form.Label>
                          <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CCEmails?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("CCComment")} />
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label >Attachments</Form.Label>
                      <Form.Control type="file" id="FileAttachment" multiple />
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label className={styles.required}>Next step</Form.Label>
                      <Form.Select aria-label="Please Select Next Step" {...register("Stage")} isInvalid={!!errors.Stage } onChange={(e)=>{setnextStage(e.currentTarget.value )}} >
                        <option value="">Please Select Next Step</option>
                        <option key='ns1' value="PMO Review">Respond</option>
                        <option key='ns6' value="Delegate">Delegate</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.Stage?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5" hidden={nextStage === "PMO Review" ? false: true}>
                      <Form.Label className={styles.required}>Comments</Form.Label>
                      <Form.Control as="textarea" rows={3} defaultValue={Props.spSubmittalItem[0].EORComment} {...register("EORComment")} isInvalid={!!errors.EORComment }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.EORComment?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5" hidden={nextStage === "Delegate" ? false: true}>
                      <PeoplePicker
                        context={Props.spContext}
                        {...register("EOR")}
                        titleText="Choose EOR"
                        personSelectionLimit={1}
                        showtooltip={true}
                        required={true}
                        ensureUser={true}
                        onChange={ items => _getPeoplePickerDelegate(items) }
                        principalTypes={[PrincipalType.User]}
                        resolveDelay={1000} />
                      <p className="link-danger">{errors.EOR?.message}</p>
                    </Form.Group>
                  </Col>
                </Row>

                <Row className="mb-4">
                  <Col>
                    <div className="d-grid gap-2">
                      <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting } >
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden={ !!isSubmitting }
                        className={ "visually-hidden" } />
                      { isSubmitting ? "...Submitting" : "SUBMIT" }
                      </Button>
                    </div>
                  </Col>
                </Row>
                { ShowSuccess && (
                    <Alert 
                      key={ MessageType } 
                      variant={ MessageType } 
                      dismissible 
                      onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                        { message }
                    </Alert>
                )}
              </Card.Body>
            </Card>
          </Container>
        </form>
        <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
          <Modal.Header>
            <Modal.Title>SharePoint</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Alert variant="primary">
              <Alert.Heading>{ message }</Alert.Heading>
              <p hidden={MessageType === "danger" ? true : false}>
                Thank you! You can now close this tab or window.
              </p>
            </Alert>
          </Modal.Body>
          <Modal.Footer hidden={MessageType === "danger" ? false : true}>
            <Button variant="secondary" onClick={handleClose}>
              Continue
            </Button>
          </Modal.Footer>
        </Modal>
      </section>
  );
}