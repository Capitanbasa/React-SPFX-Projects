import * as React from 'react';
import styles from './SubmittalsFormSpFx.module.scss';
import type { ISubmittalsFormSpFxProps } from './ISubmittalsFormSpFxProps';
import { Alert, Button, Card, Col, Container, Form, Modal, Row, Spinner } from 'react-bootstrap';
import { TsubmittalsFormSchema, submittalsFormSchema } from '../utils/types';
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup"
import { getSP } from '../utils/pnpjsConfig';
import addFilesPromise from '../utils/addFilesPromise';
import WorkFlowSubmit from '../utils/WorkFlowSubmit';

export default function SubmittalsFormSpFx(Props:ISubmittalsFormSpFxProps):React.ReactElement{
  const [ShowSuccess, setShowSuccess] = React.useState( false );
  const [message, setmessage]= React.useState( "" );
  const [MessageType, setMessageType] = React.useState( "success" ); // success, warning, danger
  const [CCGroup, setCCGroup ] = React.useState(false);
  const [ModalShow, setModalShow ] = React.useState(false);
  const handleClose = ():void => setModalShow(false);

  const { 
    register, 
    handleSubmit,
    formState: {errors, isSubmitting},
    reset
  } = useForm<TsubmittalsFormSchema>({
    resolver: yupResolver(submittalsFormSchema),
  });

  const filenameCharValidation = (FileAttachment:FileList|null|undefined):boolean => {
    if(FileAttachment && FileAttachment?.length > 0){
      for(let i =0; i < FileAttachment.length; i++){
        /* eslint-disable no-useless-escape */
        const match = (new RegExp('[~#!%\@$&^*{}+\|]|\\.\\.|^\\.|\\.$')).test(FileAttachment[i].name);
        if(match){
          setShowSuccess(true);
          setmessage("The file name contains invalid characters.("+FileAttachment[i].name+"). The following characters are not allowed: [ \" < > ! @ # $ % ^ & * ].");
          setMessageType('danger');
          return true;
        }else{
          return false;
        }

      }
    }
    return false;
  }

  const onSubmit = async (data: TsubmittalsFormSchema):Promise<void> => {
    const sp = getSP(Props.spContext);
    const Attachment = document.getElementById("FileAttachment") as HTMLInputElement;
    const Attfiles = Attachment.files;
    if(filenameCharValidation(Attfiles)){ return; }

    data.CCUser = CCGroup === true ? "Yes": "No";
    data.flag = "1";
    console.log("Schema Data:", data);

    await sp.web.lists.getByTitle(Props.PanePropsSubmittalsList).items.add(data)
    .then(async (addResult) => {
      console.log("add result:",addResult);

      if(Attfiles && Attfiles?.length > 0){
        const PromoseArray = [];
        setShowSuccess(true);
        setmessage("Please wait while we upload the file Attachment.");
        setMessageType('warning');
        for(let i =0; i < Attfiles.length; i++){
          const UploadArray = await addFilesPromise( Props.PanePropsSubmittalsList, addResult.ID ,Attfiles, i);
          PromoseArray.push(UploadArray);
        }
        Promise.all(PromoseArray).then( res => { 
          console.log("Promise Upload resolve:", res);
          setShowSuccess(true);
          setmessage("Successfully Submitted Your Request.");
          setMessageType('success');
          reset();
        })
        .catch(err => { 
          console.log("Promise Upload reject:", err);
          setShowSuccess(true);
          setmessage("Your Request is Submitted but there was a problem uploading the attachment");
          setMessageType('danger');
          reset();
        });
      }else{
        setShowSuccess(true);
        setmessage("Successfully Submitted Your Request without Attachment.");
        setMessageType('warning');
        reset();
      }
      const WFresult = await WorkFlowSubmit(addResult.ID.toString(), true, "Pending", "PMO Review", "1", data.ProjectName);
      console.log("WF Result:", WFresult);
      reset();
      setModalShow(true);
      return Promise.resolve;
    })
    .catch( (error) => {
        console.log("Error Submit:", error);
        setShowSuccess(true);
        setmessage("Sorry! Your Request failed to Submit. Please try again.");
         setMessageType('danger');
        return Promise.reject;
    });
    
  };
  // React.useEffect(() => {
  //   async function test():Promise<void>{
  //     const sp = getSP(Props.spContext);
  //     const pm:IWrorkFlow[] = await sp.web.lists.getByTitle("Workflow List").items.filter(`itemID eq '4' and Transaction eq 'Submittals'`)();
  //     console.log("WF:",pm);
  //   }
  //   test().catch(console.error);
  // },[]);

  return(
    <section className={`${styles.submittalsFormSpFx} ${Props.hasTeamsContext ? styles.teams : ''}`}>
       <form noValidate id="spwr-form" onSubmit={handleSubmit(onSubmit)}>
       <Container>
            <Card>
              <Card.Header className="h5">Submittal Item</Card.Header>
              <Card.Body>
                <Row>
                  <Col>
                  <Form.Group className="mb-3">
                    <Form.Label className={styles.required}>Project Number and Name</Form.Label>
                    <Form.Select aria-label="Please Select Project" {...register("ProjectName")} isInvalid={ !!errors.ProjectName }>
                      <option value="">Please Select Project</option> 
                        {Props.spProjectListItems && Props.spProjectListItems.map((list) => {
                              return  ( 
                                <option key={list.id} value={list.ProjectName}>{list.ProjectName}</option> 
                              );
                        })}
                    </Form.Select>
                    <Form.Control.Feedback type="invalid">
                      {errors.ProjectName?.message}
                    </Form.Control.Feedback>
                  </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label className={styles.required}>Requester Name</Form.Label>
                      <Form.Control type="text" {...register("RequesterName")} defaultValue={Props.userDisplayName} isInvalid={ !!errors.RequesterName }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.RequesterName?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label className={styles.required}>Requester Email</Form.Label>
                      <Form.Control type="email" {...register("RequesterEmail")} isInvalid={ !!errors.RequesterEmail } defaultValue={Props.userEmail}/>
                      <Form.Control.Feedback type="invalid">
                        {errors.RequesterEmail?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-5" >
                      <Form.Label className={styles.required}>Subject</Form.Label>
                      <Form.Control type="text"  {...register("Subject")} isInvalid={ !!errors.Subject }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.Subject?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label className={styles.required}>Submittal Category</Form.Label>
                      <Form.Select aria-label="Please Select Submittal Category" {...register("SubmittalCategory")} isInvalid={!!errors.SubmittalCategory }>
                        <option value="">Please Select Submittal Category</option>
                        <option key='sc1' value="Electrical">Electrical</option>
                        <option key='sc2' value="Structural">Structural</option>
                        <option key='sc3' value="Safety">Safety</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.SubmittalCategory?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label className={styles.required}>Priority</Form.Label>
                      <Form.Select aria-label="Please Select Priority" {...register("Priority")} isInvalid={!!errors.Priority }>
                        <option value="">Please Select Priority</option>
                        <option key='Priority1' value="Low">Low</option>
                        <option key='Priority2' value="Normal">Normal</option>
                        <option key='Priority3' value="High">High</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.Priority?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3" >
                      <Form.Label className={styles.required}>Description</Form.Label>
                      <Form.Control as="textarea"  {...register("Description")} isInvalid={ !!errors.Description }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.Description?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-4">
                      <Form.Label className={styles.required}>Category</Form.Label>
                      <Form.Select aria-label="Please Select Category" {...register("Category")} isInvalid={!!errors.Category }>
                        <option value="">Please Select Category</option>
                        <option key='cat1' value="Bid Submittals">Bid Submittals</option>
                        <option key='cat2' value="Certification">Certification</option>
                        <option key='cat3' value="Compliance">Compliance</option>
                        <option key='cat4' value="EPC Contractor Deliverables">EPC Contractor Deliverables</option>
                        <option key='cat5' value="Internal Documentation">Internal Documentation</option>
                        <option key='cat6' value="List">List</option>
                        <option key='cat7' value="Manual">Manual</option>
                        <option key='cat8' value="Mix Design">Mix Design</option>
                        <option key='cat9' value="Mock Up">Mock Up</option>
                        <option key='cat10' value="Operation/Maintenance Manual">Operation/Maintenance Manual</option>
                        <option key='cat11' value="Other">Other</option>
                        <option key='cat12' value="Product Data">Product Data</option>
                        <option key='cat13' value="Record Drawings">Record Drawings</option>
                        <option key='cat14' value="Reports">Reports</option>
                        <option key='cat15' value="Sample">Sample</option>
                        <option key='cat16' value="Schedule">Schedule</option>
                        <option key='cat17' value="Shop Drawing">Shop Drawing</option>
                        <option key='cat18' value="Test Report">Test Report</option>
                        <option key='cat19' value="Workplan">Workplan</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.Category?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-4" >
                      <Form.Label className={styles.required}>Responsible Sub/Manufacturer</Form.Label>
                      <Form.Control type="text" {...register("Responsible")}  isInvalid={ !!errors.Responsible }/>
                      <Form.Control.Feedback type="invalid">
                        {errors.Responsible?.message}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-5">
                  <Col>
                    <Card style={{ width: '100%' }}>
                      <Card.Header>CC Users</Card.Header>
                      <Card.Body>
                      <Card.Text>Would you like to CC any users to this process instance?*</Card.Text>
                        <Form.Group className="mb-3" >
                          <Form.Check
                            inline
                            label="Yes"
                            value="true"
                            {...register("CCUser")} 
                            onChange={(e) => { setCCGroup(e.currentTarget.checked === true ? true : false)}}
                          />
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label className={styles.required}>Email Addresses</Form.Label>
                          <Form.Control type="text" {...register("CCEmails")} isInvalid={ !!errors.CCEmails }/>
                          <Form.Control.Feedback type="invalid">
                            {errors.CCEmails?.message}
                          </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3" hidden={CCGroup === true ? false : true }>
                          <Form.Label>Comments for cc&lsquo;ed users</Form.Label>
                          <Form.Control as="textarea" rows={3} {...register("CCComment")} />
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row className='mt-4'>
                  <Col>
                    <Form.Group className="mb-5">
                      <Form.Label >Attachments</Form.Label>
                      <Form.Control type="file" id="FileAttachment" multiple />
                    </Form.Group>
                  </Col>
                </Row>
                <Row className="mb-4">
                  <Col>
                    <div className="d-grid gap-2">
                      <Button type="submit" variant="primary" size="lg" id="btn-submit" disabled={ isSubmitting } >
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden={ !!isSubmitting }
                        className={ "visually-hidden" } />
                      { isSubmitting ? "...Submitting" : "SUBMIT" }
                      </Button>
                    </div>
                  </Col>
                </Row>
                { ShowSuccess && (
                    <Alert 
                      key={ MessageType } 
                      variant={ MessageType } 
                      dismissible 
                      onClose={() => { setShowSuccess(false); setmessage(""); setMessageType( 'success'); } } >
                        { message }
                    </Alert>
                )}
              </Card.Body>
            </Card>
          </Container>
        </form>
        <Modal show={ModalShow} onHide={handleClose} backdrop="static" keyboard={false} centered size="lg" >
          <Modal.Header>
            <Modal.Title>SharePoint</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Alert variant="primary">
              <Alert.Heading>{ message }</Alert.Heading>
              <p hidden={MessageType === "danger" ? true : false}>
                Thank you! You can now close this tab or window.
              </p>
            </Alert>
          </Modal.Body>
          <Modal.Footer hidden={MessageType === "danger" ? false : true}>
            <Button variant="secondary" onClick={handleClose}>
              Continue
            </Button>
          </Modal.Footer>
        </Modal>
      </section>
  );
}