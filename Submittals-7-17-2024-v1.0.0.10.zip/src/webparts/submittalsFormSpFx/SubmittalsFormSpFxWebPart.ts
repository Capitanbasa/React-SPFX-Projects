import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  type IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';

import * as strings from 'SubmittalsFormSpFxWebPartStrings';
import SubmittalsFormSpFx from './components/SubmittalsFormSpFx';
import { IProjectListItem, ISubmittalsFormSpFxProps, ISubmittalsFormSpFxWebPartProps, ISubmittalsListItems } from './components/ISubmittalsFormSpFxProps';
import { SPHttpClient } from '@microsoft/sp-http';

import NoAccess from './components/NoAccess';
import SubmittalsFormSpFxPMO from './components/SubmittalsFormSpFxPMO';
import SubmittalsFormSpFxIR from './components/SubmittalsFormSpFxIR';
import SubmittalsFormSpFxEOR from './components/SubmittalsFormSpFxEOR';
import SubmittalsFormSpFxCondition from './components/SubmittalsFormSpFxCondition';
import { isEmpty } from '@microsoft/sp-lodash-subset';
import { getSP } from './utils/pnpjsConfig';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/site-users/web";
import 'bootstrap/dist/css/bootstrap.min.css';

export default class SubmittalsFormSpFxWebPart extends BaseClientSideWebPart<ISubmittalsFormSpFxWebPartProps> {

  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = '';
  private _projectsList:  IProjectListItem[];
  private _submittalsItem: ISubmittalsListItems[];
  private _currentUserVerified: boolean = false;

  public render(): void {

    let StageComponentForm = SubmittalsFormSpFx;
 

      if(this._submittalsItem && this._submittalsItem.length > 0){
        if(this._currentUserVerified){
          switch (this._submittalsItem[0].Stage) {
            case 'PMO Review':
              StageComponentForm = SubmittalsFormSpFxPMO; break;
            case 'Initiator Revision':
              StageComponentForm = SubmittalsFormSpFxIR; break;
            case 'EOR Review':
              StageComponentForm = SubmittalsFormSpFxEOR; break;
            case 'Conditional Approval':
              StageComponentForm = SubmittalsFormSpFxCondition; break;
            default:
              StageComponentForm = SubmittalsFormSpFx;
          }
        }else{
          StageComponentForm = NoAccess;
        }
      }else{
        StageComponentForm = SubmittalsFormSpFx;
      }

    const element: React.ReactElement<ISubmittalsFormSpFxProps> = React.createElement(
      StageComponentForm,
      {
        description: this.properties.description,
        isDarkTheme: this._isDarkTheme,
        environmentMessage: this._environmentMessage,
        hasTeamsContext: !!this.context.sdks.microsoftTeams,
        userDisplayName: this.context.pageContext.user.displayName,
        userEmail: this.context.pageContext.user.email,
        spContext: this.context,
        spProjectListItems: this._projectsList,
        PanePropsProjectNumberName: this.properties.PanePropsProjectNumberName,
        PanePropsSubmittalsList : this.properties.PanePropsSubmittalsList,
        spSubmittalItem: this._submittalsItem,
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected async onInit(): Promise<void> {
    await this._onGetProjectListItems();
    return this._getEnvironmentMessage().then(message => {
      this._environmentMessage = message;
    });
  }

  private _onGetProjectListItems = async (): Promise<void> => {
    const projectlist: IProjectListItem[] = await this._getProjectListItems();
    const submittalsItem: ISubmittalsListItems[] = await this._getCurrentSubmittalsItem();
    const CurrentUserVerify:boolean = await this._verfiyuser(submittalsItem.length > 0 ? submittalsItem[0].AssignedToId : 0);
    this._projectsList = projectlist;
    this._submittalsItem = submittalsItem;
    this._currentUserVerified = CurrentUserVerify;
  }

  private async _getProjectListItems(): Promise<IProjectListItem[]> {

    // const response = await this.context.spHttpClient.get(
    //   this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${this.properties.PanePropsProjectNumberName}')/items?$select=Id,ProjectName&$filter=Transaction eq 'Submittals' and ProjectType eq 'Prod'`,
    //   SPHttpClient.configurations.v1)
    // if (!response.ok) {
    //   const responseText = await response.text();
    //   throw new Error(responseText);
    // }
    // const responseJson = await response.json();
    // return responseJson.value as IProjectListItem[];

    const sp = getSP(this.context);
    const countLastIDList = await sp.web.lists.getByTitle(this.properties.PanePropsProjectNumberName).items.select("ID").orderBy("ID", false).top(1)();
    const TopLastID = countLastIDList.length > 0 ? countLastIDList[0].ID : 0;
    const vendorsretult = await sp.web.lists.getByTitle(this.properties.PanePropsProjectNumberName).items.select("ProjectName", "Id", "ProjectType").top(TopLastID).filter("Transaction eq 'Submittals' and ProjectType eq 'Prod'")();
    console.log(vendorsretult);
    return vendorsretult;

  }

  private async _verfiyuser(assignedtoId:number): Promise<boolean> {
    const sp = getSP(this.context);

    if(assignedtoId !== 0 && assignedtoId){
      const user = await sp.web.currentUser();
      console.log("current User:", user);
      const assignedtoUserID = await sp.web.getUserById(assignedtoId)();
      console.log("Assigned User:", assignedtoUserID);
      if(user.UserId.NameId === assignedtoUserID.UserId.NameId){
        return true;
      }else{
        return false;
      }
    }else{
      return false;
    }
  }

  private async _getCurrentSubmittalsItem(): Promise<ISubmittalsListItems[]> {
    const params = new URLSearchParams(window.location.search);
    const CCO_ID:string = params.get('ReqID') as string ;
    if(!isEmpty(CCO_ID)){
      const response = await this.context.spHttpClient.get(
        this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${this.properties.PanePropsSubmittalsList}')/items?$filter= ID eq ${escape(CCO_ID)}`,
        SPHttpClient.configurations.v1);
      if (!response.ok) {
        const responseText = await response.text();
        throw new Error(responseText);
      }
      
      const responseJson = await response.json();
      console.log(responseJson);
      return responseJson.value as ISubmittalsListItems[];
    }else{
      const responseJson: ISubmittalsListItems[]= [];
      return  responseJson;
    }
  
    
  }



  private _getEnvironmentMessage(): Promise<string> {
    if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
      return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
        .then(context => {
          let environmentMessage: string = '';
          switch (context.app.host.name) {
            case 'Office': // running in Office
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOffice : strings.AppOfficeEnvironment;
              break;
            case 'Outlook': // running in Outlook
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOutlook : strings.AppOutlookEnvironment;
              break;
            case 'Teams': // running in Teams
            case 'TeamsModern':
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentTeams : strings.AppTeamsTabEnvironment;
              break;
            default:
              environmentMessage = strings.UnknownEnvironment;
          }

          return environmentMessage;
        });
    }

    return Promise.resolve(this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentSharePoint : strings.AppSharePointEnvironment);
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }

    this._isDarkTheme = !!currentTheme.isInverted;
    const {
      semanticColors
    } = currentTheme;

    if (semanticColors) {
      this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
      this.domElement.style.setProperty('--link', semanticColors.link || null);
      this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
    }

  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('PanePropsSubmittalsList', {
                  label: strings.PanePropsSubmittalsList,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
                PropertyPaneTextField('PanePropsProjectNumberName', {
                  label: strings.PanePropsProjectNumberName,
                  onGetErrorMessage: this.validatePaneProps.bind(this),
                  deferredValidationTime: 500
                }),
              ]
            }
          ]
        }
      ]
    };
  }

  private async validatePaneProps(value: string): Promise<string> {
    if (value === null || value.length === 0) {
      return "Provide the list name";
    }
    try{
      const response = await this.context.spHttpClient.get(
      this.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${value}')/items?$select=Id`,
      SPHttpClient.configurations.v1);
      if (response.ok) {
        return "";
      } else if (response.status === 404) {
        return `List '${escape(value)}' doesn't exist in the current site`;
      }else{
        return `Error: ${response.statusText}. Please try again`;
      }
    }catch(error){
      return error.message;
    }
  }
}
